# Project instructions

This is a UX course team prototype (Vite + React + Tailwind CSS v4).

- The dev server is already running with hot reload. **Do NOT run `npm run dev`** or any other server process.
- Work only inside this folder. Do not read or modify files outside it.
- Code lives under `src/`; put components in `src/components/`.
- Use Tailwind classes for styling (Tailwind v4; `src/index.css` contains `@import "tailwindcss";`).
- To add a package use `npm install <package>`. To check for errors use `npm run build`. Use shell commands to inspect this project and apply_patch to edit files.
- There is no backend. Keep data in code or in `localStorage`.
- Work in small steps – the app must always work after every change.
- Reply in English, briefly: what you changed and what can be seen in the preview.
