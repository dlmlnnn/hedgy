"""Create a portable source archive without dependencies, caches or user data."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
destination = root / 'public' / 'downloads' / 'grow-your-day.zip'
destination.parent.mkdir(parents=True, exist_ok=True)
files = ['package.json', 'package-lock.json', 'index.html', 'vite.config.js',
         'playwright.config.js', '.gitignore', 'README.md']
for directory in ['src', 'tests', 'scripts', 'public']:
    files.extend(str(path.relative_to(root)) for path in (root / directory).rglob('*')
                 if path.is_file() and path.suffix not in ['.zip', '.pyc', '.tmp']
                 and '__pycache__' not in path.parts)
temporary = destination.with_suffix('.tmp')
with ZipFile(temporary, 'w', ZIP_DEFLATED) as archive:
    for filename in sorted(set(files)):
        path = root / filename
        if path.is_file():
            archive.write(path, 'grow-your-day/' + filename)
temporary.replace(destination)
print(f'Created {destination.relative_to(root)} ({destination.stat().st_size:,} bytes)')
