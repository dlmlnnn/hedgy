# Grow your day

A local-first planner built with React, Vite and Tailwind CSS.

## Run locally

Install Node.js 22 or newer, then run these commands in this folder:

```sh
npm ci
npm run dev
```

Open the local address printed in the terminal. For a production build:

```sh
npm run build
npm run preview
```

Tasks and completion history are stored in the browser's localStorage using
`team-b-2:` keys. This archive includes the source, not personal tasks stored
in the browser. Google Fonts need an internet connection; system fonts are
used as a fallback. Notification choices are decorative.

## Checks and export

```sh
npm test
npm run build
PLAYWRIGHT_BROWSERS_PATH=node_modules/.cache/ms-playwright npx playwright install chromium
npm run test:mobile
```

To refresh the ZIP offered in Settings (requires Python 3):

```sh
python3 scripts/export-app.py
npm run build
```
