import test from 'node:test'
import assert from 'node:assert/strict'
import { carryQuickTasks, completedThisMonth, itemsForDate, toggleItem, unfinishedItems, deleteOccurrence, appliesOn, dotTypes, plannerItemsForToday, toggleGoalStep, completeWholeGoal, calendarTasksForDate } from './taskSchedule.js'
import { normalizeTask, validateTask, isOverdue } from './taskModel.js'
import { freshTree, migrateTree, rewardCompletion, treeStats } from './treeProgress.js'

test('completion history uses actual completion time, sorts newest first, and includes older entries', () => {
  const today = new Date(2026, 9, 29)
  let items = [
    { id: 'quick', title: 'Call', date: '2026-09-30', done: false },
    { id: 'habit', title: 'Read', type: 'habit', rule: 'daily', startDate: '2026-09-01', completedDates: [] },
  ]
  items = toggleItem(items, 'habit', '2026-09-20', '2026-09-20T12:00:00Z')
  items = toggleItem(items, 'quick', '2026-09-30', '2026-10-28T12:00:00Z')
  items = toggleItem(items, 'habit', '2026-10-29', '2026-10-29T12:00:00Z')
  const restored = JSON.parse(JSON.stringify(items))
  assert.deepEqual(completedThisMonth(restored, today).map(item => item.id), ['habit', 'quick', 'habit'])
  assert.equal(completedThisMonth(restored, new Date(2026, 8, 30)).length, 3)
  assert.equal(restored[1].completionTimes['2026-09-20'], '2026-09-20T12:00:00Z')
})

test('restoring a recurring occurrence preserves other days and never awards growth twice', () => {
  let items = [{ id: 'goal', title: 'Learn', type: 'habit', rule: 'daily', startDate: '2026-10-01', completedDates: [] }]
  let tree = freshTree()
  for (const date of ['2026-10-28', '2026-10-29']) {
    items = toggleItem(items, 'goal', date, `${date}T12:00:00Z`)
    tree = rewardCompletion(tree, { id: 'goal', date })
  }
  const beforeRestore = JSON.stringify(tree)
  items = toggleItem(items, 'goal', '2026-10-29')
  assert.equal(itemsForDate(items, '2026-10-29')[0].completed, false)
  assert.equal(itemsForDate(items, '2026-10-28')[0].completed, true)
  assert.equal(items.length, 1)
  assert.equal(JSON.stringify(tree), beforeRestore)
  items = toggleItem(items, 'goal', '2026-10-29', '2026-10-29T15:00:00Z')
  tree = rewardCompletion(tree, { id: 'goal', date: '2026-10-29' })
  assert.equal(tree.completedCount, 2)
  assert.equal(completedThisMonth(items, new Date(2026, 9, 29)).length, 2)
})

test('legacy completed records remain visible with a date-based timestamp fallback', () => {
  const items = [{ id: 'old', title: 'Old task', date: '2026-10-20', done: true }]
  assert.equal(completedThisMonth(items, new Date(2026, 9, 29)).length, 1)
  assert.equal(completedThisMonth(items, new Date(2026, 10, 1)).length, 1)
  assert.equal(toggleItem(items, 'old', '2026-10-20')[0].completed, false)
})

test('a restored one-off item cannot earn growth again even after rescheduling', () => {
  const tree = rewardCompletion(freshTree(), { id: 'task', date: '2026-10-28', once: true })
  assert.equal(rewardCompletion(tree, { id: 'task', date: '2026-10-29', once: true }).completedCount, 1)
})

test('unfinished quick tasks keep their original scheduled date and remain overdue', () => {
  const items = [
    { id: 'quick', date: '2026-10-29', done: false, priority: true },
    { id: 'done', date: '2026-10-29', done: true },
    { id: 'future', date: '2026-11-10', done: false },
    { id: 'commitment', commitmentId: 'group', date: '2026-10-29', done: false },
    { id: 'habit', type: 'habit', rule: 'daily', startDate: '2026-10-01' },
    { id: 'goal', type: 'goal', deadline: '2026-10-29' },
  ]
  const moved = carryQuickTasks(items, '2026-11-02')
  assert.equal(moved[0].date, '2026-10-29')
  assert.equal(moved[0].priority, true)
  assert.equal(moved.length, items.length)
  assert.deepEqual(moved.slice(1), items.slice(1))
  assert.equal(carryQuickTasks(moved, '2026-11-02'), moved)
  const nextDay = carryQuickTasks(JSON.parse(JSON.stringify(moved)), '2026-11-03')
  assert.equal(nextDay[0].date, '2026-10-29')
})

test('habit schedule requires matching weekdays AND months and emits no duplicates', () => {
  const habit = normalizeTask({ id: 'h', title: 'Practice', type: 'habit', rule: 'schedule', startDate: '2026-01-01', weekdays: [1,3,5], months: [1,2] })
  assert.ok(appliesOn(habit, '2026-01-02'))
  assert.ok(appliesOn(habit, '2026-02-02'))
  assert.ok(!appliesOn(habit, '2026-01-03'))
  assert.ok(!appliesOn(habit, '2026-03-02'))
  const occurrences = unfinishedItems([habit], '2026-01-05')
  assert.deepEqual(occurrences.map(item => item.date), ['2026-01-02', '2026-01-05'])
  const completed = toggleItem([habit], 'h', '2026-01-02', '2026-01-02T12:00:00Z')
  assert.deepEqual(unfinishedItems(JSON.parse(JSON.stringify(completed)), '2026-01-05').map(item => item.date), ['2026-01-05'])
  const edited = [{ ...completed[0], weekdays: [3], months: [2] }]
  assert.equal(completedThisMonth(edited).length, 1)
  const restored = toggleItem(edited, 'h', '2026-01-02')
  assert.ok(unfinishedItems(restored, '2026-01-05').some(item => item.date === '2026-01-02'))
  const removed = deleteOccurrence(completed, 'h', '2026-01-02')
  assert.equal(removed.length, 1)
  assert.equal(completedThisMonth(removed).length, 0)
  assert.ok(appliesOn(removed[0], '2026-01-05'))
  assert.ok(!appliesOn(removed[0], '2026-01-02'))
})

test('daily goal completion stays active until the last step and unfinished items retain date order', () => {
  const goal = normalizeTask({ id: 'g', type: 'goal', title: 'Outcome', startDate: '2026-10-01', deadline: '2026-11-01', steps: [{ id: 's', title: 'Step 1', startDate: '2026-10-10', endDate: '2026-10-20', completed: false }] })
  assert.ok(appliesOn(goal, '2026-10-15'))
  assert.ok(!goal.completed)
  assert.equal(unfinishedItems([goal], '2026-10-30').length, 1)
  const daily = toggleItem([goal], 'g', '2026-10-30', '2026-10-30T12:00:00Z')
  assert.equal(unfinishedItems(daily, '2026-10-30').length, 1)
  assert.equal(plannerItemsForToday(unfinishedItems(daily, '2026-10-30'), '2026-10-30').length, 0)
  assert.equal(plannerItemsForToday(unfinishedItems(daily, '2026-10-31'), '2026-10-31').length, 1)
  assert.equal(completedThisMonth(daily).length, 0)
  const done = toggleGoalStep(daily, 'g', 's', '2026-10-30T13:00:00Z')
  assert.equal(unfinishedItems(done, '2026-10-30').length, 0)
  assert.equal(completedThisMonth(done)[0].date, '2026-11-01')
  assert.equal(toggleItem(done, 'g', '2026-11-01')[0].steps[0].completed, false)
  const tasks = [{ id: 'late', date: '2026-10-30', time: '15:00' }, { id: 'early', date: '2026-10-30', time: '09:00' }, { id: 'old', date: '2026-10-01' }]
  assert.deepEqual(unfinishedItems(tasks, '2026-10-30').map(item => item.id), ['old','early','late'])
  assert.ok(isOverdue(tasks[2], new Date('2026-10-30T10:00:00')))
  assert.ok(!isOverdue(tasks[0], new Date('2026-10-30T10:00:00')))
})

test('goals without steps require whole-goal completion; daily work dates stay separate', () => {
  const goal = normalizeTask({ id: 'g', title: 'Read', type: 'goal', startDate: '2026-11-01', deadline: '2026-11-05', steps: [], stepDates: ['2026-11-01', '2026-11-03'] })
  assert.equal(validateTask(goal), '')
  assert.ok(appliesOn(goal, '2026-11-01'))
  assert.equal(appliesOn(goal, '2026-11-02'), false)
  assert.ok(appliesOn(goal, '2026-11-05'))
  const daily = toggleItem([goal], 'g', '2026-11-01')
  assert.equal(daily[0].completed, false)
  assert.equal(completedThisMonth(daily).length, 0)
  const final = toggleItem(daily, 'g', '2026-11-05')
  assert.equal(final[0].completed, false)
  assert.equal(completedThisMonth(final).length, 0)
  const whole = completeWholeGoal(final, 'g')
  assert.equal(whole[0].completed, true)
  assert.equal(completedThisMonth(whole).length, 1)
})

test('whole-goal completion persists even with unfinished steps and can be restored', () => {
  const goal = normalizeTask({ id: 'g', type: 'goal', title: 'Outcome', startDate: '2026-11-01', deadline: '2026-11-10', steps: [{ id: 's', title: 'Step 1', startDate: '2026-11-01', endDate: '2026-11-10', completed: false }] })
  const done = completeWholeGoal([goal], 'g', '2026-11-02T12:00:00Z')
  assert.equal(normalizeTask(JSON.parse(JSON.stringify(done[0]))).completed, true)
  assert.equal(done[0].steps[0].completed, false)
  const restored = toggleItem(done, 'g', '2026-11-10')
  assert.equal(restored[0].completedAsWhole, false)
  assert.equal(normalizeTask(restored[0]).completed, false)
})

test('completed goals leave future calendar rows and dots while history and other tasks remain', () => {
  const goal = { id: 'g', type: 'goal', title: 'Finished', startDate: '2026-11-01', deadline: '2026-11-10', completed: true, completedAt: '2026-11-03T12:00:00', steps: [], stepDates: ['2026-11-05'] }
  const quick = { id: 'q', type: 'quick', title: 'Call', date: '2026-11-05' }
  const future = calendarTasksForDate([goal, quick], '2026-11-05', '2026-11-03')
  assert.deepEqual(itemsForDate(future, '2026-11-05').map(item => item.id), ['q'])
  assert.equal(dotTypes(future, '2026-11-05').goalStep, false)
  assert.equal(dotTypes(future, '2026-11-05').quick, true)
  assert.equal(calendarTasksForDate([goal], '2026-11-01', '2026-11-03').length, 1)
  assert.equal(calendarTasksForDate([goal], '2026-11-03', '2026-11-03').length, 1)
  assert.equal(calendarTasksForDate(toggleItem([goal], 'g', '2026-11-10'), '2026-11-05', '2026-11-03').length, 1)
})

test('validation rejects empty schedules, reversed goal ranges and steps outside the goal', () => {
  assert.ok(validateTask({ type: 'habit', title: 'Read', startDate: '2026-01-01', weekdays: [], months: [] }))
  assert.equal(validateTask({ type: 'habit', title: 'Read', startDate: '2026-01-01', weekdays: [1], months: [1] }), '')
  assert.ok(validateTask({ type: 'goal', title: 'Learn', startDate: '2026-02-01', deadline: '2026-01-01' }))
  assert.ok(validateTask({ type: 'goal', title: 'Learn', startDate: '2026-01-01', deadline: '2026-02-01', steps: [{ title: 'Do', startDate: '2026-01-01', endDate: '2026-03-01' }] }))
  assert.ok(validateTask({ type: 'quick', title: 'Do', date: '' }))
  assert.equal(normalizeTask({ id: 'old', title: 'Appointment', commitmentId: 'group', date: '2026-01-01', done: true }).type, 'commitment')
})

test('only overdue items glow; ongoing, future and completed items stay unlit', () => {
  const now = new Date('2026-10-30T12:00:00')
  assert.equal(isOverdue({ date: '2026-10-30' }, now), false)
  assert.equal(isOverdue({ date: '2026-10-31' }, now), false)
  assert.equal(isOverdue({ date: '2026-10-30', time: '18:00' }, now), false)
  assert.equal(isOverdue({ date: '2026-10-30', time: '09:00' }, now), true)
  assert.equal(isOverdue({ date: '2026-10-29' }, now), true)
  assert.equal(isOverdue({ date: '2026-10-29', completed: true }, now), false)
  assert.equal(isOverdue({ type: 'goal', startDate: '2026-10-01', deadline: '2026-10-30' }, now), false)
  assert.equal(isOverdue({ type: 'goal', startDate: '2026-10-01', deadline: '2026-11-10' }, now), false)
  assert.equal(isOverdue({ type: 'goal', deadline: '2026-10-29' }, now), true)
})

test('habit schedule advances across midnight and individual deletion preserves the sequence', () => {
  let tasks = [normalizeTask({ id: 'h', title: 'Read', type: 'habit', rule: 'schedule', startDate: '2026-10-30', weekdays: [5,6], months: [10,11] })]
  tasks = toggleItem(tasks, 'h', '2026-10-30', '2026-10-30T10:00:00Z')
  assert.equal(unfinishedItems(tasks, '2026-10-30')[0].date, '2026-10-31')
  assert.equal(unfinishedItems(tasks, '2026-10-31')[0].date, '2026-10-31')
  tasks = deleteOccurrence(tasks, 'h', '2026-10-31')
  assert.equal(unfinishedItems(tasks, '2026-10-31')[0].date, '2026-11-06')
  assert.equal(completedThisMonth(tasks).length, 1)
  assert.equal(tasks.length, 1)
  assert.deepEqual(JSON.parse(JSON.stringify(tasks))[0].excludedDates, ['2026-10-31'])
})

test('scheduled commitments use habit-style options with independent completion and green dots', () => {
  const commitment = normalizeTask({ id: 'c', title: 'Appointment', type: 'commitment', rule: 'schedule', startDate: '2026-10-30', weekdays: [5], months: [10,11], time: '10:00' })
  assert.equal(validateTask(commitment), '')
  assert.ok(appliesOn(commitment, '2026-10-30'))
  assert.ok(appliesOn(commitment, '2026-11-06'))
  assert.ok(!appliesOn(commitment, '2026-12-04'))
  const completed = JSON.parse(JSON.stringify(toggleItem([commitment], 'c', '2026-10-30')))
  assert.ok(itemsForDate(completed, '2026-10-30')[0].completed)
  assert.ok(!itemsForDate(completed, '2026-11-06')[0].completed)
  assert.equal(unfinishedItems(completed, '2026-10-30')[0].date, '2026-11-06')
  assert.equal(completedThisMonth(completed).length, 1)
  assert.ok(dotTypes(completed, '2026-11-06').commitment)
  assert.ok(!dotTypes(completed, '2026-11-06').habit)
  assert.equal(deleteOccurrence(completed, 'c', '2026-11-06').length, 1)
  assert.ok(!appliesOn(deleteOccurrence(completed, 'c', '2026-11-06')[0], '2026-11-06'))
  assert.ok(validateTask({ ...commitment, weekdays: [] }))
})

test('habit and commitment intervals continue across months without changing phase', () => {
  for (const type of ['habit', 'commitment']) {
    const item = normalizeTask({ id: type, type, title: 'Repeat', rule: 'schedule', cadence: 'interval', interval: 3, startDate: '2026-10-30', weekdays: [], months: [10,11,1] })
    assert.equal(validateTask(item), '')
    assert.ok(appliesOn(item, '2026-10-30'))
    assert.ok(appliesOn(item, '2026-11-02'))
    assert.ok(!appliesOn(item, '2026-11-01'))
    assert.ok(!appliesOn(item, '2026-12-02'))
    assert.ok(appliesOn(item, '2027-01-01'))
    assert.ok(validateTask({ ...item, interval: 1 }))
    assert.ok(validateTask({ ...item, interval: 2.5 }))
  }
})

test('calendar-picked commitment dates override repeat rules and complete independently', () => {
  const commitment = normalizeTask({ id: 'c', type: 'commitment', title: 'Meet', rule: 'schedule', cadence: 'dates', startDate: '2026-10-30', dates: ['2026-10-30', '2026-12-03'], weekdays: [], months: [] })
  assert.equal(validateTask(commitment), '')
  assert.ok(appliesOn(commitment, '2026-10-30'))
  assert.ok(appliesOn(commitment, '2026-12-03'))
  assert.ok(!appliesOn(commitment, '2026-10-31'))
  const done = toggleItem([commitment], 'c', '2026-10-30')
  assert.equal(unfinishedItems(done, '2026-10-30')[0].date, '2026-12-03')
  assert.equal(completedThisMonth(done).length, 1)
  assert.ok(validateTask({ ...commitment, dates: [] }))
})

test('the tree is always fully grown and apples match unfinished daily occurrences without a cap', () => {
  const day = '2026-10-29'
  const tree = freshTree()
  assert.equal(treeStats(tree).stage, 4)
  assert.equal(treeStats({ ...tree, completedCount: 300 }).scale, 1)
  let tasks = Array.from({ length: 20 }, (_, index) => ({ id: `task-${index}`, date: day, done: false }))
  const appleCount = () => treeStats({ ...tree, applesOnTree: itemsForDate(tasks, day).filter(item => !item.completed).length }).apples
  assert.equal(appleCount(), 20)
  tasks = toggleItem(tasks, 'task-0', day)
  assert.equal(appleCount(), 19)
  tasks.push({ id: 'new', date: day, done: false })
  assert.equal(appleCount(), 20)
  tasks = toggleItem(tasks, 'task-0', day)
  assert.equal(appleCount(), 21)
  tasks = tasks.filter(item => item.id !== 'new')
  assert.equal(appleCount(), 20)
  tasks.push({ id: 'habit', type: 'habit', rule: 'daily', startDate: day, completedDates: [] })
  assert.equal(appleCount(), 21)
  tasks = toggleItem(tasks, 'habit', day)
  assert.equal(appleCount(), 20)
  const legacy = migrateTree({ completedCount: 5, applesOnTree: 14, harvests: 3, harvestAt: 1, credited: ['old@2026-10-28'] })
  assert.equal(treeStats(legacy).stage, 4)
  assert.equal('harvestAt' in legacy, false)
  assert.equal('applesOnTree' in legacy, false)
  assert.deepEqual(legacy.credited, ['old@2026-10-28'])
})
