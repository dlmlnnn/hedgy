export function calendarMonths(start, count) {
  let offset = 0
  return Array.from({ length: count }, (_, index) => {
    const serial = start + index
    const year = Math.floor(serial / 12), month = serial % 12
    const days = Array.from({ length: new Date(year, month + 1, 0).getDate() }, (_, day) => new Date(year, month, day + 1, 12))
    const leading = (days[0].getDay() + 6) % 7
    const height = 32 + Math.ceil((leading + days.length) / 7) * 36
    const result = { serial, year, month, days, leading, offset, height }
    offset += height
    return result
  })
}

export function visibleCalendarMonth(months, scrollTop) {
  const position = Math.max(0, scrollTop - 16)
  return months.find(month => month.offset + month.height > position) || months.at(-1)
}
