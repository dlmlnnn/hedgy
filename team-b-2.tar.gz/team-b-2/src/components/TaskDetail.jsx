import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import TaskEditor from './TaskEditor'
import UnifiedTaskForm from './UnifiedTaskForm'
import DeleteTaskDialog from './DeleteTaskDialog'
import { isRecurringTask, taskType } from './taskModel'
import { dateKey, deadlineMessage } from './calendarDates'
import { appliesOn } from './taskSchedule'

const readableDate = date => date ? new Date(`${date}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''
const weekdayNames = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']

function upcomingDates(task, today, limit = 5) {
  if (!isRecurringTask(task) && task.type !== 'goal') return task.date ? [task.date] : []
  const applies = date => date >= today && appliesOn(task, date) && !task.completedDates?.includes(date)
  if (task.cadence === 'dates' || (isRecurringTask(task) && !['daily', 'weekdays', 'schedule'].includes(task.rule))) {
    return [...new Set([...(task.dates || []), ...(task.restoredDates || [])])].filter(applies).sort().slice(0, limit)
  }
  const first = new Date(`${[today, task.startDate || today].sort().at(-1)}T12:00:00`)
  const end = new Date(first)
  end.setFullYear(end.getFullYear() + 5)
  const last = task.type === 'goal' ? task.deadline : dateKey(end)
  const dates = []
  for (const day = new Date(first); dates.length < limit && dateKey(day) <= last; day.setDate(day.getDate() + 1)) {
    const date = dateKey(day)
    if (applies(date)) dates.push(date)
  }
  return dates
}

function compactDates(dates) {
  const months = new Map()
  for (const date of dates) {
    const month = date.slice(0, 7)
    if (!months.has(month)) months.set(month, [])
    months.get(month).push(Number(date.slice(-2)))
  }
  const format = new Intl.DateTimeFormat('en-US', { month: 'short' })
  return [...months].map(([month, days]) => `${format.format(new Date(`${month}-01T12:00:00`)).toLowerCase()} ${days.join(', ')}`).join('  ')
}

function recurrenceLabel(task) {
  if (!isRecurringTask(task)) return ''
  const interval = task.recurrencePattern?.interval || (task.cadence === 'interval' ? task.interval : null)
  if (interval) return `Every ${interval} days`
  const weekdays = task.recurrencePattern?.weekdays || (task.cadence !== 'dates' ? task.weekdays : null) || []
  if (weekdays.length === 2 && weekdays.includes(6) && weekdays.includes(7)) return 'Weekends'
  if (task.rule === 'daily' || weekdays.length === 7) return 'Every day'
  return [...weekdays].sort().map(day => weekdayNames[day - 1]).join(', ')
}

export default function TaskDetail({ task, lists = [], occurrenceDate, inline = false, onOverlayChange, onClose, onDelete, onSave, onCalendarOptions }) {
  const [deleting, setDeleting] = useState(false)
  const [editing, setEditing] = useState(false)
  const card = useRef(null)
  useEffect(() => { if (!editing && !deleting) card.current?.focus({ preventScroll: true }) }, [editing, deleting])
  const dates = upcomingDates(task, dateKey(new Date()), inline ? 9 : 5)
  const repeat = recurrenceLabel(task)
  function overlay(content) {
    return inline ? createPortal(<div className="absolute inset-0 z-[60]" onClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}>{content}</div>, document.querySelector('.app-stage')) : content
  }
  function dismissEdit() { setEditing(false); onOverlayChange?.(false) }
  function dismissDelete() { setDeleting(false); onOverlayChange?.(false) }
  function requestDelete() { setEditing(false); setDeleting(true); onOverlayChange?.(true) }
  if (editing) {
    const Editor = taskType(task) === 'quick' ? UnifiedTaskForm : TaskEditor
    return overlay(<Editor task={task} lists={lists} onClose={dismissEdit} onSave={updated => { dismissEdit(); onSave(updated) }} onDelete={requestDelete}
      onShare={onCalendarOptions ? () => { dismissEdit(); onCalendarOptions() } : undefined} />)
  }
  const inlineAction = 'flex min-h-8 items-center justify-center rounded-lg border border-[#D8DBD8] bg-[#EDF0ED] px-2.5 text-xs font-medium text-[#515651] hover:bg-[#E4E7E4] focus-visible:outline-2 focus-visible:outline-[#4F7A66]'
  const editTask = () => { setEditing(true); onOverlayChange?.(true) }
  const calendarIcon = <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 11h18"/></svg>
  const content = inline ? <>
    {(task.time || repeat) && <p className="text-xs leading-4 text-[#515651]">{[task.time, repeat].filter(Boolean).join(' · ')}</p>}
    {dates.length > 0 && <div tabIndex={0} aria-label="Next scheduled dates" className="task-scroll overflow-x-auto whitespace-pre py-1.5 text-xs leading-5 text-[#606760] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">{compactDates(dates)}</div>}
    <div className="mt-1 flex items-center justify-between gap-2">
      <button type="button" onClick={requestDelete} className={inlineAction}>Delete</button>
      <div className="flex items-center gap-1">
        {onCalendarOptions && <button type="button" aria-label="Calendar options" title="Calendar options" onClick={onCalendarOptions} className={inlineAction}>{calendarIcon}</button>}
        <button type="button" onClick={editTask} className={inlineAction}>Edit</button>
      </div>
    </div>
  </> : <>
        {!inline && <h2 className="break-words text-lg font-semibold! [font-family:inherit]! leading-snug">{task.title}</h2>}
        {(task.time || repeat) && <p className="mt-1 text-sm text-[#49574D]">{[task.time, repeat].filter(Boolean).join(' · ')}</p>}
        <div className="mt-3 text-xs text-[#49574D]">
          <p className="font-semibold">{dates.length === 1 && !isRecurringTask(task) && task.type !== 'goal' ? 'Scheduled date' : 'Next scheduled dates'}</p>
          {dates.length ? <ul className="mt-1 flex flex-wrap gap-1.5">
            {dates.map(date => <li key={date} className="rounded-md bg-(--control-surface) px-2 py-1">{readableDate(date)}</li>)}
          </ul> : <p className="mt-1">No upcoming dates.</p>}
        </div>
        {task.type === 'goal' && <p className="mt-2 text-xs text-[#49574D]">{deadlineMessage(task.deadline)}</p>}
        {task.description && <p className="mt-3 whitespace-pre-wrap break-words text-sm leading-relaxed">{task.description}</p>}
        <div className="mt-4 flex items-center justify-between gap-2">
          <button type="button" onClick={requestDelete} className="min-h-11 rounded-full border border-[#4F7A66] px-4 text-[13px] font-semibold">Delete</button>
          {onCalendarOptions && <button type="button" aria-label="Calendar options" title="Calendar options" onClick={onCalendarOptions} className="flex h-11 w-11 items-center justify-center rounded-full border border-[#6E9A82]/40 text-[#4F7A66]"><svg aria-hidden="true" width="20" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 11h18"/></svg></button>}
          <button type="button" onClick={editTask} className="min-h-11 rounded-full bg-[#4F7A66] px-5 text-[13px] font-semibold text-[#F8F4E8]">Edit</button>
        </div>
    </>
  function handleKeys(event) {
    if (event.key === 'Escape') { event.stopPropagation(); onClose() }
  }
  return <>
    {inline ? <section aria-label={`Details for ${task.title}`} onKeyDown={handleKeys}>{content}</section>
      : <div ref={card} role="dialog" aria-modal={!deleting} aria-hidden={deleting} inert={deleting} aria-label="Task details" tabIndex={-1} onClick={onClose} onKeyDown={handleKeys} className="planner-modal-backdrop absolute inset-0 z-50 flex items-center justify-center outline-none">
        <div onClick={event => event.stopPropagation()} className="task-scroll max-h-[90%] w-[84%] max-w-sm overflow-y-auto rounded-[28px] bg-[#F8F4E8] [--surface:#F4F6F3] p-4 text-[#2E2A25] shadow-xl">{content}</div>
      </div>}
    {deleting && overlay(<DeleteTaskDialog task={task} allowOccurrence={Boolean(occurrenceDate)} onClose={dismissDelete} onDelete={whole => { dismissDelete(); onDelete(whole) }} />)}
  </>
}
