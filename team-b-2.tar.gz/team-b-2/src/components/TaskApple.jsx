import { isOverdue, taskType } from './taskModel'
import { useId } from 'react'
export const taskAccents = { quick: '#F2B28C', commitment: '#B6C885', habit: '#78B99A', goal: '#E9C46A' }

export const applePalette = { Green: '#78B99A', Lime: '#B6C885', Peach: '#F2B28C', Gold: '#E9C46A' }
export const taskAppleColor = task => Object.hasOwn(applePalette, task.appleColor) ? applePalette[task.appleColor] : taskAccents[taskType(task)]

export default function TaskApple({ task, size = 20 }) {
  const color = taskAppleColor(task)
  const glowing = isOverdue(task)
  const haloId = useId().replace(/:/g, '')
  return <svg aria-hidden="true" style={{ '--apple-glow': color }} className={glowing ? 'priority-apple-glow' : undefined} width={size} height={size * 1.1} viewBox="0 0 24 26" fill="none">
    {glowing && <><defs><radialGradient id={haloId}><stop offset="45%" stopColor="white" stopOpacity=".65" /><stop offset="100%" stopColor="white" stopOpacity="0" /></radialGradient></defs><circle className="apple-light-halo" cx="12" cy="14" r="13" fill={`url(#${haloId})`} /></>}
    <path d="M12 8C6 4 1 10 4 18c2 5 5 6 8 4 3 2 7 0 9-6 2-7-3-12-9-8Z" fill={color} />
    <path d="M12 8c-1-2 0-4 1-6" stroke="#B5763C" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M13 6c0-3 3-4 6-3-1 3-3 4-6 3Z" fill={color} opacity=".8" />
  </svg>
}
