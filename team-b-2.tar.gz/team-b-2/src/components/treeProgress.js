const whole = value => Number.isFinite(value) ? Math.max(0, Math.round(value)) : 0

export function freshTree() {
  return { completedCount: 0, credited: [] }
}

export function migrateTree(stored) {
  if (!stored || typeof stored !== 'object' || Array.isArray(stored)) return freshTree()
  const percentage = stored.percentage ?? stored.growthPercentage ?? stored.growthProgress ?? stored.progress ?? 0
  const tree = {
    completedCount: whole(stored.completedCount ?? stored.completions ?? Math.min(100, Math.max(0, percentage)) / 100 * 45),
    credited: Array.isArray(stored.credited) ? stored.credited : [],
  }
  return tree
}

export function rewardCompletion(next, { id, date, once = false }) {
  const key = `${id}@${date}`
  if (next.credited.includes(key) || (once && next.credited.some(entry => entry.startsWith(`${id}@`)))) return next
  return {
    ...next,
    completedCount: next.completedCount + 1,
    credited: [...next.credited, key],
  }
}

export function treeStats(tree) {
  return { stage: 4, scale: 1, apples: whole(tree.applesOnTree) }
}
