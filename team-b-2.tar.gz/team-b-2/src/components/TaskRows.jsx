import { useLayoutEffect, useState } from 'react'
import TaskApple from './TaskApple'

function InlineTaskAccordion({ open, renderContent }) {
  const [keepContent, setKeepContent] = useState(false)
  useLayoutEffect(() => {
    if (open) { setKeepContent(true); return }
    const duration = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 300
    const timer = setTimeout(() => setKeepContent(false), duration)
    return () => clearTimeout(timer)
  }, [open])
  return <div inert={!open} aria-hidden={!open}
    className={`grid transition-[grid-template-rows,opacity] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none ${open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
    <div className="min-h-0 overflow-hidden">
      <div className={`pb-2 pl-[3.25rem] pr-2 transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none ${open ? 'translate-y-0' : '-translate-y-1.5'}`}>
        {(open || keepContent) && renderContent()}
      </div>
    </div>
  </div>
}

export default function TaskRows({ items, onEdit, onComplete, onShare, onStep, completed = false, onDelete, appleSize, embedded = false, detailKey, renderDetail }) {
  const [expanded, setExpanded] = useState([])
  return <ul className={embedded ? 'px-2' : 'task-scroll h-full overflow-y-auto overscroll-y-contain px-2 pb-[80px]'}>
    {!items.length && <li className={`flex items-center justify-center text-center text-sm text-[#59554D] ${embedded ? 'py-3' : 'h-full'}`}>{completed ? 'No completed tasks yet' : 'No unfinished tasks.'}</li>}
    {items.map(item => <li key={`${item.id}@${item.date}`} className="planner-task-row border-b border-[#6E9A82]/40 py-3 last:border-0">
      <div className="flex min-h-[58px] items-center gap-2">
        <button type="button" aria-label={`${item.completed ? 'Restore' : 'Complete'} ${item.title}`} onClick={() => onComplete(item)} className="flex h-11 w-11 shrink-0 items-center justify-center"><span className={`flex h-6 w-6 items-center justify-center rounded-full border-[1.5px] border-[#4F7A66] ${item.completed ? 'bg-[#8FB39A] text-white' : ''}`}>{item.completed ? '✓' : ''}</span></button>
        {appleSize && <TaskApple task={item} size={appleSize} />}
        <button type="button" aria-expanded={renderDetail ? detailKey === `${item.id}@${item.date}` : undefined} onClick={event => onEdit(item, event)} className="min-h-11 min-w-0 flex-1 text-left"><span className="planner-task-title block truncate text-[14px] font-semibold">{item.title}</span>{completed && <span className="text-[10px] text-[#59554D]">Completed {new Date(item.completedAt).toLocaleString()}</span>}</button>
        {completed && <button type="button" onClick={() => onDelete(item)} aria-label={`Delete ${item.title}`} className="h-11 w-11 text-xl">×</button>}
      </div>
      {renderDetail && <InlineTaskAccordion open={detailKey === `${item.id}@${item.date}`} renderContent={() => renderDetail(item)} />}
      {item.type === 'goal' && item.steps?.length > 0 && <>
        <button type="button" aria-expanded={expanded.includes(item.id)} onClick={() => setExpanded(previous => previous.includes(item.id) ? previous.filter(id => id !== item.id) : [...previous, item.id])} className="ml-10 min-h-11 rounded-full bg-[#E9C46A]/40 px-4 text-[12px] font-semibold text-[#695028]">Steps ({item.steps?.length || 0})</button>
        {expanded.includes(item.id) && <ul className="ml-10 mt-2 rounded-xl bg-[#E9C46A]/15 p-2">{(item.steps || []).map(step => <li key={step.id} className="flex items-center gap-2 py-2"><button type="button" aria-label={`${step.completed ? 'Restore' : 'Complete'} ${step.title}`} onClick={() => onStep(item, step)} className="flex h-11 w-11 shrink-0 items-center justify-center"><span className={`flex h-6 w-6 items-center justify-center rounded-full border border-[#8F773B] ${step.completed ? 'bg-[#8FB39A]' : ''}`}>{step.completed ? '✓' : ''}</span></button><div className="min-w-0"><p className="break-words text-[13px]">{step.title}</p><p className="text-[10px] text-[#695028]">{step.startDate} – {step.endDate}</p></div></li>)}</ul>}
      </>}
    </li>)}
  </ul>
}
