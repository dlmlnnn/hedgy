import { useEffect, useRef, useState } from 'react'
import './TreeLeaves.css'

export default function TreeLeaves({ tap }) {
  const [batches, setBatches] = useState([])
  const timers = useRef(new Set())
  useEffect(() => {
    if (!tap || window.matchMedia('(prefers-reduced-motion: reduce)').matches || Math.random() >= .25) return
    setBatches(previous => [...previous, tap])
    const timer = setTimeout(() => {
      setBatches(previous => previous.filter(id => id !== tap))
      timers.current.delete(timer)
    }, 6500)
    timers.current.add(timer)
  }, [tap])
  useEffect(() => () => timers.current.forEach(clearTimeout), [])
  return <svg aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-(--planner-header-height) w-full overflow-visible" viewBox="0 0 393 250" preserveAspectRatio="none">
    {batches.flatMap(id => [0, 1].map(index => <g key={`${id}-${index}`} className="tree-falling-leaf" style={{ '--leaf-x': `${130 + index * 9}px`, '--leaf-y': `${94 + index * 15}px`, '--leaf-mid-x': `${180 + index * 16}px`, '--leaf-mid-y': `${170 + index * 12}px`, '--leaf-end-x': `${202 + index * 19}px`, '--leaf-end-y': `${224 + index * 3}px`, animationDelay: `${index * .35}s`, animationDuration: `${5.2 + index * .6}s` }}>
      <path d="M-6 0Q-1-6 7-1Q3 5-6 0Z" fill={index ? '#8D9A72' : '#6E8258'} stroke="#476648" strokeOpacity=".5" strokeWidth=".5" />
      <path d="m-5 0 9-1" fill="none" stroke="#F3EEDF" strokeOpacity=".45" strokeWidth=".5" />
    </g>))}
  </svg>
}
