import { useState } from 'react'

export default function CreateFolderList({ onCreate }) {
  const [editing, setEditing] = useState(false)
  const [title, setTitle] = useState('')
  const [error, setError] = useState('')
  return <div className="grid h-full place-items-center px-6 pb-16">
    {editing ? <form onSubmit={event => {
      event.preventDefault()
      const message = onCreate(title.trim())
      setError(message)
      if (!message) { setEditing(false); setTitle('') }
    }} className="grid w-full max-w-60 gap-2">
      <input autoFocus aria-label="List title" placeholder="List title" maxLength={40} value={title} onChange={event => { setTitle(event.target.value); setError('') }} className="min-h-11 rounded-xl border border-[#839384] px-3 text-base outline-[#4F7A66]" />
      {error && <p role="alert" className="text-xs text-[#783E38]">{error}</p>}
      <button type="submit" disabled={!title.trim()} className="min-h-10 rounded-full bg-[#3D6653] text-sm font-semibold text-white">Create list</button>
    </form> : <button type="button" onClick={() => setEditing(true)} className="min-h-11 rounded-xl px-3 text-sm font-medium text-[#405043] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">Create a list</button>}
  </div>
}
