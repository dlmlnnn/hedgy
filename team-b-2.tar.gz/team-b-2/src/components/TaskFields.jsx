import { useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import DateRangePicker from './DateRangePicker'
import Calendar from './Calendar'
import NotificationPicker from './NotificationPicker'
import { isRecurringTask } from './taskModel'

const field = 'mt-1 min-h-11 w-full rounded-[15px] border border-[#6E9A82]/30 bg-(--control-surface) px-3 py-2 text-[14px] outline-[#4F7A66]'
const chip = 'min-h-11 rounded-xl border border-[#6E9A82]/30 px-2 text-[11px] font-semibold'
export default function TaskFields({ draft, onChange }) {
  const [range, setRange] = useState(null)
  const [calendarOpen, setCalendarOpen] = useState(false)
  const [goalDatesOpen, setGoalDatesOpen] = useState(false)
  const [dateField, setDateField] = useState(null)
  const dateTrigger = useRef(null)
  const scheduledField = ['goal', 'habit', 'commitment'].includes(draft.type) ? 'startDate' : 'date'
  const dateLabel = scheduledField === 'startDate' ? 'Starting date' : 'Date'
  function closeDatePicker() {
    setDateField(null)
    requestAnimationFrame(() => dateTrigger.current?.focus({ preventScroll: true }))
  }
  const patch = (key, value) => onChange({ ...draft, [key]: value })
  const toggle = (key, value) => patch(key, draft[key]?.includes(value) ? draft[key].filter(item => item !== value) : [...(draft[key] || []), value].sort((a, b) => a - b))
  return <>
    <input autoFocus required aria-label="Task title" placeholder="Task title" maxLength={160} value={draft.title} onChange={event => patch('title', event.target.value)} className={`${field} font-sans font-normal placeholder:font-normal placeholder:text-[#8A867C]`} />
    <label className="text-[12px] font-semibold">Description (optional)<textarea value={draft.description || ''} onChange={event => patch('description', event.target.value)} className={`${field} min-h-[80px]`} /></label>
    <div className="text-[12px] font-semibold"><span>{dateLabel}</span><button ref={dateTrigger} type="button" aria-label={dateLabel} aria-haspopup="dialog" onClick={() => { document.activeElement?.blur(); setDateField(scheduledField) }} className={`${field} flex items-center justify-between gap-2 text-left font-normal`}>
      <span>{draft.scheduledDates?.length > 1 && draft.type === 'quick' ? `${draft.scheduledDates.length} dates selected` : draft[scheduledField] ? new Date(`${draft[scheduledField]}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Choose a date'}</span>
      <svg aria-hidden="true" width="18" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M7 3v4m10-4v4M3 11h18" /></svg>
    </button></div>
    {draft.type !== 'goal' && <label className="text-[12px] font-semibold">Time (optional)<input type="time" value={draft.time || ''} onChange={event => patch('time', event.target.value)} className={field} /></label>}
    {['habit', 'commitment'].includes(draft.type) && <>
      <fieldset><legend className="mb-2 text-[13px] font-semibold">Weekdays</legend>
        <div className="mb-2 flex gap-2">
          <button type="button" onClick={() => onChange({ ...draft, cadence: 'weekdays', weekdays: [1,2,3,4,5,6,7] })} className={chip}>Every day</button>
          <button type="button" aria-expanded={draft.cadence === 'interval'} onClick={() => onChange({ ...draft, cadence: draft.cadence === 'interval' ? 'weekdays' : 'interval', interval: draft.interval || 3 })} className={chip}>Every <span style={{ color: draft.type === 'commitment' ? '#63803E' : '#387F69' }}>x</span> days</button>
          <button type="button" aria-haspopup="dialog" onClick={() => { document.activeElement?.blur(); setCalendarOpen(true) }} className={chip}>Choose dates{draft.cadence === 'dates' && ` (${draft.dates?.length || 0})`}</button>
        </div>
        {draft.cadence === 'dates' && <p className="mb-2 text-[12px] text-[#59554D]">Using {draft.dates?.length || 0} chosen dates. Repeat shortcuts can replace this selection.</p>}
        {draft.cadence === 'interval' ? <label className="mb-2 flex min-h-11 items-center justify-center gap-3 text-[13px]">Every<input aria-label="Repeat interval in days" type="number" inputMode="numeric" min="2" max="30" required value={draft.interval ?? ''} onChange={event => patch('interval', event.target.value === '' ? '' : Number(event.target.value))} className="h-11 w-16 rounded-xl border border-[#6E9A82]/40 text-center outline-[#4F7A66]" />days</label> : null}
        <div className="grid grid-cols-7 gap-1">{['mon','tue','wed','thu','fri','sat','sun'].map((name, index) => <button key={name} type="button" aria-pressed={!['interval', 'dates'].includes(draft.cadence) && (draft.weekdays?.includes(index + 1) || false)} onClick={() => onChange({ ...draft, cadence: 'weekdays', weekdays: draft.weekdays?.includes(index + 1) ? draft.weekdays.filter(day => day !== index + 1) : [...(draft.weekdays || []), index + 1].sort((a,b) => a-b) })} className={chip}>{name}</button>)}</div>
      </fieldset>
      <fieldset><legend className="mb-2 text-[13px] font-semibold">Months</legend><button type="button" onClick={() => patch('months', Array.from({ length: 12 }, (_, i) => i + 1))} className={`${chip} mb-2`}>All year</button><div className="grid grid-cols-4 gap-1">{Array.from({ length: 12 }, (_, index) => <button key={index} type="button" aria-pressed={draft.months?.includes(index + 1) || false} onClick={() => toggle('months', index + 1)} className={chip}>{new Date(2026, index, 1).toLocaleDateString('en-US', { month: 'short' })}</button>)}</div></fieldset>
    </>}
    {isRecurringTask(draft) && <fieldset className="min-w-0">
      <legend className="mb-2 text-sm font-semibold">Steps</legend>
      {draft.steps.map((step, index) => <div key={step.id} className="mb-2 flex items-center gap-2">
        <input aria-label={`Step ${index + 1} title`} required maxLength={160} value={step.title} onChange={event => patch('steps', draft.steps.map(item => item.id === step.id ? { ...item, title: event.target.value } : item))} className={`${field} min-w-0`} />
        <button type="button" aria-label={`Remove step ${index + 1}`} onClick={() => patch('steps', draft.steps.filter(item => item.id !== step.id))} className={`${chip} min-w-11 shrink-0`}>×</button>
      </div>)}
      <button type="button" onClick={() => patch('steps', [...draft.steps, { id: crypto.randomUUID(), title: '', completed: false }])} className={chip}>+ Add step</button>
    </fieldset>}
    {draft.type === 'goal' && <>
      <label className="text-[12px] font-semibold">End date<input required type="date" min={draft.startDate} value={draft.deadline} onChange={event => patch('deadline', event.target.value)} className={field} /></label>
      <label className="text-[12px] font-semibold">Time (optional)<input type="time" value={draft.time || ''} onChange={event => patch('time', event.target.value)} className={field} /></label>
      <button type="button" onClick={() => { document.activeElement?.blur(); setGoalDatesOpen(true) }} className={chip}>{draft.stepDates?.length ? `Work dates (${draft.stepDates.length})` : 'Choose work dates (optional)'}</button>
      <fieldset><legend className="mb-2 text-[14px] font-semibold">Add Steps <span className="text-[11px] font-normal text-[#8A867C]">(optional)</span></legend>
        {(draft.steps || []).map((step, index) => <div key={step.id} className="mb-3 rounded-xl border border-[#D9A23A]/40 bg-[#E9C46A]/10 p-3">
          <input aria-label={`Step ${index + 1} title`} required value={step.title} onChange={event => patch('steps', draft.steps.map(s => s.id === step.id ? { ...s, title: event.target.value } : s))} className={field} />
          <div className="mt-2 flex gap-2"><button type="button" onClick={() => setRange(step.id)} className={`${chip} flex-1`}>{step.startDate} – {step.endDate}</button><button type="button" aria-label={`Remove ${step.title}`} onClick={() => patch('steps', draft.steps.filter(s => s.id !== step.id))} className={chip}>×</button></div>
        </div>)}
        <button type="button" onClick={() => patch('steps', [...(draft.steps || []), { id: crypto.randomUUID(), title: `Step ${(draft.steps || []).length + 1}`, startDate: draft.startDate, endDate: draft.deadline, completed: false }])} className={chip}>+ Add step</button>
      </fieldset>
    </>}
    {range && <DateRangePicker start={range === 'goal' ? draft.startDate : draft.steps.find(s => s.id === range).startDate} end={range === 'goal' ? draft.deadline : draft.steps.find(s => s.id === range).endDate} blue={range !== 'goal'} onClose={() => setRange(null)} onSave={(start, end) => { onChange(range === 'goal' ? { ...draft, startDate: start, deadline: end } : { ...draft, steps: draft.steps.map(s => s.id === range ? { ...s, startDate: start, endDate: end } : s) }); setRange(null) }} />}
    {calendarOpen && createPortal(<div className="absolute inset-0 z-[70]" onClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}><Calendar mode="multi" showHelpers={false} tasks={[]} selectionType="commitment" initialDate={draft.startDate} initialDates={draft.dates || []} confirmLabel="Apply dates" multiLabel="Choose commitment dates" onClose={() => setCalendarOpen(false)} onPick={dates => { onChange({ ...draft, cadence: 'dates', rule: 'schedule', dates, startDate: dates[0] }); setCalendarOpen(false) }} /></div>, document.querySelector('.app-stage'))}
    <NotificationPicker value={draft.notification} onChange={value => patch('notification', value)} />
    {goalDatesOpen && createPortal(<div className="absolute inset-0 z-[70]" onClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}><Calendar mode="multi" tasks={[]} selectionType="goal" initialDate={draft.startDate} initialDates={draft.stepDates || []} confirmLabel="Apply work dates" multiLabel="Choose goal work dates" allowEmpty onClose={() => setGoalDatesOpen(false)} onPick={dates => { patch('stepDates', dates.filter(date => date >= draft.startDate && date <= draft.deadline)); setGoalDatesOpen(false) }} /></div>, document.querySelector('.app-stage'))}
    {dateField && createPortal(<div className="absolute inset-0 z-[70]" onClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}><Calendar mode="pick" allowMultiGesture tasks={[]} selectionType={draft.type} initialDate={draft[dateField]} initialDates={draft.type === 'quick' ? draft.scheduledDates || [] : draft.cadence === 'dates' ? draft.dates || [] : []} confirmLabel="Apply date" onClose={closeDatePicker} onPick={selection => { const dates = Array.isArray(selection) ? selection : [selection]; const date = dates[0]; onChange({ ...draft, [dateField]: date, ...(draft.type === 'quick' ? { scheduledDates: dates, originalDate: undefined, rolledOver: false } : Array.isArray(selection) && draft.type === 'goal' ? { stepDates: dates, deadline: draft.deadline < dates.at(-1) ? dates.at(-1) : draft.deadline } : Array.isArray(selection) ? { cadence: 'dates', rule: 'schedule', dates } : {}) }); closeDatePicker() }} /></div>, document.querySelector('.app-stage'))}
  </>
}
