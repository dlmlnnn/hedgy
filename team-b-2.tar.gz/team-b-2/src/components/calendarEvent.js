import { isRecurringTask } from './taskModel.js'

const zone = 'Europe/Tallinn'
const stamp = date => date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z')
const escapeText = value => String(value || '').replace(/\\/g, '\\\\').replace(/\r\n|\r|\n/g, '\\n').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')

export function tallinnInstant(date, time) {
  const [year, month, day] = date.split('-').map(Number)
  const [hour, minute] = time.split(':').map(Number)
  const target = Date.UTC(year, month - 1, day, hour, minute)
  let instant = target
  const formatter = new Intl.DateTimeFormat('en-GB', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })
  for (let i = 0; i < 3; i++) {
    const parts = Object.fromEntries(formatter.formatToParts(new Date(instant)).map(part => [part.type, part.value]))
    const displayed = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute, +parts.second)
    instant = target - (displayed - instant)
  }
  return new Date(instant)
}

function foldLine(line) {
  const encoder = new TextEncoder()
  let result = '', bytes = 0
  for (const character of line) {
    const size = encoder.encode(character).length
    if (bytes + size > 75) { result += '\r\n '; bytes = 1 }
    result += character
    bytes += size
  }
  return result
}

export function calendarEvent(task, duration = 60, now = new Date()) {
  const date = task.type === 'goal' ? task.startDate : task.date || task.startDate
  const allDay = !task.time
  const start = allDay ? date.replace(/-/g, '') : stamp(tallinnInstant(date, task.time))
  const nextDay = new Date(`${task.type === 'goal' ? task.deadline : date}T12:00:00Z`)
  nextDay.setUTCDate(nextDay.getUTCDate() + 1)
  const end = allDay ? nextDay.toISOString().slice(0, 10).replace(/-/g, '') : stamp(new Date(Number(tallinnInstant(task.type === 'goal' ? task.deadline : date, task.time)) + duration * 60000))
  const params = new URLSearchParams({ action: 'TEMPLATE', text: task.title, dates: `${start}/${end}`, details: task.description || '', ctz: zone })
  let recurrence = ''
  if (isRecurringTask(task) && ['schedule', 'weekdays', 'daily'].includes(task.rule)) {
    const days = task.rule === 'daily' ? [1,2,3,4,5,6,7] : task.weekdays || []
    recurrence = `RRULE:FREQ=YEARLY;BYMONTH=${(task.months || [1,2,3,4,5,6,7,8,9,10,11,12]).join(',')};BYDAY=${days.map(day => ['MO','TU','WE','TH','FR','SA','SU'][day - 1]).join(',')}`
    if (task.cadence === 'interval') recurrence = `RRULE:FREQ=DAILY;INTERVAL=${task.interval};BYMONTH=${task.months.join(',')}`
    if (task.cadence === 'dates') recurrence = `RDATE${allDay ? ';VALUE=DATE' : ''}:${task.dates.map(day => allDay ? day.replace(/-/g, '') : stamp(tallinnInstant(day, task.time))).join(',')}`
    params.set('recur', recurrence)
  }
  const url = `https://calendar.google.com/calendar/render?${params}`
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Grow Your Day//Calendar Event//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'BEGIN:VEVENT', `UID:${encodeURIComponent(task.id)}-${date}@grow-your-day.local`, `DTSTAMP:${stamp(now)}`, `DTSTART${allDay ? ';VALUE=DATE' : ''}:${start}`, `DTEND${allDay ? ';VALUE=DATE' : ''}:${end}`, `SUMMARY:${escapeText(task.title)}`, `DESCRIPTION:${escapeText(task.description)}`, 'END:VEVENT', 'END:VCALENDAR']
  if (recurrence) lines.splice(lines.indexOf('END:VEVENT'), 0, recurrence)
  if (recurrence && !allDay) {
    // Use local wall time for repeating events so DST does not shift the habit.
    const local = value => {
      const parts = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(value).map(part => [part.type, part.value]))
      return `${parts.year}${parts.month}${parts.day}T${parts.hour}${parts.minute}${parts.second}`
    }
    lines[lines.findIndex(line => line.startsWith('DTSTART'))] = `DTSTART;TZID=${zone}:${local(tallinnInstant(date, task.time))}`
    lines[lines.findIndex(line => line.startsWith('DTEND'))] = `DTEND;TZID=${zone}:${local(new Date(Number(tallinnInstant(date, task.time)) + duration * 60000))}`
  }
  if (isRecurringTask(task) && task.excludedDates?.length) lines.splice(lines.indexOf('END:VEVENT'), 0, `EXDATE${allDay ? ';VALUE=DATE' : ''}:${task.excludedDates.map(day => allDay ? day.replace(/-/g, '') : stamp(tallinnInstant(day, task.time))).join(',')}`)
  return { url, ics: lines.map(foldLine).join('\r\n') + '\r\n', filename: `${task.title.replace(/[^\p{L}\p{N}\s_-]/gu, '').trim().slice(0, 60) || 'calendar-event'}.ics` }
}
