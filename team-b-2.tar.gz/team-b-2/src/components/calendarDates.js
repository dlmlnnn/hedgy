export function dateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

export function deadlineMessage(deadline, today = new Date()) {
  const days = Math.round((Date.parse(`${deadline}T00:00:00Z`) - Date.parse(`${dateKey(today)}T00:00:00Z`)) / 86400000)
  if (days < 0) return 'Deadline passed'
  if (days === 0) return 'Deadline is today'
  return `${days} ${days === 1 ? 'day' : 'days'} left`
}
