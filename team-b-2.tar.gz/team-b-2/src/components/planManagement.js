export function listPlans(items, tab) {
  if (tab !== 'Commitments') return items.filter(item => item.type === (tab === 'Goals' ? 'goal' : 'habit'))
  const groups = new Map()
  for (const item of items) if (item.commitmentId) {
    if (!groups.has(item.commitmentId)) groups.set(item.commitmentId, { ...item, id: item.commitmentId, type: 'commitment', dates: [] })
    groups.get(item.commitmentId).dates.push(item.date)
  }
  return [...groups.values()].map(plan => ({ ...plan, dates: [...new Set(plan.dates)].sort() }))
}

export function belongsToPlan(item, plan) {
  return plan.type === 'commitment' ? item.commitmentId === plan.commitmentId : item.id === plan.id
}

export function preservePastDates(original, selected, today) {
  return [...new Set([...original.filter(date => date < today), ...selected.filter(date => date >= today)])].sort()
}

export function updatePlanDates(items, plan, chosen, today, makeId = () => crypto.randomUUID()) {
  const dates = preservePastDates(plan.type === 'goal' ? plan.stepDates : plan.dates, chosen, today)
  if (plan.type === 'commitment') {
    const existing = items.filter(item => belongsToPlan(item, plan))
    const added = dates.filter(date => !existing.some(item => item.date === date)).map(date => ({ id: makeId(), title: plan.title, description: plan.description || '', ...(plan.time ? { time: plan.time } : {}), date, done: false, completed: false, commitmentId: plan.commitmentId }))
    return [...items.filter(item => !belongsToPlan(item, plan) || dates.includes(item.date)), ...added]
  }
  return items.map(item => item.id !== plan.id ? item : plan.type === 'goal'
    ? { ...item, stepDates: dates.filter(date => date <= item.deadline), excludedDates: (item.excludedDates || []).filter(date => date < today || !dates.includes(date)) }
    : { ...item, dates, excludedDates: (item.excludedDates || []).filter(date => date < today || !dates.includes(date)) })
}

export function restoreDeleted(items, removed) {
  const next = [...items]
  for (const { item, index } of removed) if (!next.some(current => current.id === item.id)) next.splice(Math.min(index, next.length), 0, item)
  return next
}
