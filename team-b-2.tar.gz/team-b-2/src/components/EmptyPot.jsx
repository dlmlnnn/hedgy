export default function EmptyPot({ className = '' }) {
  return <svg className={className} viewBox="0 0 70 67" role="img" aria-label="An empty terracotta pot with soft dark soil, ready for future growth">
    <ellipse cx="35" cy="62" rx="35" ry="5" fill="#6B6B6B" opacity=".12" />
    <path d="M7 12h56l-7 38c-1 9-41 9-42 0Z" fill="#B5763C" />
    <ellipse cx="35" cy="11" rx="31" ry="9" fill="#B5763C" />
    <path d="M9 11C13-1 55-1 61 11c-8 7-44 7-52 0Z" fill="#6B6B6B" />
    <path d="M4 11q31 13 62 0v9q-31 12-62 0Z" fill="#B5763C" />
    <path d="M6 21q29 10 58 0" fill="none" stroke="#2E2A25" strokeOpacity=".13" />
    <path d="m17 30 4 18" stroke="#F8F4E8" strokeOpacity=".18" strokeWidth="3" strokeLinecap="round" />
  </svg>
}
