import { useEffect, useId, useRef } from 'react'
import { treeStats } from './treeProgress'
import { anchorOrder, anchorPosition } from './treeAppleLayout'

export function appleAnchor(index) {
  return anchorPosition(anchorOrder[Math.max(0, index) % 14])
}
const crownShape = 'M17 42C8 37 10 27 18 24 14 15 26 8 36 12 38 4 49 0 57 5 64-2 75 1 80 7 89 2 103 6 106 14 117 12 125 20 123 28 134 33 135 43 126 49 130 58 120 67 109 65 103 75 91 72 84 67 75 76 61 74 54 67 43 73 31 69 28 61 16 63 9 52 17 42Z'

function Leaf({ x, y, angle = 0, size = 1, light = false }) {
  return <g transform={`translate(${x} ${y}) rotate(${angle}) scale(${size})`}>
    <path d="M-6 0Q-1-7 7-1Q3 6-6 0Z" fill={light ? '#8D9A72' : '#476648'} stroke="#314932" strokeOpacity=".35" strokeWidth=".45" />
  </g>
}

function Canopy({ clipId }) {
  return <g transform="translate(0 -4.4)">
    <path d={crownShape} fill="#476648" stroke="#695E69" strokeOpacity=".45" strokeWidth=".65" />
    <g clipPath={`url(#${clipId})`}>
      <ellipse cx="92" cy="57" rx="49" ry="23" fill="#314932" opacity=".23" />
      <ellipse cx="45" cy="23" rx="36" ry="20" fill="#A2AE88" opacity=".26" />
    </g>
  </g>
}

export default function PlannerTree({ tree, pulse, tapPulse = 0, variant = 'planner' }) {
  const { apples, stage, scale } = treeStats(tree)
  const clipId = useId().replace(/:/g, '')
  const drawing = useRef(null)
  useEffect(() => {
    if ((!pulse && !tapPulse) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const animation = drawing.current?.animate([{ transform: 'rotate(0deg)' }, { transform: 'rotate(-3deg)', offset: .35 }, { transform: 'rotate(2deg)', offset: .7 }, { transform: 'rotate(0deg)' }], { duration: 600, easing: 'ease-in-out' })
    return () => animation?.cancel()
  }, [pulse, tapPulse])
  return <svg className={`planner-tree ${variant === 'creation' ? 'creation-tree' : ''} pointer-events-none absolute overflow-visible`} viewBox="0 0 140 88" preserveAspectRatio="none" role="img" aria-label={`Your full apple tree, ${apples} apples for today's unfinished tasks`}>
    <defs><clipPath id={clipId}><path d={crownShape} /></clipPath><radialGradient id={`${clipId}-light`}><stop offset="45%" stopColor="white" stopOpacity=".65" /><stop offset="100%" stopColor="white" stopOpacity="0" /></radialGradient></defs>
    <g ref={drawing} style={{ transformOrigin: '66px 84px' }}>
      <g className="tree-stage" style={{ opacity: stage === 0 ? 1 : 0, transformOrigin: '66px 84px', transform: `scale(${stage === 0 ? scale : 1})` }}><ellipse cx="66" cy="84" rx="3" ry="1.8" fill="#B5763C" /><path d="m65 83 1 1" stroke="#F8F4E8" opacity=".4" strokeLinecap="round" /></g>
      <g className="tree-stage" style={{ opacity: stage === 1 ? 1 : 0, transformOrigin: '66px 84px', transform: `scale(${stage === 1 ? scale : .8})` }}><path d="M66 85q-2-12 0-24" fill="none" stroke="#476648" strokeWidth="3" strokeLinecap="round" /><path d="M65 75C50 76 48 66 49 62c12 0 18 6 16 13ZM66 65c-1-12 8-18 17-17 0 10-7 17-17 17Z" fill="#476648" /><path d="m64 73-10-8m13-2 10-11" fill="none" stroke="#B9C3A2" strokeWidth=".65" strokeLinecap="round" /></g>
      {[2, 3, 4].map(pictureStage => <g key={pictureStage} className="tree-stage" style={{ opacity: stage === pictureStage ? 1 : 0, transformOrigin: '66px 84px', transform: `scale(${stage === pictureStage ? scale : [0, 0, .42, .68, .96][pictureStage]})` }}>
        <g>
          <path d="M56 85q9-5 8-13l-2-16 3-21 4-4 2 16-2 15q-1 14 10 23l-12-2Z" fill="#655A50" stroke="#4E453D" strokeWidth=".65" strokeLinejoin="round" />
          <path d="M66 63Q52 49 41 38m26 12q9-14 23-23M68 72q16-9 28-24" fill="none" stroke="#655A50" strokeWidth={pictureStage === 2 ? 3 : 4.5} strokeLinecap="round" />
        </g>
        {pictureStage === 2 ? <g fill="#476648"><ellipse cx="39" cy="35" rx="16" ry="9" transform="rotate(30 39 35)" /><ellipse cx="89" cy="26" rx="17" ry="10" transform="rotate(-35 89 26)" /><ellipse cx="66" cy="21" rx="12" ry="17" /><ellipse cx="98" cy="47" rx="14" ry="9" transform="rotate(-25 98 47)" /><Leaf x={35} y={32} angle={25} size={1.3} light /><Leaf x={64} y={15} angle={-60} size={1.35} light /><Leaf x={88} y={24} angle={-30} size={1.4} /><Leaf x={98} y={46} angle={-20} size={1.2} light /></g> : <Canopy clipId={clipId} full={pictureStage === 4} />}
      </g>)}
      <g data-apple-count={apples} className="tree-apples" aria-hidden="true">
        {Array.from({ length: Math.min(14, apples) }, (_, i) => <g key={tree.appleKeys?.[i] || `apple-${i}`} data-apple-key={tree.appleKeys?.[i]} transform={`translate(${(tree.applePositions?.[i] || appleAnchor(i)).join(' ')})`}>
          <g transform="scale(1 .624)">
          {tree.appleOverdue?.[i] && <circle className="apple-light-halo" r="7.5" fill={`url(#${clipId}-light)`} />}
          <circle key={tree.appleHighlights?.[i] || 'steady'} r="5.2" fill={tree.appleColors?.[i] || '#E9C46A'} className={tree.appleHighlights?.[i] ? 'goal-apple-celebration' : tree.appleOverdue?.[i] ? 'priority-apple-glow' : undefined} style={{ '--apple-glow': tree.appleColors?.[i] || '#E9C46A', transformBox: 'fill-box', transformOrigin: 'center' }} />
          <path d="M0-4.6Q-.4-6.7 1.3-8.3" fill="none" stroke="#795335" strokeWidth="1.5" strokeLinecap="round" />
          <ellipse cx="-1.5" cy="-1.5" rx="1" ry="1.5" fill="#F8F4E8" opacity=".45" transform="rotate(30 -1.5 -1.5)" />
          </g>
        </g>)}
      </g>
    </g>
  </svg>
}
