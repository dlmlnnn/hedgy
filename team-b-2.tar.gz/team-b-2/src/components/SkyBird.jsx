import { useEffect, useState } from 'react'
import './SkyBird.css'

const messages = ['do your tasks folk', 'get to work', 'just do it', "let’s roll folks!", 'rise and grind', 'seize the moment...']

export default function SkyBird({ perchRequest = 0 }) {
  const [flight, setFlight] = useState(null)
  const [visit, setVisit] = useState(null)
  const [perched, setPerched] = useState(false)
  const [request, setRequest] = useState(null)
  const [caughtWorm, setCaughtWorm] = useState(false)
  const [departed, setDeparted] = useState(false)
  useEffect(() => {
    let timer
    function schedule() {
      clearTimeout(timer)
      if (document.hidden) return
      timer = setTimeout(() => { setRequest({ id: Date.now(), worm: true }); schedule() }, 360000)
    }
    schedule()
    document.addEventListener('visibilitychange', schedule)
    return () => { clearTimeout(timer); document.removeEventListener('visibilitychange', schedule) }
  }, [])
  useEffect(() => {
    if (perchRequest) setRequest({ id: Date.now(), worm: false })
  }, [perchRequest])
  useEffect(() => {
    if (!request) return
    setPerched(false)
    setCaughtWorm(false)
    setDeparted(false)
    setFlight(null)
    const fromLeft = Math.random() < .5
    setVisit({ ...request, fromLeft, message: messages[Math.floor(Math.random() * messages.length)] })
    const land = setTimeout(() => setPerched(true), !request.worm && !fromLeft ? 2380 : 1260)
    const catchWorm = setTimeout(() => setCaughtWorm(true), 3800)
    const leave = setTimeout(() => setPerched(false), 5460)
    const depart = setTimeout(() => setDeparted(true), 7000)
    const finish = setTimeout(() => { setVisit(null); setFlight(null) }, request.worm ? 9000 : 7000)
    return () => { clearTimeout(land); clearTimeout(catchWorm); clearTimeout(leave); clearTimeout(depart); clearTimeout(finish) }
  }, [request])
  useEffect(() => {
    const motion = window.matchMedia('(prefers-reduced-motion: reduce)')
    let next, finish
    function stop() { clearTimeout(next); clearTimeout(finish); setFlight(null) }
    function schedule() {
      if (document.hidden || motion.matches) return
      next = setTimeout(() => {
        if (document.hidden || motion.matches) return
        setFlight({ id: Date.now(), fromLeft: Math.random() < .5, height: 26 + Math.random() * 25 })
        finish = setTimeout(() => setFlight(null), 6500)
        schedule()
      }, Math.random() < .75 ? 60000 : 120000)
    }
    function restart() { stop(); schedule() }
    schedule()
    document.addEventListener('visibilitychange', restart)
    motion.addEventListener('change', restart)
    return () => { clearTimeout(next); clearTimeout(finish); document.removeEventListener('visibilitychange', restart); motion.removeEventListener('change', restart) }
  }, [])
  const bird = visit || flight
  if (!bird) return null
  const bubbleWidth = visit ? Math.max(53, visit.message.length * 5.5 + 18) : 0
  return <svg aria-hidden={visit ? undefined : true} role={visit ? 'status' : undefined} aria-label={visit ? `A bird visits the tree${visit.worm ? ', pecks and catches a worm,' : ''} and says ${visit.message}` : undefined} className={`sky-bird ${visit ? 'sky-bird-visiting' : ''} ${visit?.worm ? 'sky-bird-worm-visit' : ''} ${visit && !visit.worm && !bird.fromLeft ? 'sky-bird-slow-right' : ''} pointer-events-none absolute inset-x-0 top-0 h-(--planner-header-height) w-full overflow-hidden`} viewBox="0 0 393 250" preserveAspectRatio="none">
    <g key={visit ? `visit-${bird.id}` : bird.id} className={visit ? 'sky-bird-perch' : 'sky-bird-flight'} style={{ display: visit?.worm && departed ? 'none' : undefined, '--bird-start': bird.fromLeft ? '-28px' : '421px', '--bird-end': bird.fromLeft ? '421px' : '-28px' }}>
      <g transform={`translate(0 ${visit ? 0 : bird.height})`}><g className={visit ? undefined : 'sky-bird-bob'}>
        <g transform={`scale(${bird.fromLeft ? .8 : -.8} .8)`} fill="#282B27" stroke="#282B27" strokeLinecap="round" strokeLinejoin="round">
          <path d="M-4 1-11-1-8 3-4 3" strokeWidth=".7" />
          <ellipse cx="0" cy="2" rx="4" ry="2.3" stroke="none" />
          <g className={visit?.worm ? 'sky-bird-peck' : undefined}>
          <circle cx="5" cy=".4" r="2.1" stroke="none" />
          <path d="m6.5 0 3 1-3 .6" fill="#B59A70" stroke="none" />
          {visit?.worm && caughtWorm && <path data-bird-worm="true" className="sky-bird-worm" d="M9 1q2-3 3 0t3 0q1-2 2 0" stroke="#B57665" strokeWidth="1.3" fill="none" />}
          </g>
          <path className={perched && visit ? undefined : 'sky-bird-wing'} d={perched && visit ? 'M-3 1Q-2 4 2 3L1 1Z' : 'M0 2Q-3-4-9-6Q-5-8 2-1Z'} strokeWidth=".6" />
          {perched && visit && <path d="M-1 4v2m4-2v2" fill="none" strokeWidth=".8" />}
        </g>
      </g></g>
    </g>
    {visit && <g key={`message-${visit.id}`} className="sky-bird-message" style={visit.worm ? { opacity: departed ? 1 : 0 } : undefined} transform="translate(8 30)"><rect width={bubbleWidth} height="22" rx="11" fill="#F8F4E8" stroke="#6E9A82" strokeOpacity=".5" /><text x={bubbleWidth / 2} y="14.5" textAnchor="middle" fill="#4F7A66" fontFamily="Nunito, sans-serif" fontSize="10">{visit.message}</text></g>}
  </svg>
}
