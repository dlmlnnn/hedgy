export default function PlannerScene({ daylight }) {
  return <svg aria-hidden="true" className="planner-scene pointer-events-none absolute inset-x-0 top-0 h-(--planner-header-height) w-full" viewBox="0 0 393 244" preserveAspectRatio="none">
    <defs><linearGradient id="planner-hill" x1="0%" y1="0%" x2="0%" y2="100%"><stop stopColor={daylight.ground} /><stop offset="1" stopColor={daylight.lower} /></linearGradient></defs>
    {daylight.phase === 'night' && <g fill="#F8F4E8" opacity=".45"><circle cx="42" cy="78" r="1" /><circle cx="191" cy="50" r=".8" /><circle cx="247" cy="30" r="1" /><circle cx="300" cy="92" r=".8" /><circle cx="128" cy="30" r=".7" /></g>}
    <path d="M0 222H88Q101 222 113 224L204 230Q286 234 393 233V244H0Z" fill="url(#planner-hill)" />
    <g fill="none" stroke="#8B826E" strokeWidth="4" strokeLinecap="round" opacity=".75" transform="translate(-4 28) scale(.88 .92)"><path d="M-6 175H99l105 13M-6 192H99l105 13" /><path d="M-5 168v44m26-44v44m26-44v44m26-44v44m27-44v46m26-40v42m26-38v39m26-33v36m23-31v36" /></g>
    <ellipse cx="89" cy="231" rx="24" ry="5" fill="#6B6B6B" opacity=".1" />
    <path d="M72 231q17-11 34 0Z" fill="#655A50" />
  </svg>
}
