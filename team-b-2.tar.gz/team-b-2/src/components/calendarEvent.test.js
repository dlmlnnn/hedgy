import test from 'node:test'
import assert from 'node:assert/strict'
import { calendarEvent, tallinnInstant } from './calendarEvent.js'

test('habit exports weekday and month recurrence to Google Calendar and ICS', () => {
  const event = calendarEvent({ id: 'habit', type: 'habit', rule: 'schedule', title: 'Read', date: '2027-01-04', weekdays: [1,3,5], months: [1,2], excludedDates: ['2027-01-06'] })
  const rule = 'RRULE:FREQ=YEARLY;BYMONTH=1,2;BYDAY=MO,WE,FR'
  assert.ok(event.ics.includes(rule))
  assert.equal(new URL(event.url).searchParams.get('recur'), rule)
  assert.match(event.ics, /EXDATE;VALUE=DATE:20270106/)
})

test('timed habit uses Estonian wall time across daylight saving changes', () => {
  const event = calendarEvent({ id: 'h', type: 'habit', title: 'Read', date: '2026-10-23', time: '09:00', rule: 'schedule', weekdays: [5], months: [10,11] })
  assert.match(event.ics, /DTSTART;TZID=Europe\/Tallinn:20261023T090000/)
  assert.match(event.ics, /DTEND;TZID=Europe\/Tallinn:20261023T100000/)
})

test('goal event spans the full inclusive goal range', () => {
  const event = calendarEvent({ id: 'goal', type: 'goal', title: 'Outcome', date: '2026-11-30', startDate: '2026-11-01', deadline: '2026-11-30' })
  assert.match(event.ics, /DTSTART;VALUE=DATE:20261101/)
  assert.match(event.ics, /DTEND;VALUE=DATE:20261201/)
})

test('timed events use Estonian summer and winter time and the chosen duration', () => {
  assert.equal(tallinnInstant('2026-10-29', '10:00').toISOString(), '2026-10-29T08:00:00.000Z')
  assert.equal(tallinnInstant('2026-06-21', '10:00').toISOString(), '2026-06-21T07:00:00.000Z')
  const event = calendarEvent({ id: 'task', title: 'Read', date: '2026-10-29', time: '10:00' }, 90)
  assert.match(event.ics, /DTSTART:20261029T080000Z\r\n/)
  assert.match(event.ics, /DTEND:20261029T093000Z\r\n/)
  const url = new URL(event.url)
  assert.equal(url.searchParams.get('dates'), '20261029T080000Z/20261029T093000Z')
  assert.equal(url.searchParams.get('ctz'), 'Europe/Tallinn')
})

test('all-day events use an exclusive next-day end across the year boundary', () => {
  const event = calendarEvent({ id: 'task', title: 'Reflect', date: '2026-12-31' })
  assert.match(event.ics, /DTSTART;VALUE=DATE:20261231\r\n/)
  assert.match(event.ics, /DTEND;VALUE=DATE:20270101\r\n/)
  assert.equal(new URL(event.url).searchParams.get('dates'), '20261231/20270101')
})

test('event text is escaped and UTF-8 lines are folded safely', () => {
  const event = calendarEvent({ id: 'safe-id', title: 'Read, write; rest', description: 'First line\nSecond \\ line; with, commas. ' + 'õun'.repeat(80), date: '2026-10-29' })
  const unfolded = event.ics.replace(/\r\n /g, '')
  assert.ok(unfolded.includes('SUMMARY:Read\\, write\\; rest'))
  assert.ok(unfolded.includes('DESCRIPTION:First line\\nSecond \\\\ line\\; with\\, commas.'))
  for (const line of event.ics.split('\r\n')) assert.ok(new TextEncoder().encode(line).length <= 75)
  assert.equal(new URL(event.url).searchParams.get('text'), 'Read, write; rest')
  assert.match(event.filename, /\.ics$/)
})
