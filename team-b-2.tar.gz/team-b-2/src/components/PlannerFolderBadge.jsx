import { useId, useRef, useState } from 'react'

export default function PlannerFolderBadge({ folders, value, onChange }) {
  const [open, setOpen] = useState(false)
  const id = useId()
  const trigger = useRef(null)
  const label = value || 'No folder'
  const options = [['', 'No folder'], ...folders.map(name => [name, name])]
  return <div className="pointer-events-auto absolute bottom-4 left-[4.5rem] max-w-[calc(100%-9rem)]" onBlur={event => {
    if (event.relatedTarget && !event.currentTarget.contains(event.relatedTarget)) setOpen(false)
  }} onKeyDown={event => {
    if (event.key === 'Escape' && open) {
      event.stopPropagation()
      setOpen(false)
      trigger.current?.focus()
    }
  }}>
    <button ref={trigger} type="button" aria-label={`Task folder: ${label}`} aria-expanded={open} aria-controls={id} onClick={() => setOpen(previous => !previous)} className="flex h-[46px] max-w-full items-center gap-2 rounded-[999px] border border-[#D0D0D0] bg-(--planner-card-surface) px-3 text-xs font-semibold text-[#565656] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">
      <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="size-4 shrink-0"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z" /></svg>
      <span className="truncate">{label}</span>
    </button>
    <div id={id} hidden={!open} aria-label="Filter by task folder" role="group" className="task-scroll absolute bottom-full left-0 mb-2 max-h-44 w-40 overflow-y-auto rounded-xl border border-[#6E9A82]/35 bg-(--control-surface) p-1 shadow-lg">
      {options.map(([folder, name]) => <button key={folder} type="button" aria-current={folder === value ? 'true' : undefined} onClick={() => {
        onChange(folder)
        setOpen(false)
        trigger.current?.focus({ preventScroll: true })
      }} className="block min-h-9 w-full break-words rounded-lg px-2 text-left text-xs text-[#354D40] hover:bg-(--control-hover) aria-[current=true]:bg-(--control-selected) focus-visible:outline-2 focus-visible:outline-[#4F7A66]">{name}</button>)}
    </div>
  </div>
}
