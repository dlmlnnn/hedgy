import { useEffect, useId, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import Calendar from './Calendar'
import { dateKey } from './calendarDates'
import NotificationPicker from './NotificationPicker'
import TaskApple, { applePalette, taskAppleColor } from './TaskApple'
import TaskListField, { taskFieldClass } from './TaskListField'
import TimeAccordion from './TimeAccordion'
import { newTask } from './taskModel'
import useVisibleViewport from './useVisibleViewport'
import useTriggerExpansion from './useTriggerExpansion'

const quickDays = [[0, 'Today'], [1, 'tomorrow'], [2, 'in 2 days'], [3, 'in 3 days'], [5, 'in 5 days'], [6, 'in 6 days'], [7, 'in 7 days']]

export default function UnifiedTaskForm({ task, lists, initialFolder, initialFolderListId, onSave, onClose, onDelete, onShare, onCreateList, triggerRef }) {
  const [draft, setDraft] = useState(() => task || { ...newTask(), appleColor: 'Green', list: initialFolder || '', folderListId: initialFolderListId })
  const [advanced, setAdvanced] = useState(false)
  const optionsId = useId()
  const dayOptionsId = useId()
  const [dayOptionsOpen, setDayOptionsOpen] = useState(false)
  const [scheduleControl, setScheduleControl] = useState(null)
  const [palette, setPalette] = useState(false)
  const paletteId = useId()
  const appleButton = useRef(null)
  const [calendar, setCalendar] = useState(null)
  const dialog = useRef(null)
  const form = useRef(null)
  const dateButton = useRef(null)
  const dayButton = useRef(null)
  const viewport = useVisibleViewport(dialog)
  useTriggerExpansion(form, triggerRef)
  const title = task ? 'Edit task' : 'Add a task'
  const allowNoDate = Boolean(draft.list)
  const noDate = draft.date === null
  const dayOptions = quickDays.map(([offset, label]) => {
    const day = new Date()
    day.setDate(day.getDate() + offset)
    return { date: dateKey(day), label }
  })
  if (allowNoDate) dayOptions.splice(2, 0, { date: null, label: 'No date' })
  const dateCount = draft.scheduledDates?.length || 0
  const quickDate = dateCount <= 1 ? dayOptions.find(option => option.date === draft.date) : undefined
  const calendarLabel = dateCount > 1 ? `${dateCount} dates selected` : new Date(`${draft.date}T12:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
  const dayLabel = noDate ? 'No date' : quickDate?.label || calendarLabel
  const color = draft.appleColor || Object.keys(applePalette).find(name => applePalette[name] === taskAppleColor(draft))
  const patch = (key, value) => setDraft(previous => ({ ...previous, [key]: value }))
  const toggleScheduleControl = control => setScheduleControl(previous => previous === control ? null : control)
  const scheduleButton = 'flex min-h-11 min-w-0 items-center justify-center gap-2 rounded-xl border border-[#6E9A82]/40 bg-white/40 px-2 text-sm text-[#354D40] focus-visible:outline-2 focus-visible:outline-[#4F7A66]'
  useEffect(() => { dialog.current?.focus({ preventScroll: true }) }, [])
  function closeCalendar() {
    const trigger = calendar === 'day' ? dayButton : dateButton
    setCalendar(null)
    requestAnimationFrame(() => trigger.current?.focus({ preventScroll: true }))
  }
  function submit(event) {
    event.preventDefault()
    if (draft.title.trim()) onSave({ ...draft, title: draft.title.trim(), list: (draft.list || '').trim() })
  }
  function selectDay(date) {
    setDraft(previous => ({ ...previous, date, startDate: date, originalDate: undefined, rolledOver: false, scheduledDates: undefined, monthPattern: undefined, recurrencePattern: undefined, usesRecurrence: false,
      ...(date === null ? { deadline: null, time: '', notification: undefined } : {}) }))
    if (date === null) { setAdvanced(false); setScheduleControl(null) }
    setDayOptionsOpen(false)
    dayButton.current?.focus({ preventScroll: true })
  }
  const closeButton = <button type="button" aria-label="Close task form" onClick={onClose} className="h-11 w-11 shrink-0 rounded-full text-2xl text-[#59554D] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">×</button>
  const taskListField = <TaskListField lists={lists} value={draft.list} onChange={value => patch('list', value)} onCreateList={onCreateList} />
  const submitButton = <button type="submit" disabled={!draft.title.trim()} className="min-h-11 shrink-0 rounded-full bg-[#3D6653] px-4 text-sm font-semibold text-white disabled:opacity-55 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4F7A66]">{task ? 'Save changes' : 'Add task'}</button>
  return <>
    <div ref={dialog} role="dialog" aria-modal={!calendar} aria-label={title} tabIndex={-1} inert={Boolean(calendar)} onClick={onClose} onKeyDown={event => {
      if (event.key === 'Escape') { event.stopPropagation(); onClose() }
    }} className="planner-modal-backdrop absolute inset-0 z-50 flex items-center justify-center outline-none">
      <form ref={form} style={viewport ? { position: 'absolute', top: viewport.top + 8, maxHeight: viewport.height - 16 } : undefined} onClick={event => event.stopPropagation()} onSubmit={submit} className="task-scroll flex max-h-[90%] w-[88%] max-w-sm flex-col gap-3 overflow-y-auto rounded-[28px] bg-[#F8F4E8] p-5 text-[#2E2A25] shadow-xl">
        {task && <div className="flex shrink-0 items-center justify-between">
          <h2 className="text-xl font-semibold">{title}</h2>
          {closeButton}
        </div>}
        <div className="shrink-0">
        <div className="flex items-end gap-3">
          <label className="min-w-0 flex-1">
            <span className="sr-only">Task name</span>
            <input className={`${taskFieldClass} !mt-0`} value={draft.title} onChange={event => patch('title', event.target.value)} placeholder="Task name" required maxLength={160} />
          </label>
          <button ref={appleButton} type="button" aria-label={`Apple color, ${color}`} aria-expanded={palette} aria-controls={paletteId} onClick={() => setPalette(value => !value)} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-dashed border-[#B8B7AE] bg-white/40 focus-visible:outline-2 focus-visible:outline-[#4F7A66]">
            <TaskApple task={{ appleColor: color }} size={24} />
          </button>
          {!task && closeButton}
        </div>
        <div id={paletteId} inert={!palette} aria-hidden={!palette} className={`grid transition-[grid-template-rows,opacity] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none ${palette ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
          <div className="min-h-0 overflow-hidden">
            <fieldset className="mt-2 flex gap-1 rounded-xl bg-white/40 px-2 pb-1">
              <legend className="px-1 text-sm font-semibold">Apple color</legend>
              {Object.keys(applePalette).map(name => <button key={name} aria-pressed={name === color} aria-label={name} type="button" onClick={() => {
                patch('appleColor', name)
                setPalette(false)
                appleButton.current?.focus({ preventScroll: true })
              }} className="grid min-h-11 min-w-11 place-items-center rounded-xl aria-pressed:bg-[#4F7A66]/15 focus-visible:outline-2 focus-visible:outline-[#4F7A66]"><TaskApple task={{ appleColor: name }} size={22} /></button>)}
            </fieldset>
          </div>
        </div>
        </div>
        {task && <><fieldset disabled={noDate}>{taskListField}</fieldset>{submitButton}</>}
        {(!task || allowNoDate || noDate) && <div className="shrink-0 rounded-xl border border-[#6E9A82]/40 bg-(--control-surface)" onBlur={event => {
          if (event.relatedTarget && !event.currentTarget.contains(event.relatedTarget)) setDayOptionsOpen(false)
        }} onKeyDown={event => {
          if (event.key !== 'Escape' || !dayOptionsOpen) return
          event.stopPropagation()
          setDayOptionsOpen(false)
          dayButton.current?.focus({ preventScroll: true })
        }}>
          <button ref={dayButton} type="button" aria-label={dayOptionsOpen ? 'Close day options' : `Task day, ${dayLabel}`} aria-expanded={dayOptionsOpen} aria-controls={dayOptionsId} onClick={() => setDayOptionsOpen(value => !value)} className="flex min-h-11 w-full items-center justify-between gap-2 rounded-xl px-3 text-left text-base focus-visible:outline-2 focus-visible:outline-[#4F7A66]">
            <span className={noDate ? 'text-neutral-600' : undefined}>{!dayOptionsOpen && dayLabel}</span>
            <span aria-hidden="true" className={`text-[#4F7A66] transition-transform duration-200 motion-reduce:transition-none ${dayOptionsOpen ? 'rotate-180' : ''}`}>⌄</span>
          </button>
          <div id={dayOptionsId} inert={!dayOptionsOpen} aria-hidden={!dayOptionsOpen} className={`grid transition-[grid-template-rows,opacity] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none ${dayOptionsOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
            <div className="min-h-0 overflow-hidden">
              <div role="group" aria-label="Day options" className="task-scroll max-h-56 overflow-y-auto overscroll-contain border-t border-[#6E9A82]/30 p-1">
                <button type="button" aria-haspopup="dialog" onClick={() => { setDayOptionsOpen(false); setCalendar('day') }} className="block min-h-9 w-full rounded-lg px-2 text-left text-sm font-medium text-[#354D40] hover:bg-[#E8EFE5] focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">Select date</button>
                {dayOptions.map(({ date, label }) => <button key={date} type="button" aria-current={quickDate?.date === date ? 'true' : undefined} onClick={() => selectDay(date)} className="block min-h-9 w-full rounded-lg px-2 text-left text-sm hover:bg-(--control-hover) aria-[current=true]:bg-(--control-selected) focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">{label}</button>)}
              </div>
            </div>
          </div>
        </div>}
        {task && <div className="flex shrink-0 justify-between gap-2 text-sm text-[#3D6653]">
          <button type="button" onClick={onDelete} className="min-h-11 px-2 underline">Delete</button>
          {onShare && !noDate && <button type="button" onClick={onShare} className="min-h-11 px-2 underline">Calendar options</button>}
        </div>}
        <div className="shrink-0">
        <div className={`flex gap-2 border-t border-[#6E9A82]/30 ${advanced ? 'items-start pt-2' : 'items-center'}`}>
          {advanced && <>
            <div className="w-24 shrink-0"><TimeAccordion value={draft.time} expanded={scheduleControl === 'time'} onToggle={() => toggleScheduleControl('time')} onChange={value => patch('time', value)} /></div>
            <button ref={dateButton} type="button" aria-label="Schedule calendar" aria-haspopup="dialog" onClick={() => { setScheduleControl(null); setCalendar('schedule') }} className={`${scheduleButton} size-9 min-h-0!`}>
              <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" className="size-4 shrink-0"><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M7 3v4m10-4v4M3 10h18" /></svg>
            </button>
          </>}
          <button type="button" disabled={noDate} aria-label={advanced ? 'Collapse task options' : undefined} aria-expanded={advanced} aria-controls={optionsId} onClick={() => setAdvanced(value => !value)} className={`flex shrink-0 items-center gap-2 whitespace-nowrap text-left text-sm font-semibold text-[#3D6653] disabled:bg-transparent! disabled:text-[#3D6653]! focus-visible:outline-2 focus-visible:outline-[#4F7A66] ${advanced ? 'ml-auto size-9 justify-center rounded-full' : 'min-h-11 w-full justify-between'}`}>
            {!advanced && <span className={noDate ? 'opacity-65' : undefined}>{task ? 'Time / date / repeat / steps' : 'Time / date / repeat'}</span>}
            <span className="grid size-7 shrink-0 place-items-center rounded-full bg-[#4F7A66]/10" aria-hidden="true">
              <svg viewBox="0 0 16 16" fill="none" className={`size-4 transition-transform duration-200 ease-in-out motion-reduce:transition-none ${advanced ? 'rotate-180' : ''}`}>
                <path d="m4 6 4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
          </button>
        </div>
        <div id={optionsId} inert={!advanced} aria-hidden={!advanced} className={`grid transition-[grid-template-rows,opacity] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none ${advanced ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
          <div className="min-h-0 overflow-hidden">
          <div className={`flex flex-col gap-2 px-0.5 pt-3 pb-0.5 transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none ${advanced ? 'translate-y-0' : 'translate-y-1.5'}`}>
          <textarea aria-label="Notes" placeholder="notes..." value={draft.description || ''} onChange={event => patch('description', event.target.value)} rows={3} className="min-h-20 w-full resize-none rounded-lg border border-[#6E9A82]/40 bg-white/40 px-3 py-2 text-base outline-[#4F7A66]" />
          <button type="button" aria-expanded={scheduleControl === 'notification'} onClick={() => toggleScheduleControl('notification')} className={`${scheduleButton} w-full rounded-full!`}>Set a notification</button>
          {scheduleControl === 'notification' && <NotificationPicker value={draft.notification} onChange={value => patch('notification', value)} />}
          {!task && <fieldset disabled={!advanced} className="min-w-0">{taskListField}</fieldset>}
          </div>
          </div>
        </div>
        </div>
        {!task && submitButton}
      </form>
    </div>
    {calendar && createPortal(<div className="absolute inset-0 z-[70]"><Calendar mode={task || calendar === 'day' ? 'pick' : 'multi'} selectionType="quick" allowMultiGesture={Boolean(task)} multiLabel="Choose task dates" tasks={[]} initialDate={draft.date} initialDates={calendar === 'day' ? [] : draft.scheduledDates || (task ? [] : [draft.date])} initialMonthPattern={calendar === 'schedule' ? draft.monthPattern : undefined} confirmLabel={task || calendar === 'day' ? 'Apply date' : 'Apply dates'} onClose={closeCalendar} onPick={(selection, { recurrence, monthPattern, recurrencePattern }) => {
      const dates = Array.isArray(selection) ? selection : [selection]
      setDraft(previous => {
        const previousDates = previous.scheduledDates || []
        const sameDates = dates.length === previousDates.length && dates.every((date, index) => date === previousDates[index])
        return {
          ...previous, date: dates[0], startDate: dates[0], scheduledDates: dates, monthPattern,
          recurrencePattern: recurrencePattern || (!recurrence && sameDates && calendar !== 'day' ? previous.recurrencePattern : undefined),
          ...(task ? {} : { usesRecurrence: calendar !== 'day' && Boolean(recurrence || (sameDates && previous.usesRecurrence)) }),
          originalDate: undefined, rolledOver: false,
        }
      })
      closeCalendar()
    }} /></div>, document.querySelector('.app-stage'))}
  </>
}
