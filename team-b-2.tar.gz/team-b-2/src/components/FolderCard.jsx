import { useEffect, useRef, useState } from 'react'

export async function readFolderCover(file) {
  const url = URL.createObjectURL(file)
  try {
    const image = new Image()
    image.src = url
    await image.decode()
    const scale = Math.min(1, 480 / Math.max(image.naturalWidth, image.naturalHeight))
    const canvas = document.createElement('canvas')
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale))
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale))
    canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height)
    return canvas.toDataURL('image/webp', 0.8)
  } finally {
    URL.revokeObjectURL(url)
  }
}

function ReorderHandle({ name, index, disabled, onMove, onDragTarget }) {
  const press = useRef(null)
  const [dragging, setDragging] = useState(false)
  useEffect(() => () => clearTimeout(press.current?.timer), [])

  function start(event) {
    if (disabled || press.current || !event.isPrimary || event.button !== 0) return
    event.currentTarget.setPointerCapture(event.pointerId)
    const gesture = { id: event.pointerId, x: event.clientX, y: event.clientY, active: false }
    press.current = gesture
    gesture.timer = setTimeout(() => {
      gesture.active = true
      setDragging(true)
      onDragTarget(index)
    }, 250)
  }
  function targetAt(event) {
    const card = document.elementFromPoint(event.clientX, event.clientY)?.closest('[data-folder-index]')
    return card ? Number(card.dataset.folderIndex) : null
  }
  function move(event) {
    const gesture = press.current
    if (gesture?.id !== event.pointerId) return
    if (gesture.active) onDragTarget(targetAt(event))
    else if (Math.hypot(event.clientX - gesture.x, event.clientY - gesture.y) > 10) clearTimeout(gesture.timer)
  }
  function finish(event, drop = false) {
    const gesture = press.current
    if (gesture?.id !== event.pointerId) return
    clearTimeout(gesture.timer)
    press.current = null
    if (!gesture.active) return
    setDragging(false)
    onDragTarget(null)
    const target = drop ? targetAt(event) : null
    if (target !== null) onMove(index, target)
  }

  return <button type="button" disabled={disabled} aria-label={`Reorder ${name}`}
    title="Hold and drag, or use the arrow keys"
    onPointerDown={start} onPointerMove={move} onPointerUp={event => finish(event, true)}
    onPointerCancel={finish} onLostPointerCapture={finish} onContextMenu={event => event.preventDefault()}
    onKeyDown={event => {
      const offset = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -2, ArrowDown: 2 }[event.key]
      if (!offset) return
      event.preventDefault()
      event.stopPropagation()
      onMove(index, index + offset)
    }}
    className={`folder-reorder-handle grid size-9 shrink-0 select-none place-items-center rounded-lg text-[#4F6053] focus-visible:outline-2 focus-visible:outline-[#4F7A66] ${dragging ? 'cursor-grabbing bg-[#657568]/15' : 'cursor-grab hover:bg-[#657568]/10'}`}>
    <svg aria-hidden="true" viewBox="0 0 20 20" className="size-4" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M4 5h12M4 10h12M4 15h12" />
    </svg>
  </button>
}

export default function FolderCard({ name, cover, editing, uploading, uploadPending, onNameChange, onCoverChange, onCoverRemove, index, reorderDisabled, dropTarget, onDragTarget, onMove, onDelete, onOpen }) {
  return <li data-folder-index={editing ? index : undefined} className={`relative mb-3 min-w-0 rounded-2xl border border-white/70 bg-white/40 p-3.5 shadow-[0_2px_5px_#354D4012] sm:p-4 ${dropTarget ? 'ring-2 ring-[#657568]/65' : ''}`}>
    <div className="relative grid aspect-[4/3] place-items-center overflow-hidden rounded-xl border border-[#657568]/20 bg-[#657568]/8 has-focus-visible:outline-2 has-focus-visible:outline-offset-2 has-focus-visible:outline-[#4F7A66]">
      {cover ? <img src={cover} alt="" className="absolute inset-0 h-full w-full object-cover" />
        : <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" className="size-6 text-[#657568]/55">
          <rect x="3" y="5" width="18" height="14" rx="3" /><path d="m4 16 5-5 4 4 2-2 5 5" /><circle cx="16" cy="9" r="1" />
        </svg>}
      {uploading && <span role="status" className="relative rounded-md bg-white/80 px-1 py-0.5 text-center text-xs text-[#354D40]">Preparing cover…</span>}
      {editing && <input type="file" accept="image/*" aria-label={`${cover ? 'Change' : 'Add'} cover for ${name}`} disabled={uploadPending}
          className="absolute inset-0 h-full w-full cursor-pointer opacity-0" onChange={event => {
            const file = event.target.files?.[0]
            event.target.value = ''
            if (file) onCoverChange(file)
          }} />}
    </div>
    {editing && <button type="button" disabled={uploadPending} aria-label={`Delete ${name} folder`} onClick={onDelete}
      className="absolute right-0 top-0 z-10 flex size-8 items-start justify-end rounded-tr-2xl border-0 bg-transparent pr-2 pt-1 text-sm leading-none text-neutral-600 hover:text-neutral-900 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-neutral-500 disabled:opacity-40">×</button>}
    <div className="mt-2 grid min-h-9 grid-cols-1 items-center [&>*]:col-start-1 [&>*]:row-start-1">
      <p aria-hidden={Boolean(editing)} className={`min-w-0 break-words text-sm font-semibold text-[#2E2A25] transition-opacity duration-300 motion-reduce:transition-none ${editing ? 'opacity-0' : 'opacity-100'}`}>{name}</p>
      <div inert={!editing} aria-hidden={!editing} data-open={Boolean(editing)} className="folder-edit-glide flex min-w-0 items-center gap-1">
        <input aria-label={`Folder name for ${name}`} value={editing?.name ?? name} maxLength={40} onChange={event => onNameChange(event.target.value)}
          className="folder-title-input min-h-9 min-w-0 flex-1 rounded-sm border-0 text-sm font-semibold focus-visible:outline-1 focus-visible:outline-[#657568]/55" />
        <ReorderHandle name={name} index={index} disabled={reorderDisabled || uploadPending} onMove={onMove} onDragTarget={onDragTarget} />
      </div>
    </div>
    {cover && <div inert={!editing} aria-hidden={!editing} data-open={Boolean(editing)} className="folder-edit-reveal">
      <div>
        <button type="button" disabled={uploading} onClick={onCoverRemove} aria-label={`Remove cover for ${name}`}
          className="min-h-8 rounded-sm text-xs text-[#59554D] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">Remove cover</button>
      </div>
    </div>}
    {!editing && <button type="button" aria-label={`Open ${name} folder`} onClick={onOpen}
      className="absolute inset-0 rounded-2xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4F7A66]" />}
  </li>
}

