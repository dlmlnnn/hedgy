import { useEffect, useRef, useState } from 'react'

export default function PanelPager({ pages, addButton, calendarButton, folderBadge, slideAway, requestedPage }) {
  const [activePageId, setActivePageId] = useState(pages[0]?.id)
  const [offset, setOffset] = useState(0)
  const drag = useRef(null)
  const suppressClick = useRef(false)
  const activeDot = useRef(null)
  const count = pages.length
  const page = Math.max(0, pages.findIndex(item => item.id === activePageId))
  useEffect(() => { if (requestedPage) { setActivePageId(requestedPage); setOffset(0) } }, [requestedPage])
  useEffect(() => { activeDot.current?.scrollIntoView({ block: 'nearest', inline: 'nearest' }) }, [activePageId, page])
  function jump(next) { if (count) setActivePageId(pages[(next + count) % count].id); setOffset(0) }
  function end(event, cancelled = false) {
    const gesture = drag.current
    if (!gesture || gesture.id !== event.pointerId) return
    drag.current = null
    if (!cancelled && gesture.moved && Math.abs(event.clientX - gesture.x) > 40) jump(page + (event.clientX < gesture.x ? 1 : -1))
    setOffset(0)
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId)
    setTimeout(() => { suppressClick.current = false }, 0)
  }
  return <div className="planner-scene-pager planner-page-bounds absolute" data-slide-away={slideAway || undefined} aria-roledescription={count ? 'carousel' : undefined} aria-label={count ? 'Planner card carousel' : undefined}
    style={{ touchAction: 'pan-y' }}
    onPointerDown={event => { if (event.button !== 0) return; suppressClick.current = false; if (count < 2 || event.target.closest('[role="tablist"], form')) return; drag.current = { id: event.pointerId, x: event.clientX, y: event.clientY, moved: false } }}
    onPointerMove={event => {
      const gesture = drag.current
      if (!gesture || gesture.id !== event.pointerId) return
      const x = event.clientX - gesture.x, y = event.clientY - gesture.y
      if (!gesture.moved && Math.abs(y) > 10 && Math.abs(y) > Math.abs(x)) { drag.current = null; return }
      if (!gesture.moved && Math.abs(x) > 10 && Math.abs(x) > Math.abs(y) * 1.2) { gesture.moved = true; suppressClick.current = true; event.currentTarget.setPointerCapture(event.pointerId) }
      if (gesture.moved) setOffset(Math.max(-150, Math.min(150, x)))
    }} onPointerUp={event => end(event)} onPointerCancel={event => end(event, true)}
    onClickCapture={event => { if (suppressClick.current) { event.preventDefault(); event.stopPropagation() } }}
    onDragStart={event => event.preventDefault()}
    onKeyDown={event => { if (count < 2 || ['INPUT', 'TEXTAREA', 'SELECT'].includes(event.target.tagName)) return; if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') { event.preventDefault(); jump(page + (event.key === 'ArrowRight' ? 1 : -1)) } }}>
    {!count && addButton()}
    {pages.map(({ id, name, content, placeholder, folderListId, onEditTitle, titleEditor }, index) => {
      const depth = (page - index + count) % count
      const active = depth === 0
      return <section key={id} id={`panel-page-${index}`} role="tabpanel" aria-label={name} inert={!active} aria-hidden={!active}
        data-stack-depth={depth}
        className={`absolute inset-0 flex flex-col overflow-hidden rounded-[28px] bg-[#F8F4E8] shadow-[0_10px_30px_rgba(70,50,30,0.18)] motion-reduce:transition-none ${placeholder ? '[--surface:rgb(250_250_250_/_0.45)]' : '[--surface:var(--planner-card-surface)]'}`}
        style={{ zIndex: 4 - Math.min(depth, 3), opacity: depth > 2 || (!active && pages[page].placeholder) ? 0 : 1, pointerEvents: active ? 'auto' : 'none', transformOrigin: 'left center', transform: active ? `translateX(${offset}px)` : `translateX(${Math.min(depth, 3) * 9.9}px) scale(${1 - Math.min(depth, 3) * .0108})`, transition: active && drag.current?.moved ? 'none' : 'transform var(--planner-page-motion), opacity 240ms ease', filter: !active ? `brightness(${1 - Math.min(depth, 3) * .07})` : undefined }}>
        <div className={`flex min-h-11 shrink-0 justify-between gap-2 pl-6 pr-4 ${titleEditor ? 'items-start' : 'items-center'}`}>
          {titleEditor || <h2 title={name} className={placeholder ? 'sr-only' : 'planner-page-heading min-w-0 truncate text-[14px] leading-[18px]'}>
            {onEditTitle ? <button data-folder-title type="button" aria-label={`Edit list title: ${name}`} onClick={onEditTitle} className="block min-h-9 max-w-full truncate rounded-lg text-left [font:inherit]! focus-visible:outline-2 focus-visible:outline-[#4F7A66]">{name}</button> : name}
          </h2>}
          <div role="tablist" aria-label="Planner pages" className="ml-auto flex h-11 max-w-[45%] shrink-0 items-center overflow-x-auto [scrollbar-width:none]">
            {pages.map(({ id: targetId, name: title }, target) => <button key={targetId} ref={active && page === target ? activeDot : undefined} type="button" role="tab" aria-label={title} aria-selected={page === target} aria-controls={`panel-page-${target}`} onClick={() => jump(target)} className="flex h-11 w-7 shrink-0 items-center justify-center focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">
              <span aria-hidden="true" className={`h-2 w-2 rounded-full ${page === target ? 'bg-[#4F7A66]' : 'bg-[#4F7A66]/15'}`} />
            </button>)}
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-hidden select-none">{content}</div>
        {!placeholder && addButton(folderListId)}
      </section>
    })}
    <div className="pointer-events-none absolute inset-0 z-[5] [&_button]:pointer-events-auto">{calendarButton}{folderBadge}</div>
  </div>
}
