import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { dateKey } from './calendarDates'
import { calendarTasksForDate, dotTypes, itemsForDate } from './taskSchedule'
import TaskDetail from './TaskDetail'
import { taskAccents, taskAppleColor } from './TaskApple'
import TaskRows from './TaskRows'
import CalendarEventCard from './CalendarEventCard'
import { weekdayNames } from './WeekdayPicker'
import { selectIntervalRange, selectRecurringMonths, selectWeekdaysInMonth } from './calendarSelection'
import { calendarMonths, visibleCalendarMonth } from './calendarStream'
import useTriggerExpansion from './useTriggerExpansion'

const recurrenceOptions = [['weekdays', 'Weekdays'], ['interval', 'Every x days'], ['months', 'Months']]
const monthLabels = Array.from({ length: 12 }, (_, index) => new Date(2026, index, 1).toLocaleDateString('en-US', { month: 'short' }))
const recurrenceChoice = 'min-h-8 rounded-lg border border-[#6E9A82]/35 bg-white/35 px-2 text-xs font-medium text-[#354D40] hover:bg-white/70 focus-visible:outline-2 focus-visible:outline-[#4F7A66]'

function CalendarAppleDots({ items }) {
  if (!items.length) return null
  const perSide = Math.max(4, Math.ceil(items.length / 4))
  const spacing = Math.min(6, 18 / (perSide - 1))
  const size = Math.min(4, spacing * .7)
  return <span aria-hidden="true" data-dot-layout={items.length > 4 ? 'square' : 'row'} className="pointer-events-none absolute inset-0">
    {items.map((task, index) => {
      const side = Math.floor(index / perSide)
      const sideCount = Math.min(perSide, items.length - side * perSide)
      const along = (index % perSide - (sideCount - 1) / 2) * spacing
      const [x, y] = [[-along, 12], [-12, -along], [along, -12], [12, along]][side]
      return <span key={task.id} className="absolute rounded-full" style={{
        width: size, height: size, backgroundColor: taskAppleColor(task),
        left: `calc(50% + ${x - size / 2}px)`, top: `calc(50% + ${y - size / 2}px)`,
      }} />
    })}
  </span>
}

export default function Calendar({ mode = 'view', tasks, lists, onClose, onPick, onToggle, onDeleteItem, onSaveItem, onAdd, onStep, multiLabel = 'Choose commitment dates', initialDates = [], initialDate = null, initialMonthPattern, confirmLabel, allowEmpty = false, selectionType = 'commitment', showHelpers = true, allowMultiGesture = false, triggerRef }) {
  const [gestureMulti, setGestureMulti] = useState(allowMultiGesture && initialDates.length > 1)
  const multi = mode === 'multi' || gestureMulti
  const hold = useRef(null)
  const suppressClick = useRef(false)
  useEffect(() => () => clearTimeout(hold.current?.timer), [])
  function cancelHold() { clearTimeout(hold.current?.timer); hold.current = null }
  function enableMulti(key) {
    cancelHold()
    if (!allowMultiGesture || mode === 'view') return
    suppressClick.current = true
    if (!multi) {
      setGestureMulti(true)
      setSelectedDates(new Set([...(selected ? [selected] : []), key]))
    } else selectDay(key)
  }
  const [today] = useState(() => new Date())
  const [month, setMonth] = useState(() => initialDate ? new Date(`${initialDate}T12:00:00`).getMonth() : today.getMonth())
  const [year, setYear] = useState(() => initialDate ? new Date(`${initialDate}T12:00:00`).getFullYear() : today.getFullYear())
  const [pickerYear, setPickerYear] = useState(year)
  const [streamStart, setStreamStart] = useState(year * 12 + month)
  const [monthCount, setMonthCount] = useState(12)
  const months = useMemo(() => calendarMonths(streamStart, monthCount), [streamStart, monthCount])
  const pendingScroll = useRef(initialDate || dateKey(today))
  const savedScroll = useRef(0)
  const restoredNode = useRef(null)
  const [monthsOpen, setMonthsOpen] = useState(false)
  const [helper, setHelper] = useState(initialMonthPattern ? 'months' : null)
  const [helperStart, setHelperStart] = useState(null)
  const [repeatMonths, setRepeatMonths] = useState(initialMonthPattern?.months || [])
  const [repeatDays, setRepeatDays] = useState(initialMonthPattern?.days || [])
  const [weekdays, setWeekdays] = useState([])
  const [interval, setInterval] = useState('')
  const validInterval = /^\d+$/.test(interval) && Number(interval) >= 2 && Number(interval) <= 30
  const [selected, setSelected] = useState(() => initialDate || (mode === 'view' ? dateKey(today) : null))
  const [selectedDates, setSelectedDates] = useState(() => new Set(initialDates))
  const [anchorDate, setAnchorDate] = useState(null)
  const [pickingStart, setPickingStart] = useState(false)
  const startButton = useRef(null)
  const [closing, setClosing] = useState(false)
  const [detailId, setDetailId] = useState(null)
  const [eventTask, setEventTask] = useState(null)
  const detailTrigger = useRef(null)
  const dialog = useRef(null)
  const windowRef = useRef(null)
  const daysList = useRef(null)
  const timer = useRef(null)
  const picked = useRef(false)
  const todayKey = dateKey(today)
  const recurrenceValid = !helper || (helper === 'weekdays' ? weekdays.length > 0 : helper === 'interval' ? validInterval : repeatMonths.length > 0 && repeatDays.length > 0)
  const displayedDates = useMemo(() => {
    if (helper === 'months') return recurrenceValid ? selectRecurringMonths(selectedDates, todayKey, repeatMonths, repeatDays) : new Set()
    if (!helper || !recurrenceValid || !helperStart) return selectedDates
    if (helper === 'weekdays') {
      const from = anchorDate || helperStart
      const month = new Date(`${from}T12:00:00`)
      return selectWeekdaysInMonth(selectedDates, month.getFullYear(), month.getMonth(), todayKey, weekdays, from)
    }
    const start = [todayKey, anchorDate || helperStart].sort().at(-1)
    const base = new Date(`${start}T12:00:00`)
    return selectIntervalRange(selectedDates, base.getFullYear(), base.getMonth(), todayKey, Number(interval), start)
  }, [helper, recurrenceValid, helperStart, selectedDates, todayKey, anchorDate, weekdays, interval, repeatMonths, repeatDays])
  const hasSelection = multi ? recurrenceValid && (allowEmpty || displayedDates.size > 0) : Boolean(selected)
  const selectedTasks = selected ? itemsForDate(mode === 'view' ? calendarTasksForDate(tasks, selected, todayKey) : tasks, selected) : []
  const monthName = new Date(year, month, 1).toLocaleDateString('en-US', { month: 'long' })
  const detailTask = tasks.find(task => task.id === detailId)
  function closeDetail() {
    setDetailId(null)
    requestAnimationFrame(() => {
      if (detailTrigger.current?.isConnected) detailTrigger.current.focus({ preventScroll: true })
      else dialog.current?.focus({ preventScroll: true })
    })
  }

  useEffect(() => {
    dialog.current?.focus({ preventScroll: true })
    return () => clearTimeout(timer.current)
  }, [])
  useLayoutEffect(() => {
    const element = daysList.current
    if (!element || (element === restoredNode.current && !pendingScroll.current)) return
    let top = savedScroll.current
    if (pendingScroll.current) {
      const target = new Date(`${pendingScroll.current}T12:00:00`)
      const targetMonth = months.find(item => item.year === target.getFullYear() && item.month === target.getMonth())
      top = targetMonth?.offset || 0
      const targetRow = Math.floor(((targetMonth?.leading || 0) + target.getDate() - 1) / 7)
      top += Math.max(0, 32 + (targetRow + 1) * 36 - element.clientHeight)
      pendingScroll.current = null
    }
    element.scrollTop = top
    savedScroll.current = top
    restoredNode.current = element
  }, [months, monthsOpen, pickingStart])
  useTriggerExpansion(windowRef, triggerRef, !closing)

  function jumpMonth(nextYear, nextMonth) {
    pendingScroll.current = nextYear === today.getFullYear() && nextMonth === today.getMonth() ? todayKey : dateKey(new Date(nextYear, nextMonth, 1, 12))
    setStreamStart(nextYear * 12 + nextMonth)
    setMonthCount(12)
    setYear(nextYear)
    setMonth(nextMonth)
    setMonthsOpen(false)
  }

  function scrollDays(event) {
    const element = event.currentTarget
    savedScroll.current = element.scrollTop
    const visible = visibleCalendarMonth(months, element.scrollTop)
    if (visible) { setYear(visible.year); setMonth(visible.month) }
    if (element.scrollHeight - element.scrollTop - element.clientHeight < 300) setMonthCount(previous => previous + 12)
  }

  function toggleHelper(next) {
    if (helper === next) { setHelper(null); return }
    if (next === 'months') {
      const from = anchorDate || helperStart
      const fromRule = (helper === 'weekdays' || helper === 'interval') && recurrenceValid && from
      const sourceMonth = fromRule ? (helper === 'interval' && from < todayKey ? todayKey : from).slice(0, 7) : null
      const dates = [...(fromRule ? displayedDates : selectedDates)]
        .filter(date => date >= todayKey && (!sourceMonth || date.startsWith(sourceMonth)))
      setRepeatDays([...new Set(dates.map(date => Number(date.slice(-2))))].sort((a, b) => a - b))
      if (sourceMonth && dates.length) {
        const monthNumber = Number(sourceMonth.slice(-2))
        setRepeatMonths(previous => previous.includes(monthNumber) ? previous : [...previous, monthNumber])
      }
    } else if (next === 'weekdays') {
      const monthStart = dateKey(new Date(year, month, 1, 12))
      setHelperStart(monthStart.slice(0, 7) === todayKey.slice(0, 7) ? todayKey : monthStart)
      setAnchorDate(null)
    } else if (!helper || helper === 'weekdays' || helper === 'months') {
      const monthStart = dateKey(new Date(year, month, 1, 12))
      const firstSelected = [...selectedDates].sort().find(date => date >= todayKey && date >= monthStart)
      setHelperStart(firstSelected || [todayKey, monthStart].sort().at(-1))
      setAnchorDate(null)
    }
    setHelper(next)
  }

  function close() {
    if (closing) return
    setClosing(true)
    timer.current = setTimeout(onClose, 200)
  }
  function selectDay(key) {
    if (!multi) { setSelected(key); return }
    if (helper === 'months') {
      const day = Number(key.slice(-2))
      setRepeatDays(previous => previous.includes(day) ? previous.filter(value => value !== day) : [...previous, day].sort((a, b) => a - b))
      return
    }
    const next = new Set(displayedDates)
    if (helper) setHelper(null)
    if (next.has(key)) {
      next.delete(key)
      if (anchorDate === key) setAnchorDate([...next].filter(date => date >= todayKey).sort().at(-1) || null)
    } else { next.add(key); setAnchorDate(key) }
    setSelectedDates(next)
    const picked = new Date(`${key}T12:00:00`)
    setYear(picked.getFullYear())
    setMonth(picked.getMonth())
  }
  function keys(event) {
    if (event.key === 'Escape') { event.preventDefault(); close() }
    if (event.key !== 'Tab') return
    const controls = Array.from(dialog.current.querySelectorAll('button:not(:disabled), input:not(:disabled)'))
    const first = controls[0], last = controls.at(-1)
    if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog.current)) { event.preventDefault(); last?.focus() }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
  }

  return <><div ref={dialog} inert={Boolean(detailTask) || Boolean(eventTask) || pickingStart} tabIndex={-1} role="dialog" aria-modal={!detailTask && !eventTask && !pickingStart} aria-label={mode === 'view' ? 'Calendar and tasks' : mode === 'multi' ? multiLabel : 'Choose a task date'} onKeyDown={keys} onClick={close} className={`add-menu-backdrop absolute inset-0 z-40 bg-[#2E2A25]/20 backdrop-blur-[3px] outline-none ${closing ? 'is-closing' : ''} ${triggerRef ? 'calendar-from-trigger' : ''}`}>
    <div ref={windowRef} className="add-menu-window pointer-events-none absolute inset-0">
      <div onClick={event => event.stopPropagation()} className="calendar-surface task-scroll pointer-events-auto absolute left-1/2 top-1/2 flex max-h-[calc(100%-24px)] w-[90%] max-w-md -translate-x-1/2 -translate-y-1/2 flex-col gap-3 overflow-y-auto overscroll-contain rounded-[28px] bg-[#F8F4E8] p-4 text-[#2E2A25] shadow-xl">
        <div className="shrink-0 rounded-2xl border border-[#6E9A82]/30 bg-white/35">
          <button type="button" onClick={() => { if (!monthsOpen) setPickerYear(year); setMonthsOpen(value => !value) }} aria-expanded={monthsOpen} aria-label={`Choose month, ${monthName} ${year}`} className="flex min-h-10 w-full items-center justify-between rounded-t-2xl px-3 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-[#4F7A66]">
            <span>{monthName} {year}</span><span aria-hidden="true" className={monthsOpen ? 'rotate-180' : ''}>⌄</span>
          </button>
          {monthsOpen ? <div className="flex h-[min(34dvh,256px)] min-h-32 flex-col px-3 pb-2" aria-label={`Months of ${pickerYear}`}>
          <div className="flex h-11 shrink-0 items-center justify-center text-[#2E2A25]">
            <button type="button" aria-label="Previous year" onClick={() => setPickerYear(value => value - 1)} className="flex h-11 w-11 items-center justify-center rounded-full transition active:bg-[#E9C46A] focus-visible:outline-2 focus-visible:outline-[#4F7A66]"><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="m14 6-6 6 6 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg></button>
            <span aria-live="polite" className="min-w-[72px] text-center text-[15px] font-semibold">{pickerYear}</span>
            <button type="button" aria-label="Next year" onClick={() => setPickerYear(value => value + 1)} className="flex h-11 w-11 items-center justify-center rounded-full transition active:bg-[#E9C46A] focus-visible:outline-2 focus-visible:outline-[#4F7A66]"><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="m10 6 6 6-6 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg></button>
          </div>
          <div className="grid min-h-0 flex-1 grid-cols-3 grid-rows-4">
            {Array.from({ length: 12 }, (_, index) => <button key={index} type="button" aria-pressed={year === pickerYear && month === index} aria-label={new Date(pickerYear, index, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })} onClick={() => jumpMonth(pickerYear, index)} className={`rounded-full text-[14px] font-semibold text-[#2E2A25] transition active:bg-[#E9C46A] focus-visible:outline-2 focus-visible:outline-[#4F7A66] ${pickerYear === today.getFullYear() && index === today.getMonth() ? 'bg-[#E9C46A] ring-1 ring-inset ring-[#4F7A66]' : ''}`}>{new Date(pickerYear, index, 1).toLocaleDateString('en-US', { month: 'short' })}</button>)}
          </div>
        </div> : <>
          <div aria-hidden="true" className="grid grid-cols-7 border-y border-[#6E9A82]/20 px-2 py-1 text-center text-[10px] font-semibold text-[#595F55]">
            {weekdayNames.map(day => <span key={day} className="capitalize">{day}</span>)}
          </div>
          <div ref={daysList} data-calendar-mode={mode} onScroll={scrollDays} className="calendar-scroll h-[min(34dvh,256px)] min-h-28 overflow-y-auto overscroll-contain px-2" aria-label="Scrollable calendar months">
            {months.map(displayMonth => {
              const label = new Date(displayMonth.year, displayMonth.month, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
              return <section key={displayMonth.serial} aria-label={label}>
                <div className="flex h-8 items-center px-1 text-xs font-semibold text-[#595F55]">{label}</div>
                <div className="grid grid-cols-7">
                {Array.from({ length: displayMonth.leading }, (_, index) => <span key={`empty-${index}`} aria-hidden="true" />)}
            {displayMonth.days.map(day => {
              const key = dateKey(day)
              const disabled = mode !== 'view' && key < todayKey
              const isSelected = multi ? displayedDates.has(key) : selected === key
              const overviewItems = mode === 'view' ? itemsForDate(calendarTasksForDate(tasks, key, todayKey), key) : null
              const dots = overviewItems ? null : dotTypes(tasks, key)
              const count = overviewItems?.length
              return <button key={key} type="button" disabled={disabled} aria-pressed={isSelected} aria-current={key === todayKey ? 'date' : undefined} aria-label={`${day.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}${count ? `, ${count} ${count === 1 ? 'task' : 'tasks'}` : ''}${dots?.quick || dots?.commitment ? ', has tasks' : ''}${dots?.habit ? ', has habits' : ''}`} onPointerDown={event => { if (!allowMultiGesture || mode === 'view' || event.pointerType === 'mouse') return; cancelHold(); hold.current = { x: event.clientX, y: event.clientY, timer: setTimeout(() => enableMulti(key), 450) } }} onPointerMove={event => { if (hold.current && Math.hypot(event.clientX - hold.current.x, event.clientY - hold.current.y) > 10) cancelHold() }} onPointerUp={cancelHold} onPointerCancel={cancelHold} onContextMenu={event => { if (allowMultiGesture) event.preventDefault() }} onDoubleClick={() => { enableMulti(key); suppressClick.current = false }} onClick={() => { if (suppressClick.current) { suppressClick.current = false; return } selectDay(key) }} className="relative flex h-9 min-w-0 items-center justify-center rounded-lg text-[#2E2A25] transition active:bg-[#E9C46A]/50 disabled:cursor-default disabled:opacity-35 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">
                <span style={mode === 'view' ? { backgroundColor: isSelected ? '#D7E7EF' : key === todayKey ? '#D8D8D2' : undefined } : undefined} className={`flex size-8 max-w-full items-center justify-center rounded-lg ${mode !== 'view' && isSelected ? 'bg-[#E9C46A]' : ''} ${mode !== 'view' && key === todayKey ? 'ring-1 ring-inset ring-[#4F7A66]' : ''}`}><span className="text-sm font-semibold leading-none">{day.getDate()}</span></span>
                {overviewItems ? <CalendarAppleDots items={overviewItems} /> : <span aria-hidden="true" className="absolute inset-x-0 bottom-0.5 flex items-center justify-center gap-0.5">
                  {dots.quick && <span className="h-1 w-1 rounded-full" style={{ backgroundColor: taskAccents.quick }} />}
                  {dots.commitment && <span className="h-1 w-1 rounded-full" style={{ backgroundColor: taskAccents.commitment }} />}
                  {dots.habit && <span className="h-1 w-1 rounded-full" style={{ backgroundColor: taskAccents.habit }} />}
                  {dots.goalStep && <span className="h-1 w-1 rounded-full" style={{ backgroundColor: taskAccents.goal }} />}
                  {dots.goalDeadline && <span className="h-2 w-2 rounded-full" style={{ backgroundColor: taskAccents.goal }} />}
                  {multi && isSelected && !(selectionType === 'goal' ? dots.goalStep || dots.goalDeadline : dots[selectionType]) && <span className="h-1 w-1 rounded-full" style={{ backgroundColor: taskAccents[selectionType] }} />}
                </span>}
              </button>
            })}
                </div>
              </section>
            })}
          </div>
          </>}
        </div>
        {mode !== 'view' && multi && showHelpers && <section aria-label="Recurrence" className="shrink-0 rounded-2xl border border-[#6E9A82]/30 bg-white/30 p-2.5">
          <div className="grid grid-cols-[1fr_1.6fr] items-start gap-2">
            <span className="pt-2 text-xs font-medium text-[#62665E]">Recurrence</span>
            <div className="grid gap-1.5">
              {recurrenceOptions.map(([id, label]) => <button key={id} type="button" aria-pressed={helper === id} onClick={() => toggleHelper(id)} className={`${recurrenceChoice} text-left ${helper === id ? 'calendar-recurrence-selected' : ''}`}>
                {label}{helper === id && <span className="float-right" aria-hidden="true">✓</span>}
              </button>)}
            </div>
          </div>
          {helper && <div className="mt-2 grid gap-2 border-t border-[#6E9A82]/25 pt-2">
            {helper !== 'months' && <button ref={startButton} type="button" aria-haspopup="dialog" onClick={() => setPickingStart(true)} className={recurrenceChoice}>
              Starting from {new Date(`${anchorDate || helperStart}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </button>}
            {helper === 'weekdays' && <div className="grid grid-cols-7 gap-1" aria-label="Choose weekdays">
              {weekdayNames.map((name, index) => <button key={name} type="button" aria-pressed={weekdays.includes(index + 1)} onClick={() => setWeekdays(previous => previous.includes(index + 1) ? previous.filter(day => day !== index + 1) : [...previous, index + 1])} className={`${recurrenceChoice} px-0! capitalize ${weekdays.includes(index + 1) ? 'calendar-recurrence-selected' : ''}`}>{name}</button>)}
            </div>}
            {helper === 'interval' && <label className="flex items-center gap-2 text-xs">Every
              <input aria-label="Interval in days, 2 to 30" type="number" min="2" max="30" inputMode="numeric" placeholder="3" value={interval} onChange={event => setInterval(event.target.value)} className="h-9 w-14 rounded-lg border border-[#6E9A82]/40 px-1 text-center text-base outline-[#4F7A66]" />days
            </label>}
            {helper === 'months' && <><p className="text-xs text-[#595F55]">Tap day numbers in the calendar and choose the months to repeat them in.</p>
            <p aria-live="polite" className="text-xs text-[#354D40]">{repeatDays.length ? `Days: ${repeatDays.join(', ')}` : 'No days selected'}</p>
            <div className="grid grid-cols-4 gap-1" aria-label="Choose recurring months">
              {monthLabels.map((name, index) => <button key={name} type="button" aria-pressed={repeatMonths.includes(index + 1)} onClick={() => setRepeatMonths(previous => previous.includes(index + 1) ? previous.filter(month => month !== index + 1) : [...previous, index + 1])} className={`${recurrenceChoice} ${repeatMonths.includes(index + 1) ? 'calendar-recurrence-selected' : ''}`}>{name}</button>)}
            </div></>}
          </div>}
        </section>}
        {mode !== 'view' ? <button type="button" disabled={!hasSelection || closing} onClick={() => {
          if (!hasSelection || picked.current) return
          picked.current = true
          const recurrencePattern = helper === 'interval' ? { interval: Number(interval) } : helper === 'weekdays' ? { weekdays } : undefined
          onPick(multi ? [...displayedDates].sort() : selected, {
            recurrence: multi ? helper : null, recurrencePattern: multi ? recurrencePattern : undefined,
            monthPattern: multi && helper === 'months' ? { months: repeatMonths, days: repeatDays } : undefined,
          })
        }} className="min-h-11 w-full shrink-0 rounded-full bg-[#4F7A66] px-3 text-sm font-semibold text-[#F8F4E8] transition active:scale-[0.98] disabled:cursor-default focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4F7A66]">{gestureMulti ? `Apply ${displayedDates.size} dates` : confirmLabel || (multi ? 'Apply dates' : 'Add for this day')}</button> :
        <div className="relative h-[min(27dvh,230px)] min-h-24 shrink-0 overflow-hidden rounded-xl border border-[#6E9A82]/30 bg-white/35">
          <TaskRows key={selected} items={selectedTasks} appleSize={15} onComplete={item => onToggle(item.id, selected)} onEdit={(item, event) => { detailTrigger.current = event.currentTarget; setDetailId(item.id) }} onShare={setEventTask} onStep={onStep} />
      {onAdd && <button type="button" aria-label="Add an item" disabled={closing} onClick={event => { event.stopPropagation(); if (closing) return; setClosing(true); timer.current = setTimeout(onAdd, 200) }} className="absolute bottom-4 right-4 flex h-[46.08px] w-[46.08px] items-center justify-center rounded-full bg-[#F8F4E8] text-[27.84px] font-normal leading-none text-[#2E2A25] transition active:scale-95 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4F7A66]">+</button>}
        </div>}
      </div>
    </div>
  </div>
    {detailTask && <TaskDetail key={detailTask.id} task={detailTask} lists={lists} occurrenceDate={selected} commitmentDates={detailTask.commitmentId ? tasks.filter(task => task.commitmentId === detailTask.commitmentId).map(task => task.date).sort() : []} onClose={closeDetail} onCalendarOptions={() => { setEventTask({ ...detailTask, date: selected }); setDetailId(null) }} onDelete={whole => { onDeleteItem(detailTask.id, selected, whole); closeDetail() }} onSave={updated => { onSaveItem(updated); closeDetail() }} />}
    {eventTask && <CalendarEventCard task={eventTask} onClose={() => { setDetailId(eventTask.id); setEventTask(null) }} />}
    {pickingStart && <Calendar mode="pick" tasks={tasks} initialDate={anchorDate && anchorDate >= todayKey ? anchorDate : todayKey} confirmLabel="Use start date" onClose={() => { setPickingStart(false); requestAnimationFrame(() => startButton.current?.focus({ preventScroll: true })) }} onPick={date => {
      setAnchorDate(date)
      const start = new Date(`${date}T12:00:00`)
      jumpMonth(start.getFullYear(), start.getMonth())
      pendingScroll.current = date
      setPickingStart(false)
      requestAnimationFrame(() => startButton.current?.focus({ preventScroll: true }))
    }} />}
  </>
}
