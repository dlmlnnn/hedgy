import { useEffect, useRef, useState } from 'react'
import './WipeableClouds.css'

const clouds = [
  { left: 'calc(46% - var(--cloud-first-width) * .2)', top: 'calc(var(--cloud-sky-start) - var(--cloud-height) * .1)', width: 'var(--cloud-first-width)', height: 'var(--cloud-height)', delay: '0s' },
  { left: 'min(calc(var(--cloud-second-left) + var(--cloud-second-width) * .1), calc(99% - var(--cloud-second-width)))', top: 'calc(var(--cloud-second-top) - var(--cloud-height) * .1)', width: 'var(--cloud-second-width)', height: 'var(--cloud-height)', delay: '1s' },
]
const legacyCloud = { ...clouds[0], left: 'var(--cloud-legacy-left)', width: 'var(--cloud-legacy-width)' }
const classicClouds = [
  { left: '-6%', top: '9%', width: '39%', height: '27%' },
  { left: '45%', top: '21%', width: '36%', height: '31%' },
  { left: '70%', top: '47%', width: '37%', height: '30%' },
]
// Each layer has its own footprint, slant and density. Small wisps break up the cloud bank.
const cloudPuffs = [
  [[318,166,205,94,-.13,.40], [484,144,218,115,.10,.53], [634,162,208,81,-.13,.39],
    [421,106,116,90,.12,.43], [568,91,108,75,-.08,.31], [718,130,141,63,.15,.33],
    [223,130,121,53,-.14,.34], [280,205,172,51,-.14,.27], [647,213,167,41,.20,.29],
    [851,162,116,29,.24,.19], [136,184,96,31,-.24,.17]],
  [[375,150,195,92,.15,.44], [545,166,210,109,-.11,.50], [706,156,187,85,.13,.39],
    [350,106,116,67,.13,.36], [496,87,120,72,-.19,.43], [601,119,98,64,.17,.31],
    [742,107,113,68,.14,.35], [831,178,117,49,.23,.25], [458,221,203,47,-.18,.24],
    [218,166,156,43,-.20,.23], [153,204,88,23,-.18,.16]],
  [[325,148,228,101,-.18,.46], [504,134,192,103,.08,.49], [659,168,244,82,.14,.39],
    [320,105,130,71,-.12,.33], [478,86,101,71,.22,.38], [627,117,121,65,.18,.36],
    [760,135,153,57,.11,.29], [223,193,133,49,-.25,.24], [513,214,179,39,.13,.25],
    [843,198,118,27,.20,.16], [117,156,86,28,-.25,.16]],
]

function paintCloud(ctx, index) {
  for (const [x, y, width, height, slant, opacity] of cloudPuffs[index]) {
    ctx.save()
    ctx.translate(x, y)
    ctx.transform(width, slant * height, slant * width, height, 0, 0)
    const mist = ctx.createRadialGradient(-.23, -.26, .03, 0, 0, 1)
    mist.addColorStop(0, `rgba(255,252,246,${opacity})`)
    mist.addColorStop(.36, `rgba(250,248,242,${opacity * .72})`)
    mist.addColorStop(.72, `rgba(242,243,239,${opacity * .26})`)
    mist.addColorStop(1, 'rgba(242,243,239,0)')
    ctx.fillStyle = mist
    ctx.fillRect(-1, -1, 2, 2)
    ctx.restore()
  }
}

function ClassicCloud({ shape, index }) {
  const canvas = useRef(null)
  useEffect(() => {
    const node = canvas.current
    const observer = new ResizeObserver(() => {
      const ratio = Math.min(window.devicePixelRatio || 1, 2)
      node.width = Math.max(1, Math.round(node.clientWidth * ratio))
      node.height = Math.max(1, Math.round(node.clientHeight * ratio))
      const ctx = node.getContext('2d')
      ctx.scale(node.width / 1000, node.height / 300)
      paintCloud(ctx, index)
    })
    observer.observe(node)
    return () => observer.disconnect()
  }, [index])
  return <canvas ref={canvas} className="classic-cloud absolute" style={{ ...shape, animationDelay: `-${index * 9}s` }} />
}
const notesKey = 'team-b-2:cloudNotes'
function loadNotes() {
  try {
    const saved = JSON.parse(localStorage.getItem(notesKey) || '{}')
    return Object.fromEntries(Object.entries(saved).filter(([key, value]) => /^[0-2]$/.test(key) && typeof value?.note === 'string' && value.note.trim()).map(([key, value]) => [key, { note: value.note.slice(0, 100), points: Array.isArray(value.points) ? value.points.filter(point => Array.isArray(point) && point.length === 2 && point.every(Number.isFinite)).slice(-5000) : [] }]))
  } catch { return {} }
}

function ScratchCloud({ shape, index, saved, onSave, textColor, mode }) {
  const notesEnabled = mode === 'notes'
  const canvas = useRef(null)
  const last = useRef(null)
  const points = useRef(saved?.points || [])
  const gesture = useRef(null)
  const [note, setNote] = useState(saved?.note || '')
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState('')
  const input = useRef(null)
  const [cleared, setCleared] = useState(false)
  const [peel, setPeel] = useState(null)
  const peelTimer = useRef(null)
  const erase = useRef(null)
  useEffect(() => { if (editing) input.current?.focus() }, [editing])
  useEffect(() => {
    if (!cleared) return
    const timer = setTimeout(() => {
      points.current = []
      setNote('')
      setEditing(false)
      setPeel(null)
      setCleared(false)
    }, 60000)
    return () => clearTimeout(timer)
  }, [cleared])
  function editNote() { setDraft(note); setEditing(true) }
  function addNote(event) {
    event.preventDefault()
    const text = draft.trim()
    if (!text) return
    points.current = []
    setNote(text)
    onSave(index, { note: text, points: [] })
    setEditing(false)
    input.current?.blur()
  }

  useEffect(() => {
    const node = canvas.current
    if (!node) return
    let active = true
    function paint() {
      const rect = node.getBoundingClientRect()
      const ratio = Math.min(window.devicePixelRatio || 1, 2)
      node.width = Math.max(1, Math.round(rect.width * ratio))
      node.height = Math.max(1, Math.round(rect.height * ratio))
      const ctx = node.getContext('2d')
      ctx.scale(node.width / 1000, node.height / 300)
      paintCloud(ctx, index)
      if (note) {
        ctx.save()
        ctx.setTransform(ratio, 0, 0, ratio, 0, 0)
        ctx.font = '400 14.2025px "Carlton Std", "Fredoka One", Nunito, sans-serif'
        ctx.letterSpacing = '0.710125px' // 0.05em at the cloud-note font size.
        ctx.fillStyle = textColor
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        const lines = []
        let line = ''
        for (const character of note) {
          if (ctx.measureText(line + character).width > rect.width * .76 && line) { lines.push(line); line = '' }
          line += character
        }
        if (line) lines.push(line)
        const scale = Math.min(1, (rect.height - 2) / (lines.length * 18.4))
        ctx.translate(rect.width / 2, rect.height / 2)
        ctx.scale(1, scale)
        lines.forEach((text, i) => ctx.fillText(text, 0, (i - (lines.length - 1) / 2) * 18.4))
        ctx.restore()
      }
      erase.current = (x, y) => {
        ctx.save()
        // A round brush in screen space, with feathered edges.
        ctx.setTransform(ratio, 0, 0, ratio, 0, 0)
        const px = x * rect.width, py = y * rect.height
        const radius = 19
        const brush = ctx.createRadialGradient(px, py, 0, px, py, radius)
        brush.addColorStop(0, 'rgba(0,0,0,1)')
        brush.addColorStop(.65, 'rgba(0,0,0,.95)')
        brush.addColorStop(1, 'rgba(0,0,0,0)')
        ctx.globalCompositeOperation = 'destination-out'
        ctx.fillStyle = brush
        ctx.fillRect(px - radius, py - radius, radius * 2, radius * 2)
        ctx.restore()
      }
      points.current.forEach(point => erase.current(...point))
    }
    const observer = new ResizeObserver(paint)
    observer.observe(node)
    Promise.allSettled(['Carlton Std', 'Fredoka One'].map(font => document.fonts?.load(`400 14.2025px "${font}"`))).then(() => { if (active) paint() })
    return () => { active = false; observer.disconnect(); clearTimeout(peelTimer.current) }
  }, [note, textColor, cleared])

  function scratch(event) {
    const rect = canvas.current.getBoundingClientRect()
    const point = [(event.clientX - rect.left) / rect.width, (event.clientY - rect.top) / rect.height]
    const previous = last.current || point
    const steps = Math.max(1, Math.ceil(Math.hypot((point[0] - previous[0]) * rect.width, (point[1] - previous[1]) * rect.height) / 4))
    for (let i = 1; i <= steps; i++) {
      const position = [previous[0] + (point[0] - previous[0]) * i / steps, previous[1] + (point[1] - previous[1]) * i / steps]
      points.current.push(position)
      erase.current?.(...position)
    }
    last.current = point
    setPeel({ x: point[0] * 100, y: point[1] * 100, id: event.timeStamp })
    clearTimeout(peelTimer.current)
    peelTimer.current = setTimeout(() => setPeel(null), 350)
  }
  function finish(event) {
    const active = gesture.current
    gesture.current = null
    last.current = null
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId)
    if (!active) return
    if (!active.moved) {
      if (notesEnabled && event.type !== 'pointercancel') editNote()
      return
    }
    const node = canvas.current, ctx = node.getContext('2d')
    const pixels = ctx.getImageData(0, 0, node.width, node.height).data
    let remaining = 0
    for (let i = 3; i < pixels.length; i += 16) if (pixels[i] > 30) remaining++
    if (remaining / (pixels.length / 16) < .015) { setCleared(true); onSave(index, null); return }
    if (note) {
      const rect = node.getBoundingClientRect()
      let rubbed = 0
      for (let x = 0; x < 15; x++) {
        const px = (.2 + x * .6 / 14) * rect.width
        if (points.current.some(([a,b]) => Math.hypot(a * rect.width - px, b * rect.height - rect.height / 2) < 15)) rubbed++
      }
      if (rubbed >= 11) { setNote(''); onSave(index, null) }
      else onSave(index, { note, points: points.current.slice(-5000) })
    }
  }
  if (cleared) return null
  return <div className={`wipeable-cloud ${saved ? 'cloud-has-note' : ''}`} style={{ ...shape, zIndex: editing ? 20 : undefined, animationDelay: saved ? '0s' : shape.delay }}>
    <canvas ref={canvas} role="button" tabIndex={editing ? -1 : 0} aria-label={`Wipe away cloud ${index + 1}`} aria-description={note ? `Note: ${note}. Tap to edit, drag to erase.` : notesEnabled ? 'Tap to add a note, drag to wipe away.' : 'Drag or press Enter to wipe away.'} className="h-full w-full touch-none rounded-full outline-offset-2 focus-visible:outline-2 focus-visible:outline-[#6E9A82]"
      onKeyDown={event => {
        const activate = event.key === 'Enter' || event.key === ' '
        if (activate) event.preventDefault()
        if (activate && notesEnabled) editNote()
        if (event.key === 'Delete' || (activate && !notesEnabled)) { setCleared(true); onSave(index, null) }
      }}
      onPointerDown={event => { if (event.button !== 0 || editing) return; event.stopPropagation(); last.current = null; gesture.current = { x: event.clientX, y: event.clientY, moved: false }; event.currentTarget.setPointerCapture(event.pointerId) }}
      onPointerMove={event => { const start = gesture.current; if (start && event.currentTarget.hasPointerCapture(event.pointerId)) { event.stopPropagation(); if (!start.moved && Math.hypot(event.clientX - start.x, event.clientY - start.y) > 8) { start.moved = true; const rect = canvas.current.getBoundingClientRect(); last.current = [(start.x - rect.left) / rect.width, (start.y - rect.top) / rect.height] } if (start.moved) scratch(event) } }}
      onPointerUp={finish} onPointerCancel={finish} />
    {editing && <form onSubmit={addNote} onPointerDown={event => event.stopPropagation()} onClick={event => event.stopPropagation()} className="cloud-note-editor absolute left-[8%] top-[10%] flex w-[84%] flex-col gap-1 rounded-2xl bg-(--surface)/95 p-1.5 shadow-sm">
      <input ref={input} aria-label={`Note for cloud ${index + 1}`} maxLength={100} placeholder="A little thought…" value={draft} onChange={event => setDraft(event.target.value)} onKeyDown={event => { if (event.key === 'Escape') { setEditing(false); canvas.current?.focus() } }} className="min-h-11 min-w-0 rounded-xl bg-transparent px-2 text-[16px] text-[#2E2A25] outline-[#6E9A82]" />
      <div className="flex justify-end gap-1"><button type="button" aria-label="Cancel cloud note" onClick={() => setEditing(false)} className="min-h-11 min-w-11 rounded-full text-[#65756D]">×</button><button type="submit" disabled={!draft.trim()} className="min-h-11 rounded-full bg-[#4F7A66] px-4 text-[13px] font-semibold text-[#F8F4E8] disabled:opacity-40">Add</button></div>
    </form>}
    {peel && <span key={peel.id} aria-hidden="true" className="cloud-peel" style={{ left: `${peel.x}%`, top: `${peel.y}%` }} />}
  </div>
}

export default function WipeableClouds({ daylight, mode = 'classic' }) {
  const [savedNotes, setNotes] = useState(loadNotes)
  const notes = mode === 'notes' ? savedNotes : {}
  const [initialClouds] = useState(() => Object.keys(savedNotes).map(Number))
  // Reuse an empty right-side slot for a note from the former left cloud.
  const useLegacySlot = mode === 'notes' && initialClouds.includes(0)
  const cloudIds = useLegacySlot && !initialClouds.includes(1) ? [0, 2] :
    useLegacySlot && !initialClouds.includes(2) ? [1, 0] : [1, 2]
  const showLegacyCloud = Boolean(notes[0]) && !cloudIds.includes(0)
  const sky = daylight?.sky || '#C5D7D5'
  const night = daylight?.phase === 'night'
  const textColor = '#' + [1, 3, 5].map(offset => {
    const channel = parseInt(sky.slice(offset, offset + 2), 16)
    return Math.round(night ? channel + (255 - channel) * .5 : channel * .82).toString(16).padStart(2, '0')
  }).join('')
  function saveNote(index, record) {
    if (mode !== 'notes') return
    setNotes(previous => {
      const next = { ...previous }
      if (record?.note) next[index] = record
      else delete next[index]
      try { localStorage.setItem(notesKey, JSON.stringify(next)) } catch { /* Notes still work in this session. */ }
      return next
    })
  }
  if (mode === 'classic') return <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-(--planner-header-height) overflow-hidden">
    {classicClouds.map((shape, index) => <ClassicCloud key={shape.left} shape={shape} index={index} />)}
  </div>
  return <div className="cloud-sky pointer-events-none absolute inset-0" data-extra-note={showLegacyCloud || undefined} aria-label="Drifting sky clouds">
    {cloudIds.map((index, slot) => <ScratchCloud key={`${mode}:${index}`} shape={clouds[slot]} index={index} saved={notes[index]} onSave={saveNote} textColor={textColor} mode={mode} />)}
    {showLegacyCloud && <ScratchCloud key={0} shape={legacyCloud} index={0} saved={notes[0]} onSave={saveNote} textColor={textColor} mode={mode} />}
  </div>
}
