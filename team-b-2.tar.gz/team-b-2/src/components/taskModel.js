import { dateKey } from './calendarDates.js'

export const typeNames = { quick: 'Quick task', commitment: 'Commitment', habit: 'Habit', goal: 'Long term goal' }
export const taskType = task => task.type === 'goal' || task.type === 'habit' ? task.type : task.commitmentId || task.type === 'commitment' ? 'commitment' : 'quick'
export const isRecurringTask = task => task.type === 'habit' || (taskType(task) === 'commitment' && task.rule === 'schedule')
// Quick tasks remain independent records, with independent completion and tree apples.
export function expandTaskDates(task, makeId = () => crypto.randomUUID()) {
  if (task.type !== 'quick' || !task.scheduledDates?.length) return [normalizeTask(task)]
  const dates = [...new Set(task.scheduledDates)].sort()
  const primary = dates.includes(task.date) ? task.date : dates[0]
  return dates.map(date => normalizeTask({ ...task, scheduledDates: undefined, originalDate: undefined, date, startDate: date,
    ...(date === primary ? {} : { id: makeId(), completed: false, done: false, completedAt: null, completedDates: [], completionTimes: {} }) }))
}
export function normalizeTask(task) {
  const type = taskType(task)
  let completed = isRecurringTask(task) ? false : type === 'goal' && !task.steps && task.completedDates ? task.completedDates.includes(task.deadline) : Boolean(task.completed ?? task.done)
  const steps = task.steps || (type === 'goal' ? (task.stepDates || []).map((date, index) => ({ id: `${task.id}-step-${date}`, title: `Step ${index + 1}`, startDate: date, endDate: date, completed: task.completedDates?.includes(date) || false, completedAt: task.completionTimes?.[date] || null })) : [])
  if (type === 'goal' && steps.length) completed = Boolean(task.completedAsWhole) || steps.every(step => step.completed)
  const unscheduled = type === 'quick' && task.date === null
  return { ...task, type, completed, done: completed, date: unscheduled ? null : (type === 'quick' ? task.originalDate : null) || task.date || task.startDate || task.deadline, startDate: unscheduled ? null : task.startDate || task.date, stepDates: task.stepDates || [], steps, completedDates: [...new Set(task.completedDates || [])], completionTimes: task.completionTimes || {}, excludedDates: [...new Set(task.excludedDates || [])] }
}
export function newTask(type = 'quick') {
  const today = dateKey(new Date())
  return normalizeTask({ id: crypto.randomUUID(), type, title: '', description: '', date: today, startDate: today, deadline: today, time: '', rule: 'schedule', weekdays: [], months: [], completed: false, done: false })
}
export function validateTask(task) {
  if (!task.title.trim()) return 'Please enter a title.'
  if (isRecurringTask(task) || task.type === 'commitment') {
    if (task.cadence === 'dates') return task.dates?.length ? '' : 'Choose at least one date.'
    if (!task.startDate || !task.months?.length) return 'Choose a starting date and at least one month.'
    if (task.cadence === 'interval') {
      if (!Number.isInteger(task.interval) || task.interval < 2 || task.interval > 30) return 'Choose an interval from 2 to 30 days.'
    } else if (!task.weekdays?.length) return 'Choose at least one weekday or Every x days.'
  } else if (task.type === 'goal') {
    if (!task.startDate || !task.deadline || task.deadline < task.startDate) return 'The end date must be on or after the start date.'
    if ((task.steps || []).some(step => !step.title.trim() || !step.startDate || !step.endDate || step.endDate < step.startDate || step.startDate < task.startDate || step.endDate > task.deadline)) return 'Each step needs a title and a valid date range within the goal.'
  } else if (!task.date) return 'Choose a scheduled date.'
  return ''
}
export function isOverdue(task, now = new Date()) {
  if (task.completed ?? task.done) return false
  const date = task.type === 'goal' ? task.deadline : task.date
  if (!date) return false
  // Untimed items remain ongoing for their whole scheduled day.
  if (!task.time) return date < dateKey(now)
  return new Date(`${date}T${task.time}:00`) <= now
}
