import { useEffect, useRef, useState } from 'react'

export default function AppleCollection({ event, onFinished, onLanded }) {
  const visit = event.kind === 'visit'
  const celebration = visit || event.kind === 'goal-final'
  const [message] = useState(() => {
    if (event.message) return event.message
    const alternatives = ['bless you', 'see you tomorrow', 'you’re kind', 'danke', 'keep it up folk👍', 'merci']
    return Math.random() < 0.3 ? 'thanks' : alternatives[Math.floor(Math.random() * alternatives.length)]
  })
  const bubbleWidth = Math.max(53, message.length * 5.5 + 18)
  const finish = useRef(onFinished)
  const landed = useRef(onLanded)
  finish.current = onFinished
  landed.current = onLanded
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const timer = setTimeout(() => finish.current(), celebration ? (reduced ? 3000 : 7000) : reduced ? 1600 : 5600)
    const fallTimer = visit ? null : setTimeout(() => landed.current?.(), reduced ? 0 : 900)
    return () => { clearTimeout(timer); clearTimeout(fallTimer) }
  }, [event.id])
  return <div data-hedgehog-visit={celebration || undefined} data-falling-anchor={event.anchorIndex} data-landing-x={event.startX} data-landing-y={event.landY} style={{ '--apple-start-x': `${event.startX}px`, '--apple-start-y': `${event.startY}px`, '--apple-land-y': `${event.landY}px`, '--hedgehog-pickup-x': `${event.startX - 3}px`, '--hedgehog-pickup-y': `${event.landY - 25}px` }} className="pointer-events-none absolute inset-x-0 top-0 z-10 h-(--planner-header-height)" role="status" aria-label={visit ? `A hedgehog stops by the tree and says ${message}.` : `An apple falls. A hedgehog collects it and says ${message}.`}>
    <svg aria-hidden="true" className={`h-full w-full overflow-visible ${celebration ? 'goal-visit-feedback' : ''}`} viewBox="0 0 393 250" preserveAspectRatio="none">
      {!visit && <g className="collection-falling-apple">
        <path d="m0-4 1-3" stroke="#6C7955" strokeWidth="1" strokeLinecap="round" /><circle r="5.2" fill={event.color} /><ellipse cx="-1.5" cy="-1.5" rx="1" ry="1.5" fill="#F8F4E8" opacity=".5" />
      </g>}
      <g className="collection-hedgehog">
        <g className="hedgehog-step">
          <ellipse cx="32" cy="35" rx="29" ry="3" fill="#625848" opacity=".12" />
          <path d="m17 34 3-5m23 5 3-5" fill="none" stroke="#79674F" strokeWidth="3" strokeLinecap="round" />
          <path d="M15 28 13 19l5-1-1-7 6 2 2-9 6 5 5-7 4 7 7-3 1 7 7-1-2 7 6 3-4 10-20 2Z" fill="#8B7C61" stroke="#706449" strokeWidth=".7" strokeLinejoin="round" />
          <path d="M20 22Q14 16 9 22L1 28q8 8 23 2Z" fill="#D7C4A3" stroke="#A69070" strokeWidth=".6" />
          <circle cx="14" cy="24" r="1.1" fill="#2E2A25" /><circle cx="1.6" cy="28" r="1.6" fill="#62513E" />
          <path d="m24 15 2 4m5-7 2 5m6-3 1 4m6 1 2 3m-14 0 1 4m-10-2 1 3m16-2 2 3" fill="none" stroke="#B5A283" strokeWidth="1.1" strokeLinecap="round" />
          {!visit && <g className="collection-carried-apple" transform="translate(3 25)"><circle r="5.2" fill={event.color} /><ellipse cx="-1.5" cy="-1.5" rx="1" ry="1.5" fill="#F8F4E8" opacity=".5" /><path d="m0-4 1-3" stroke="#6C7955" strokeWidth="1" /></g>}
        </g>
      </g>
      <g className="collection-thanks" transform={`translate(69 ${celebration ? 185 : 219})`}><rect width={bubbleWidth} height="22" rx="11" fill="#F8F4E8" stroke="#6E9A82" strokeOpacity=".5" /><text x={bubbleWidth / 2} y="14.5" textAnchor="middle" fill="#4F7A66" fontFamily="Nunito, sans-serif" fontSize="10">{message}</text></g>
    </svg>
  </div>
}
