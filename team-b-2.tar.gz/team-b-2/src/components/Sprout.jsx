export default function Sprout({ planting }) {
  return <svg className={`relative h-[300px] w-[300px] ${planting ? 'growing' : ''}`} viewBox="0 0 300 300" role="img" aria-label="A tiny green sprout growing in a terracotta pot">
    <ellipse cx="150" cy="262" rx="71" ry="9" fill="#4F7A66" opacity=".12" />
    <g fill="none" stroke="#F8F4E8" strokeWidth="2" strokeLinecap="round"><path d="M66 103v10m-5-5h10M229 154v8m-4-4h8" /><circle cx="217" cy="77" r="3" /></g>
    <g className="sprout">
      <path d="M150 199c-4-27 0-51 2-77" fill="none" stroke="#3F8C8F" strokeWidth="6" strokeLinecap="round" />
      <path d="M150 153c-32 1-46-19-43-39 28-1 48 15 43 39ZM151 132c-2-28 16-45 41-43-1 25-16 45-41 43Z" fill="#3F8C8F" />
      <path d="m150 151-25-21m28 0 22-22" fill="none" stroke="#4F7A66" strokeOpacity=".25" strokeWidth="1.5" strokeLinecap="round" />
    </g>
    <ellipse cx="150" cy="199" rx="49" ry="10" fill="#B5763C" />
    <ellipse cx="150" cy="198" rx="39" ry="6" fill="#2E2A25" opacity=".65" />
    <ellipse className="seed" cx="164" cy="80" rx="4" ry="7" fill="#B5763C" />
    <path d="m105 202 10 48c2 12 68 12 70 0l10-48Z" fill="#B5763C" />
    <path d="m111 216 7 33c1 5 12 7 19 8" fill="none" stroke="#F8F4E8" strokeOpacity=".2" strokeWidth="4" strokeLinecap="round" />
    <path d="M100 197q50 15 100 0v13q-50 15-100 0Z" fill="#B5763C" />
    <path d="M101 210q49 14 98 0" fill="none" stroke="#2E2A25" strokeOpacity=".15" strokeWidth="2" />
  </svg>
}
