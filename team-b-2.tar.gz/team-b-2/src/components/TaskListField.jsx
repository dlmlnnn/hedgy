import { useEffect, useId, useRef, useState } from 'react'
import { createPortal } from 'react-dom'

export const taskFieldClass = 'mt-1 block min-h-11 w-full min-w-0 rounded-xl border border-[#6E9A82]/40 bg-(--control-surface) px-3 py-2 text-base outline-[#4F7A66]'

export default function TaskListField({ lists, value = '', onChange, onCreateList, hideLabel = false, onOverlayChange }) {
  const [creating, setCreating] = useState(false)
  const [placement, setPlacement] = useState(null)
  const open = Boolean(placement)
  const dropdown = useRef(null)
  const trigger = useRef(null)
  const optionsId = useId()
  const options = [...new Set([...lists, ...(!creating && value ? [value] : [])])]
  useEffect(() => {
    if (open) dropdown.current?.focus({ preventScroll: true })
  }, [open])
  function openDropdown() {
    const field = trigger.current.getBoundingClientRect()
    const stage = trigger.current.closest('.app-stage')
    const frame = stage.getBoundingClientRect()
    const viewport = window.visualViewport
    const visibleTop = Math.max(frame.top, viewport?.offsetTop ?? 0)
    const visibleBottom = viewport ? Math.min(frame.bottom, viewport.offsetTop + viewport.height) : frame.bottom
    const below = visibleBottom - field.bottom - 12
    const above = field.top - visibleTop - 12
    const menuHeight = Math.min(176, 10 + 44 * (options.length + 1))
    const placeBelow = below >= menuHeight || below >= above
    onOverlayChange?.(true)
    setPlacement({
      stage,
      placeBelow,
      fieldHeight: field.height,
      maxOptionsHeight: Math.max(44, Math.min(176, placeBelow ? below : above)),
      style: {
        left: field.left - frame.left,
        width: field.width,
        ...(placeBelow ? { top: field.top - frame.top } : { bottom: frame.bottom - field.bottom }),
      },
    })
  }
  function closeDropdown() {
    setPlacement(null)
    onOverlayChange?.(false)
    requestAnimationFrame(() => trigger.current?.focus({ preventScroll: true }))
  }
  function select(next) {
    setCreating(next === 'new')
    onChange(next === 'new' ? '' : next.slice(5))
    if (open) closeDropdown()
  }
  function handleMenuKeys(event) {
    if (event.key === 'Escape') {
      event.stopPropagation()
      event.preventDefault()
      closeDropdown()
    }
    if (event.key !== 'Tab') return
    const buttons = dropdown.current.querySelectorAll('button')
    const first = buttons[0]
    const last = buttons[buttons.length - 1]
    const focused = document.activeElement
    if (event.shiftKey && (focused === first || focused === dropdown.current)) {
      event.preventDefault()
      last.focus()
    } else if (!event.shiftKey && focused === last) {
      event.preventDefault()
      first.focus()
    }
  }
  return <div>
    {onCreateList ? <div>
      {!hideLabel && <span className="block text-sm font-semibold">Task folder</span>}
      <button ref={trigger} type="button" aria-label="Task folder" aria-describedby={`${optionsId}-value`} aria-haspopup="dialog" aria-expanded={open} aria-controls={open ? optionsId : undefined} onClick={openDropdown} className={`${taskFieldClass} flex items-center justify-between gap-2 text-left ${hideLabel ? 'mt-0! min-h-9! rounded-lg! bg-white/45! py-1! text-sm! text-[#626760]' : ''}`}>
        <span id={`${optionsId}-value`} className="truncate">{creating ? '+New folder' : value || "Today's Tasks"}</span>
        <span aria-hidden="true" className={`shrink-0 text-[#4F7A66] transition-transform motion-reduce:transition-none ${open ? 'rotate-180' : ''}`}>⌄</span>
      </button>
      {open && createPortal(
        <div onClick={event => { event.stopPropagation(); closeDropdown() }} className="absolute inset-0 z-[75] backdrop-blur-[3px]">
          <div id={optionsId} ref={dropdown} role="dialog" aria-modal="true" aria-label="Task folder options" tabIndex={-1} style={placement.style} onClick={event => event.stopPropagation()} onKeyDown={handleMenuKeys} className={`absolute flex overflow-hidden rounded-xl border border-[#6E9A82]/40 bg-(--control-surface) shadow-lg outline-none ${placement.placeBelow ? 'flex-col' : 'flex-col-reverse'}`}>
            <button type="button" aria-label="Close task folder options" onClick={closeDropdown} style={{ minHeight: placement.fieldHeight - 1 }} className="flex w-full shrink-0 items-center justify-between gap-2 px-3 py-2 text-left text-base focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">
              <span className="truncate">{creating ? '+New folder' : value || "Today's Tasks"}</span>
              <span aria-hidden="true" className="shrink-0 rotate-180 text-[#4F7A66]">⌄</span>
            </button>
            <div style={{ maxHeight: placement.maxOptionsHeight }} className={`task-scroll overflow-y-auto overscroll-contain border-[#6E9A82]/30 p-1 ${placement.placeBelow ? 'border-t' : 'border-b'}`}>
            {hideLabel && value && <button type="button" onClick={() => select('list:')} className="block min-h-11 w-full rounded-lg px-3 py-2 text-left text-sm text-[#2E2A25] hover:bg-(--control-hover) focus-visible:outline-2 focus-visible:outline-[#4F7A66]">Today's Tasks</button>}
            {options.map(name => <button key={name} type="button" aria-current={value === name ? 'true' : undefined} onClick={() => select(`list:${name}`)} className="block min-h-11 w-full break-words rounded-lg px-3 py-2 text-left text-sm text-[#2E2A25] hover:bg-(--control-hover) aria-[current=true]:bg-(--control-selected) focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">{name}</button>)}
            <button type="button" onClick={() => select('new')} className="block min-h-11 w-full rounded-lg px-3 py-2 text-left text-sm font-semibold text-[#3D6653] hover:bg-(--control-hover) focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">+New folder</button>
            </div>
          </div>
        </div>,
        placement.stage,
      )}
    </div> : <label className="block text-sm font-semibold">Task folder
      <select aria-label="Task folder" className={taskFieldClass} value={creating ? 'new' : `list:${value}`} onChange={event => select(event.target.value)}>
        <option value="list:">Today's Tasks</option>
        {options.map(name => <option key={name} value={`list:${name}`}>{name}</option>)}
        <option value="new">+New folder</option>
      </select>
    </label>}
    {creating && <div className="mt-2">
      <label className="block text-sm font-semibold">New folder name
        <input className={taskFieldClass} maxLength={40} pattern={String.raw`.*\S.*`} value={value} onChange={event => onChange(event.target.value)} placeholder="e.g. School" required />
      </label>
      {onCreateList && <button type="button" disabled={!value.trim()} onClick={() => {
        onChange(onCreateList(value))
        setCreating(false)
      }} className="mt-2 min-h-11 rounded-xl border border-[#4F7A66] px-4 text-sm font-semibold">Add folder</button>}
    </div>}
  </div>
}
