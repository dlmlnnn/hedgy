import test from 'node:test'
import assert from 'node:assert/strict'
import { selectMonthDays, selectWeekdaysInMonth, selectIntervalRange, selectRecurringMonths } from './calendarSelection.js'

test('month recurrence preserves dates outside its year and skips months without the anchor day', () => {
  const result = selectRecurringMonths(new Set(['2026-01-10', '2026-02-10', '2027-02-02']), '2026-01-31', [1, 2, 3], [31])
  assert.deepEqual([...result].sort(), ['2026-01-10', '2026-01-31', '2026-03-31', '2027-02-02'])
})

test('selected day numbers repeat only in the selected months', () => {
  const result = selectRecurringMonths(new Set(['2026-12-25']), '2026-11-20', [11, 1], [20, 25, 31])
  assert.deepEqual([...result].sort(), ['2026-11-20', '2026-11-25', '2027-01-20', '2027-01-25', '2027-01-31'])
})

test('interval selection fills a year across month and year boundaries with one rhythm', () => {
  const result = selectIntervalRange(new Set(), 2026, 9, '2026-10-29', 3, '2026-10-29')
  assert.ok(result.has('2026-10-29'))
  assert.ok(result.has('2026-11-01'))
  assert.ok(result.has('2027-01-03'))
  assert.ok(result.has('2027-10-27'))
  assert.ok(!result.has('2027-10-30'))
  const sorted = [...result].sort()
  for (let i = 1; i < sorted.length; i++) assert.equal((Date.parse(sorted[i]) - Date.parse(sorted[i - 1])) / 86400000, 3)
})

test('interval range respects future starts, past dates, existing rhythm and unrelated dates', () => {
  const result = selectIntervalRange(new Set(['2026-10-28', '2028-01-01']), 2026, 10, '2026-10-29', 3, null)
  assert.ok(result.has('2026-11-03'))
  assert.ok(!result.has('2026-11-01'))
  assert.ok(result.has('2028-01-01'))
  const future = selectIntervalRange(new Set(), 2026, 9, '2026-10-29', 3, '2026-12-31')
  assert.ok(future.has('2026-12-31'))
  assert.ok(future.has('2027-01-03'))
  assert.ok([...future].every(date => date >= '2026-12-31'))
  const past = selectIntervalRange(new Set(), 2026, 9, '2026-10-29', 3, '2026-10-20')
  assert.ok(past.has('2026-10-29'))
  assert.ok([...past].every(date => date >= '2026-10-29'))
  assert.deepEqual([...selectIntervalRange(new Set(['2026-11-01']), 2026, 10, '2026-10-29', 1, null)], ['2026-11-01'])
})

test('weekday selection stays in the chosen month and preserves explicitly selected dates outside it', () => {
  const result = selectWeekdaysInMonth(new Set(['2026-10-30', '2026-12-10']), 2026, 10, '2026-10-29', [1, 3], '2026-11-10')
  assert.deepEqual([...result].sort(), [
    '2026-10-30', '2026-11-11', '2026-11-16', '2026-11-18',
    '2026-11-23', '2026-11-25', '2026-11-30', '2026-12-10',
  ])
})

test('reapplying weekdays replaces the range, excludes past days and allows manual exceptions', () => {
  const mondays = selectWeekdaysInMonth(new Set(), 2026, 9, '2026-10-29', [1], '2026-10-01')
  const fridays = selectWeekdaysInMonth(mondays, 2026, 9, '2026-10-29', [5], '2026-10-01')
  assert.ok(fridays.has('2026-10-30'))
  assert.ok(!fridays.has('2026-11-02'))
  assert.ok([...fridays].every(date => date >= '2026-10-29'))
  fridays.delete('2026-10-30')
  assert.ok(!fridays.has('2026-10-30'))
})

test('every X days uses the picked anchor instead of an older selection and continues across months', () => {
  const today = '2026-10-29'
  const november = selectMonthDays(new Set(['2026-11-05', '2026-11-11', '2027-01-01']), 2026, 10, today, { interval: 3, anchorDate: '2026-11-11' })
  assert.deepEqual([...november].filter(date => date.startsWith('2026-11')), ['2026-11-11', '2026-11-14', '2026-11-17', '2026-11-20', '2026-11-23', '2026-11-26', '2026-11-29'])
  const december = selectMonthDays(november, 2026, 11, today, { interval: 3, anchorDate: '2026-11-11' })
  assert.ok(december.has('2026-12-02'))
  assert.ok(december.has('2026-12-05'))
  assert.ok(december.has('2026-11-11'))
  assert.ok(december.has('2027-01-01'))
})

test('weekdays fills matching weekdays from the picked day, retaining other months', () => {
  const result = selectMonthDays(new Set(['2026-11-02', '2026-11-10', '2026-12-10']), 2026, 10, '2026-10-29', { weekdays: [1, 3], anchorDate: '2026-11-10' })
  assert.deepEqual([...result].filter(date => date.startsWith('2026-11')), ['2026-11-11', '2026-11-16', '2026-11-18', '2026-11-23', '2026-11-25', '2026-11-30'])
  assert.ok(result.has('2026-12-10'))
})

test('helpers exclude past dates and preserve a rhythm across the year boundary', () => {
  const result = selectMonthDays(new Set(), 2026, 9, '2026-10-29', { interval: 3, anchorDate: '2026-10-20' })
  assert.deepEqual([...result], ['2026-10-29'])
  const weekdays = selectMonthDays(new Set(), 2026, 9, '2026-10-29', { weekdays: [1, 3, 5], anchorDate: '2026-10-20' })
  assert.deepEqual([...weekdays], ['2026-10-30'])
  const january = selectMonthDays(new Set(['2026-12-31']), 2027, 0, '2026-10-29', { interval: 3, anchorDate: '2026-12-31' })
  assert.ok(january.has('2027-01-03'))
  assert.ok(january.has('2027-01-06'))
})
