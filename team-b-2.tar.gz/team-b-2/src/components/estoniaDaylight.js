import { getTimes } from 'suncalc'

const palettes = {
  night: ['#656D86', '#A3A1AA', '#476648', '#727968'],
  morning: ['#DBCDD0', '#EAD8BD', '#527352', '#87907B'],
  day: ['#C5D7D5', '#F3EEDF', '#476648', '#87907B'],
  evening: ['#C7ADBA', '#E5C8A6', '#476648', '#7D8472'],
}

function mix(first, second, amount) {
  return '#' + [1, 3, 5].map(offset => Math.round(parseInt(first.slice(offset, offset + 2), 16) * (1 - amount) + parseInt(second.slice(offset, offset + 2), 16) * amount).toString(16).padStart(2, '0')).join('')
}

export function estoniaDaylight(now = new Date(), theme = 'regular') {
  if (theme === 'dark') {
    const [sky, horizon, ground, lower] = palettes.night
    return { phase: 'night', sky: mix(sky, '#000000', .1), horizon: mix(horizon, '#000000', .1), ground, lower }
  }
  if (theme === 'neutral') {
    const [sky, horizon, ground, lower] = palettes.morning
    return { phase: 'morning', sky, horizon, ground, lower }
  }
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Tallinn', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now).map(part => [part.type, part.value]))
  const anchor = new Date(`${parts.year}-${parts.month}-${parts.day}T12:00:00Z`)
  const times = getTimes(anchor, 59.437, 24.7536)
  const dawn = Number(times.dawn)
  const dusk = Number(times.dusk)
  const morningEnd = Number(times.goldenHourEnd || times.solarNoon)
  const eveningStart = Number(times.goldenHour || times.solarNoon)
  const time = Number(now)
  const phase = time < dawn || time >= dusk ? 'night' : time < morningEnd ? 'morning' : time < eveningStart ? 'day' : 'evening'
  const milestones = [
    [dawn - 45 * 60000, 'night'], [dawn + 15 * 60000, 'morning'],
    [morningEnd, 'day'], [eveningStart, 'day'],
    [Number(times.sunset), 'evening'], [dusk + 30 * 60000, 'night'],
  ].sort((a, b) => a[0] - b[0])
  let colors = palettes.night
  for (let i = 0; i < milestones.length - 1; i++) {
    const [start, from] = milestones[i], [end, to] = milestones[i + 1]
    if (time >= start && time <= end) {
      const amount = Math.max(0, Math.min(1, (time - start) / Math.max(1, end - start)))
      colors = palettes[from].map((color, index) => mix(color, palettes[to][index], amount))
      break
    }
  }
  return { phase, sky: colors[0], horizon: colors[1], ground: colors[2], lower: colors[3] }
}
