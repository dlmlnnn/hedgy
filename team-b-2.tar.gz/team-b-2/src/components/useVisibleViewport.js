import { useEffect, useState } from 'react'

export default function useVisibleViewport(frameRef) {
  const [viewport, setViewport] = useState(null)
  useEffect(() => {
    function resize() {
      const frame = frameRef.current?.closest('.app-stage')?.getBoundingClientRect() || frameRef.current?.parentElement?.getBoundingClientRect()
      const visual = window.visualViewport
      if (!frame || !visual) return
      const top = Math.max(0, visual.offsetTop - frame.top)
      const height = Math.max(0, Math.min(frame.height - top, visual.height - Math.max(0, frame.top - visual.offsetTop)))
      setViewport(height < frame.height - 16 ? { top, height } : null)
    }
    resize()
    window.visualViewport?.addEventListener('resize', resize)
    window.visualViewport?.addEventListener('scroll', resize)
    window.addEventListener('resize', resize)
    return () => { window.visualViewport?.removeEventListener('resize', resize); window.visualViewport?.removeEventListener('scroll', resize); window.removeEventListener('resize', resize) }
  }, [frameRef])
  return viewport
}
