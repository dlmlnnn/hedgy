import { useId, useLayoutEffect, useRef, useState } from 'react'

const timeValues = length => Array.from({ length }, (_, index) => String(index).padStart(2, '0'))
const hours = timeValues(24)
const minutes = timeValues(60)

export default function TimeAccordion({ value = '', expanded, onToggle, onChange }) {
  const panelId = useId()
  const [pickedHour, setPickedHour] = useState(null)
  const trigger = useRef(null)
  const numbers = useRef(null)
  const choosingHour = pickedHour === null
  const [hour = '', minute = ''] = value.split(':')
  const selected = choosingHour ? hour : minute
  const label = choosingHour ? 'Hour' : 'Minute'
  useLayoutEffect(() => {
    if (!expanded || !numbers.current) return
    const list = numbers.current
    const choice = list.querySelector('[aria-current="true"]')
    list.scrollTop = choice ? Math.max(0, choice.offsetTop - list.offsetTop - 28) : 0
    if (!choosingHour) (choice || list.querySelector('button'))?.focus({ preventScroll: true })
  }, [expanded, choosingHour, selected])

  function finish(time) {
    onChange(time)
    onToggle()
    trigger.current?.focus({ preventScroll: true })
  }
  return <div className="min-w-0 self-start rounded-lg border border-[#6E9A82]/40 bg-white/40 text-[#354D40]">
    <button ref={trigger} type="button" aria-label={value ? `Time, ${value}` : 'Set time'} aria-expanded={expanded} aria-controls={panelId} onClick={() => {
      if (!expanded) setPickedHour(null)
      onToggle()
    }}
      className="flex min-h-8 w-full items-center justify-center gap-1 whitespace-nowrap rounded-lg px-2 text-xs font-semibold hover:bg-white/40 focus-visible:outline-2 focus-visible:outline-[#4F7A66]">
      <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" className="size-4 shrink-0">
        <circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />
      </svg>
      {value || '--:--'}
    </button>
    <div id={panelId} inert={!expanded} aria-hidden={!expanded}
      className={`grid transition-[grid-template-rows,opacity] duration-250 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none ${expanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
      <div className="min-h-0 overflow-hidden">
        <div className="border-t border-[#6E9A82]/30 px-1 pb-1">
          <p className="py-1 text-center text-[11px] font-semibold">{label}</p>
          <div key={label} ref={numbers} role="group" aria-label={`Choose ${label.toLowerCase()}`} className="task-scroll relative grid max-h-32 gap-0.5 overflow-y-auto overscroll-contain">
            {(choosingHour ? hours : minutes).map(option => <button key={option} type="button" aria-label={`${label} ${option}`}
              aria-current={option === selected ? 'true' : undefined} onClick={() => choosingHour ? setPickedHour(option) : finish(`${pickedHour}:${option}`)}
              className="min-h-8 rounded-md text-sm tabular-nums hover:bg-[#E8EFE5] aria-[current=true]:bg-[#DCE7DC] focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">{option}</button>)}
          </div>
          {choosingHour && value && <button type="button" onClick={() => finish('')} className="mt-1 min-h-7 w-full rounded-md text-[10px] hover:bg-[#E8EFE5]">Clear time</button>}
        </div>
      </div>
    </div>
  </div>
}
