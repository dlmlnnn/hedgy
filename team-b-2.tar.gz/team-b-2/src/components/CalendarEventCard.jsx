import { useEffect, useRef, useState } from 'react'
import { calendarEvent } from './calendarEvent'

export default function CalendarEventCard({ task, onClose }) {
  const [duration, setDuration] = useState(60)
  const [closing, setClosing] = useState(false)
  const [message, setMessage] = useState('')
  const [fallback, setFallback] = useState(false)
  const dialog = useRef(null)
  const timer = useRef(null)
  const event = calendarEvent(task, duration)
  useEffect(() => { dialog.current?.focus({ preventScroll: true }); return () => clearTimeout(timer.current) }, [])
  function close() {
    if (closing) return
    setClosing(true)
    timer.current = setTimeout(onClose, 200)
  }
  function keys(key) {
    if (key.key === 'Escape') { key.preventDefault(); close() }
    if (key.key !== 'Tab') return
    const controls = [...dialog.current.querySelectorAll('button, a, select, input')]
    if (key.shiftKey && (document.activeElement === controls[0] || document.activeElement === dialog.current)) { key.preventDefault(); controls.at(-1)?.focus() }
    else if (!key.shiftKey && document.activeElement === controls.at(-1)) { key.preventDefault(); controls[0]?.focus() }
  }
  async function share() {
    setMessage(''); setFallback(false)
    const file = new File([event.ics], event.filename, { type: 'text/calendar' })
    try {
      if (navigator.canShare?.({ files: [file] }) && navigator.share) await navigator.share({ files: [file], title: task.title })
      else { download(); setMessage('Calendar event (.ics) downloaded for sharing.') }
    } catch (error) {
      if (error.name !== 'AbortError') { setFallback(true); setMessage('Copy this event link to share, or download the .ics file.') }
    }
  }
  function download() {
    const url = URL.createObjectURL(new Blob([event.ics], { type: 'text/calendar;charset=utf-8' }))
    const link = document.createElement('a')
    link.href = url; link.download = event.filename
    document.body.appendChild(link); link.click(); link.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
    setMessage('Calendar file downloaded.')
  }
  return <div ref={dialog} role="dialog" aria-modal="true" aria-labelledby="calendar-event-title" tabIndex={-1} onKeyDown={keys} onClick={close} className={`task-detail-layer add-menu-backdrop absolute inset-0 z-40 flex items-center justify-center outline-none ${closing ? 'is-closing' : ''}`}>
    <div aria-hidden="true" className="detail-blur pointer-events-none absolute inset-0 bg-[#2E2A25]/15 backdrop-blur-[3px]" />
    <div onClick={click => click.stopPropagation()} className="add-menu-window task-scroll relative max-h-[min(480px,90%)] w-[78.88%] overflow-y-auto overscroll-contain rounded-[28px] bg-[#F8F4E8] p-5 text-[#2E2A25] shadow-[0_8px_24px_rgba(70,50,30,0.18)]">
      <div className="flex items-center justify-between gap-3"><h2 id="calendar-event-title" className="text-[22px] font-semibold">Calendar event</h2><button type="button" onClick={close} aria-label="Back to task details" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#4F7A66] focus-visible:outline-2 focus-visible:outline-[#4F7A66]"><svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="m6 6 12 12M18 6 6 18" /></svg></button></div>
      <p className="mt-2 break-words text-[16px] font-semibold">{task.title}</p>
      <dl className="mt-3 space-y-2 text-[12px] text-[#59554D]">
        <div className="flex items-center justify-between gap-3"><dt>Date</dt><dd>{new Date(`${task.date}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</dd></div>
        <div className="flex items-center justify-between gap-3"><dt>Time</dt><dd>{task.time ? `${task.time} · Estonia` : 'All day'}</dd></div>
        <div className="flex items-center justify-between gap-3"><dt><label htmlFor="event-duration">Duration</label></dt><dd>{task.time ? <select id="event-duration" value={duration} onChange={change => setDuration(Number(change.target.value))} className="min-h-11 rounded-xl border border-[#6E9A82]/40 px-2 text-[12px] outline-[#4F7A66]">{[[15,'15 minutes'],[30,'30 minutes'],[45,'45 minutes'],[60,'1 hour'],[90,'1½ hours'],[120,'2 hours'],[180,'3 hours']].map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select> : '1 day'}</dd></div>
      </dl>
      <div className="mt-5 flex flex-col gap-2">
        <a href={event.url} target="_blank" rel="noopener noreferrer" className="flex min-h-11 items-center justify-center rounded-full bg-[#4F7A66] px-3 text-[13px] font-semibold text-[#F3EEDF] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4F7A66]">Add to Google Calendar</a>
        <button type="button" onClick={share} className="min-h-11 rounded-full border border-[#4F7A66] px-3 text-[13px] font-semibold text-[#4F7A66]">Share calendar event</button>
        <button type="button" onClick={download} className="min-h-11 rounded-full border border-[#4F7A66] px-3 text-[13px] font-semibold text-[#4F7A66]">Download event (.ics)</button>
      </div>
      <p className="mt-4 text-[11px] leading-relaxed text-[#59554D]">Review and save the event in Google Calendar, or open the .ics file in your calendar app.</p>
      {message && <p role="status" className="mt-3 text-[11px] leading-relaxed text-[#59554D]">{message}</p>}
      {fallback && <input aria-label="Shareable calendar event link" readOnly value={event.url} onFocus={focus => focus.target.select()} className="mt-2 min-h-11 w-full rounded-xl border border-[#6E9A82]/40 px-3 text-[12px]" />}
    </div>
  </div>
}
