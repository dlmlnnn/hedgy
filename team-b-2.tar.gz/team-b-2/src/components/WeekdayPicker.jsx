import { useEffect, useRef, useState } from 'react'

export const weekdayNames = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']

export default function WeekdayPicker({ initialDays, onDone, onClose, confirmLabel = 'Done', label = 'Choose goal weekdays', requireSelection = false }) {
  const [days, setDays] = useState(() => new Set(initialDays))
  const [closing, setClosing] = useState(false)
  const dialog = useRef(null)
  const timer = useRef(null)
  useEffect(() => {
    dialog.current?.focus({ preventScroll: true })
    return () => clearTimeout(timer.current)
  }, [])
  function close() {
    if (closing) return
    setClosing(true)
    timer.current = setTimeout(onClose, 200)
  }
  function keys(event) {
    if (event.key === 'Escape') { event.preventDefault(); close() }
    if (event.key !== 'Tab') return
    const buttons = Array.from(dialog.current.querySelectorAll('button'))
    if (event.shiftKey && (document.activeElement === buttons[0] || document.activeElement === dialog.current)) { event.preventDefault(); buttons.at(-1).focus() }
    else if (!event.shiftKey && document.activeElement === buttons.at(-1)) { event.preventDefault(); buttons[0].focus() }
  }
  return <div ref={dialog} role="dialog" aria-modal="true" aria-label={label} tabIndex={-1} onKeyDown={keys} onClick={close} className={`add-menu-backdrop absolute inset-0 z-40 bg-[#2E2A25]/20 backdrop-blur-[3px] outline-none ${closing ? 'is-closing' : ''}`}>
    <div className="add-menu-window pointer-events-none absolute inset-0">
      <div onClick={event => event.stopPropagation()} className="pointer-events-auto absolute left-1/2 top-[14.789%] flex h-[100px] w-[76.336%] -translate-x-1/2 items-center gap-1 rounded-[28px] bg-[#F8F4E8] px-3 shadow-[0_8px_24px_rgba(70,50,30,0.18)]">
        {weekdayNames.map((name, index) => <button key={name} type="button" aria-pressed={days.has(index + 1)} onClick={() => setDays(previous => { const next = new Set(previous); if (next.has(index + 1)) next.delete(index + 1); else next.add(index + 1); return next })} className={`h-14 min-w-0 flex-1 rounded-full text-[11px] font-semibold text-[#2E2A25] transition active:bg-[#E9C46A] focus-visible:outline-2 focus-visible:outline-[#4F7A66] ${days.has(index + 1) ? 'bg-[#E9C46A]' : ''}`}>{name}</button>)}
      </div>
      <button type="button" disabled={closing || (requireSelection && !days.size)} onClick={event => { event.stopPropagation(); onDone([...days].sort((a, b) => a - b)) }} className="pointer-events-auto absolute left-1/2 top-[29.343%] h-14 w-[76.336%] -translate-x-1/2 rounded-full bg-[#4F7A66] text-[15px] font-semibold text-[#F8F4E8] transition active:scale-[0.98] disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#F8F4E8]">{confirmLabel}</button>
    </div>
  </div>
}
