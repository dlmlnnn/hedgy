import { useEffect, useRef, useState } from 'react'
import Calendar from './Calendar'
import WeekdayPicker, { weekdayNames } from './WeekdayPicker'
import { dateKey } from './calendarDates'
import TaskApple from './TaskApple'
import { belongsToPlan, listPlans, restoreDeleted, updatePlanDates } from './planManagement'

const shortDate = date => new Date(`${date}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
const countDates = count => `${count} ${count === 1 ? 'date' : 'dates'}`

function summary(plan) {
  if (plan.type === 'goal') return `Deadline ${shortDate(plan.deadline)} · ${plan.stepDates.filter(date => !(plan.excludedDates || []).includes(date)).length} work dates`
  if (plan.type === 'commitment') return `${countDates(plan.dates.length)} · until ${shortDate(plan.dates.at(-1))}`
  if (plan.rule === 'daily') return 'every day'
  if (plan.rule === 'weekdays') return (plan.weekdays || []).map(day => weekdayNames[day - 1]).join(', ')
  return countDates(plan.dates.length)
}

function Icon({ trash = false }) {
  return <svg aria-hidden="true" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">{trash ? <path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v5m4-5v5" /> : <path d="m15 4 5 5M4 20l5-1L21 7l-4-4L5 15l-1 5Z" />}</svg>
}

function GoalDatesMenu({ onChoose, onClose }) {
  const [closing, setClosing] = useState(false)
  const dialog = useRef(null)
  const timer = useRef(null)
  useEffect(() => { dialog.current?.focus({ preventScroll: true }); return () => clearTimeout(timer.current) }, [])
  function close(action = onClose) {
    if (closing) return
    setClosing(true)
    timer.current = setTimeout(action, 200)
  }
  function keys(event) {
    if (event.key === 'Escape') { event.preventDefault(); close() }
    if (event.key !== 'Tab') return
    const buttons = dialog.current.querySelectorAll('button')
    if (event.shiftKey && (document.activeElement === buttons[0] || document.activeElement === dialog.current)) { event.preventDefault(); buttons[1].focus() }
    else if (!event.shiftKey && document.activeElement === buttons[1]) { event.preventDefault(); buttons[0].focus() }
  }
  return <div ref={dialog} role="dialog" aria-modal="true" aria-label="Edit goal dates" tabIndex={-1} onKeyDown={keys} onClick={() => close()} className={`add-menu-backdrop absolute inset-0 z-40 flex items-center justify-center bg-[#2E2A25]/20 backdrop-blur-[3px] outline-none ${closing ? 'is-closing' : ''}`}>
    <div onClick={event => event.stopPropagation()} className="add-menu-window w-[78.88%] overflow-hidden rounded-[28px] bg-[#F8F4E8] shadow-[0_8px_24px_rgba(70,50,30,0.18)]">
      {[['Change deadline', 'deadline'], ['Change work dates', 'dates']].map(([title, mode]) => <button key={mode} type="button" onClick={() => close(() => onChoose(mode))} className="block min-h-[88px] w-full border-b border-[#6E9A82]/40 px-6 text-left text-[16px] font-semibold text-[#2E2A25] last:border-0 active:bg-[#F3EEDF] focus-visible:outline-2 focus-visible:-outline-offset-4 focus-visible:outline-[#4F7A66]">{title}</button>)}
    </div>
  </div>
}

export function usePlanManager(tasks, onChange) {
  const [editor, setEditor] = useState(null)
  const [notice, setNotice] = useState(null)
  const trigger = useRef(null)
  const today = dateKey(new Date())
  useEffect(() => {
    if (!notice) return
    const timer = setTimeout(() => setNotice(null), notice.removed ? 6000 : 2000)
    return () => clearTimeout(timer)
  }, [notice])
  function closeEditor() {
    setEditor(null)
    requestAnimationFrame(() => trigger.current?.focus({ preventScroll: true }))
  }
  function saved(update) {
    onChange(update)
    setNotice({ text: 'Saved' })
    closeEditor()
  }
  function remove(plan) {
    const removed = tasks.map((item, index) => ({ item, index })).filter(({ item }) => belongsToPlan(item, plan))
    onChange(items => items.filter(item => !belongsToPlan(item, plan)))
    setNotice({ text: 'Deleted', removed })
  }
  function edit(plan, event) {
    trigger.current = event.currentTarget
    setEditor({ plan, mode: plan.type === 'goal' ? 'goal' : plan.type === 'habit' && (plan.rule === 'daily' || plan.rule === 'weekdays') ? 'weekdays' : plan.type === 'commitment' || plan.type === 'habit' ? 'dates' : 'date' })
  }

  return { edit, remove, active: Boolean(editor), overlays: <>
    {editor?.mode === 'date' && <Calendar mode="pick" tasks={tasks} initialDate={editor.plan.date} confirmLabel="Save date" onClose={closeEditor} onPick={date => saved(items => items.map(item => item.id === editor.plan.id ? { ...item, date, rolledOver: false } : item))} />}
    {editor?.mode === 'goal' && <GoalDatesMenu onClose={closeEditor} onChoose={mode => setEditor(previous => ({ ...previous, mode }))} />}
    {editor?.mode === 'dates' && <Calendar selectionType={editor.plan.type === 'goal' ? 'goal' : editor.plan.type === 'habit' ? 'habit' : 'commitment'} mode="multi" tasks={tasks} initialDates={editor.plan.type === 'goal' ? editor.plan.stepDates.filter(date => !(editor.plan.excludedDates || []).includes(date)) : editor.plan.dates} multiLabel={`Edit dates for ${editor.plan.title}`} confirmLabel="Save dates" onClose={closeEditor} onPick={dates => saved(items => updatePlanDates(items, editor.plan, dates, today))} />}
    {editor?.mode === 'deadline' && <Calendar mode="pick" tasks={tasks} initialDate={editor.plan.deadline} confirmLabel="Save deadline" onClose={closeEditor} onPick={deadline => saved(items => items.map(item => item.id === editor.plan.id ? { ...item, deadline, stepDates: item.stepDates.filter(date => date <= deadline) } : item))} />}
    {editor?.mode === 'weekdays' && <WeekdayPicker initialDays={editor.plan.rule === 'daily' ? [1, 2, 3, 4, 5, 6, 7] : editor.plan.weekdays || []} label={`Repeat weekdays for ${editor.plan.title}`} confirmLabel="Save" requireSelection onClose={closeEditor} onDone={weekdays => saved(items => items.map(item => item.id === editor.plan.id ? { ...item, rule: weekdays.length === 7 ? 'daily' : 'weekdays', weekdays } : item))} />}
    {notice && <div role="status" className="absolute bottom-7 left-1/2 z-50 flex min-h-12 -translate-x-1/2 items-center gap-5 whitespace-nowrap rounded-full bg-[#4F7A66] px-5 text-[13px] font-semibold text-[#F8F4E8] shadow-[0_8px_24px_rgba(70,50,30,0.18)] task-arrival">{notice.text}{notice.removed && <button type="button" onClick={() => { onChange(items => restoreDeleted(items, notice.removed)); setNotice(null) }} className="min-h-11 underline underline-offset-4 focus-visible:outline-2 focus-visible:outline-[#F8F4E8]">Undo</button>}</div>}
  </> }
}

export function PlanPage({ name, title = name, tasks, onEdit, onDelete, onDetails }) {
  const plans = listPlans(tasks, name)
  return <div className="flex h-full flex-col px-4">
    <h2 className="sr-only">{title} · {plans.length}</h2>
    <ul className="task-scroll min-h-0 flex-1 overflow-y-auto overscroll-y-contain pb-5">
      {!plans.length && <li className="flex h-full items-center justify-center text-[14px] text-[#59554D]">Nothing here yet.</li>}
      {plans.map(plan => <li key={plan.id} className="flex min-h-[88px] items-center gap-2 border-b border-[#6E9A82]/40 py-3 last:border-0">
        <button type="button" onClick={event => onDetails(plan, event)} aria-label={`View details for ${plan.title}`} aria-haspopup="dialog" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full active:bg-[#F3EEDF] focus-visible:outline-2 focus-visible:outline-[#4F7A66]"><TaskApple task={plan} /></button>
        <div className="min-w-0 flex-1"><p title={plan.title} className="truncate text-[14px] font-semibold">{plan.title}</p><p title={summary(plan)} className="mt-1 truncate text-[11px] leading-relaxed text-[#59554D]">{summary(plan)}</p></div>
        <button type="button" aria-label={`Edit dates for ${plan.title}`} onClick={event => onEdit(plan, event)} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#4F7A66] active:bg-[#F3EEDF] focus-visible:outline-2 focus-visible:outline-[#4F7A66]"><Icon /></button>
        <button type="button" aria-label={`Delete all dates for ${plan.title}`} onClick={() => onDelete(plan)} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#59554D] active:bg-[#F3EEDF] focus-visible:outline-2 focus-visible:outline-[#4F7A66]"><Icon trash /></button>
      </li>)}
    </ul>
  </div>
}
