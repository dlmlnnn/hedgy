import { useEffect, useRef } from 'react'
import { isRecurringTask } from './taskModel.js'

export default function DeleteTaskDialog({ task, onClose, onDelete, allowOccurrence = true }) {
  const dialog = useRef(null)
  useEffect(() => { dialog.current?.focus({ preventScroll: true }) }, [])
  return <div ref={dialog} tabIndex={-1} role="dialog" aria-modal="true" aria-label="Confirm deletion" onClick={onClose} onKeyDown={event => {
    if (event.key === 'Escape') { event.stopPropagation(); onClose() }
  }} className="absolute inset-0 z-[60] flex items-center justify-center bg-[#2E2A25]/20 backdrop-blur-[3px] outline-none">
    <div onClick={event => event.stopPropagation()} className="w-[79%] rounded-[28px] bg-[#F8F4E8] p-5 shadow-xl">
      <h2 className="text-xl font-semibold">Delete {task.title}?</h2><p className="my-3 text-sm text-[#59554D]">{isRecurringTask(task) ? (allowOccurrence ? 'Remove this occurrence or the whole sequence and its completion history.' : 'Remove the whole sequence and its completion history.') : 'This permanently removes this task.'}</p>
      <div className="flex flex-col gap-2">{isRecurringTask(task) && allowOccurrence && <button type="button" onClick={() => onDelete(false)} className="min-h-11 rounded-full border border-[#4F7A66]">Only this task</button>}<button type="button" onClick={() => onDelete(true)} className="min-h-11 rounded-full bg-[#4F7A66] text-white">{isRecurringTask(task) ? 'Whole sequence' : 'Delete task'}</button><button type="button" onClick={onClose} className="min-h-11 rounded-full border border-[#4F7A66]">Cancel</button></div>
    </div>
  </div>
}
