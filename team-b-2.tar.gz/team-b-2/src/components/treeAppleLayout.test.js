import test from 'node:test'
import assert from 'node:assert/strict'
import { anchorOrder, anchorPosition, appleItemKey, appleLandingLane, reconcileAppleAssignments, treeItemsForToday } from './treeAppleLayout.js'
import { unfinishedItems } from './taskSchedule.js'

test('anchors follow the specified priority, cap at fourteen and stay assigned on reorder', () => {
  const items = Array.from({ length: 16 }, (_, i) => ({ id: 'task-' + i, date: '2026-10-30' }))
  const assigned = reconcileAppleAssignments({}, items)
  assert.deepEqual(Object.values(assigned), anchorOrder)
  assert.equal(Object.keys(assigned).length, 14)
  assert.deepEqual(reconcileAppleAssignments(JSON.parse(JSON.stringify(assigned)), [...items].reverse()), assigned)
  const remaining = items.slice(1)
  const reserved = reconcileAppleAssignments(assigned, remaining, [assigned['task-0']])
  assert.equal(Object.keys(reserved).length, 13)
  const released = reconcileAppleAssignments(reserved, remaining)
  assert.equal(released['task-14'], assigned['task-0'])
  for (let i = 1; i < 14; i++) assert.equal(released['task-' + i], assigned['task-' + i])
  assert.deepEqual(anchorPosition(4), [56, 24.64])
})

test('tree uses today and overdue planner items, including recurring items and active goal steps', () => {
  const items = [
    { id: 'past', date: '2026-10-29' },
    { id: 'future', date: '2026-10-31' },
    { id: 'habit', type: 'habit', rule: 'schedule', startDate: '2026-10-30', weekdays: [5,6], months: [10] },
    { id: 'commit', type: 'commitment', rule: 'schedule', startDate: '2026-10-30', weekdays: [5,6], months: [10] },
    { id: 'goal', type: 'goal', startDate: '2026-10-30', deadline: '2026-11-10', steps: [{ id: 'step', startDate: '2026-10-30', endDate: '2026-11-01' }, { id: 'later', startDate: '2026-11-01', endDate: '2026-11-02' }] },
  ]
  const apples = treeItemsForToday(unfinishedItems(items, '2026-10-30'), '2026-10-30')
  assert.deepEqual(apples.map(item => item.id).sort(), ['past','habit','commit','goal'].sort())
  assert.equal(appleItemKey(apples.find(item => item.id === 'habit')), 'habit@2026-10-30')
  const tomorrow = treeItemsForToday(unfinishedItems(items, '2026-10-31'), '2026-10-31')
  assert.ok(tomorrow.some(item => appleItemKey(item) === 'habit@2026-10-31'))
  assert.equal(new Set(apples.map(appleItemKey)).size, apples.length)
})

test('simultaneous landings have separate spots even for nearby anchors', () => {
  const active = []
  for (const x of [100, 101, 100, 110, 115]) {
    const lane = appleLandingLane(x, active)
    const event = { startX: x, landY: 238 - lane * 12 }
    for (const prior of active) assert.ok(Math.hypot(event.startX - prior.startX, event.landY - prior.landY) >= 12)
    active.push(event)
  }
})

test('a daily goal check retains one apple, while whole-goal completion removes it', () => {
  const goal = { id: 'g', type: 'goal', title: 'Goal', startDate: '2026-11-01', deadline: '2026-11-03', completedDates: ['2026-11-01'], steps: [] }
  assert.equal(treeItemsForToday([], '2026-11-01', [goal]).length, 1)
  assert.equal(treeItemsForToday([], '2026-11-02', [{ ...goal, completed: true }]).length, 0)
  assert.equal(treeItemsForToday([], '2026-11-03', [{ ...goal, completed: true }]).length, 0)
  assert.equal(treeItemsForToday([], '2026-11-04', [goal]).length, 1)
  assert.equal(treeItemsForToday([], '2026-11-04', [{ ...goal, completed: true }]).length, 0)
})
