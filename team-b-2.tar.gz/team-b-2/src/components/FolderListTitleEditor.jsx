import { useState } from 'react'

export default function FolderListTitleEditor({ list, onClose, onRename, onDelete }) {
  const [title, setTitle] = useState(list.title)
  const [error, setError] = useState('')
  const [confirming, setConfirming] = useState(false)
  return <form aria-label="Edit list title" onSubmit={event => { event.preventDefault(); if (!confirming) setError(onRename(title.trim())) }}
    onKeyDown={event => {
      if (event.key === 'Escape') { event.stopPropagation(); if (confirming) setConfirming(false); else onClose() }
    }} className="min-w-0 flex-1 pt-1 pb-1">
    <input autoFocus aria-label="List title" value={title} onChange={event => { setTitle(event.target.value); setError('') }} maxLength={40} required
      className="planner-page-heading h-9 w-full rounded-lg border border-[#839384]/55 bg-white! px-1.5 text-base outline-[#4F7A66] sm:text-sm" />
    <div className="folder-title-actions mt-1 grid gap-1">
      {confirming && <p className="text-xs text-[#59554D]">Delete this list? Its tasks will stay in All.</p>}
      {error && <p role="alert" className="text-xs text-[#783E38]">{error}</p>}
      <div className="flex flex-wrap gap-1.5">
        {confirming ? <>
          <button type="button" onClick={onDelete} className="min-h-8 rounded-full border border-[#A46C65]/65 px-2.5 text-xs font-semibold text-[#783E38]">Confirm delete</button>
          <button type="button" onClick={() => setConfirming(false)} className="min-h-8 px-2 text-xs font-medium text-[#354D40]">Back</button>
        </> : <>
          <button type="submit" className="min-h-8 rounded-full bg-[#3D6653] px-2.5 text-xs font-semibold text-white">Save title</button>
          <button type="button" onClick={() => setConfirming(true)} className="min-h-8 rounded-full border border-[#A46C65]/65 px-2.5 text-xs font-semibold text-[#783E38]">Delete list</button>
        </>}
      </div>
    </div>
  </form>
}
