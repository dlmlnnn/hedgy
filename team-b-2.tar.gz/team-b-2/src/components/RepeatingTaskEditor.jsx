import { useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import Calendar from './Calendar'
import { dateKey } from './calendarDates'
import DeleteTaskDialog from './DeleteTaskDialog'
import NotificationPicker from './NotificationPicker'
import TaskApple, { applePalette, taskAppleColor } from './TaskApple'
import TaskListField from './TaskListField'
import TimeAccordion from './TimeAccordion'
import { appliesOn } from './taskSchedule'

const icons = {
  calendar: 'M7 3v4m10-4v4M3 10h18M6 5h12a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3Z',
  notification: 'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4',
}
const control = 'flex min-h-8 min-w-0 items-center justify-center gap-1 rounded-lg border border-[#6E9A82]/40 bg-white/45 px-1.5 text-xs font-semibold text-[#354D40] hover:bg-white/70 focus-visible:outline-2 focus-visible:outline-[#4F7A66]'
const monthFormat = new Intl.DateTimeFormat('en-US', { month: 'short' })
const monthYearFormat = new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric' })

function usesFixedDates(task) {
  return task.cadence === 'dates' || !['schedule', 'daily', 'weekdays'].includes(task.rule)
}

function previewDates(task, today) {
  if (usesFixedDates(task)) {
    return [...new Set([...(task.dates || []), ...(task.restoredDates || [])])]
      .filter(date => date >= today && appliesOn(task, date)).sort()
  }
  const first = new Date(`${[today, task.startDate || today].sort().at(-1)}T12:00:00`)
  const end = new Date(first)
  end.setFullYear(end.getFullYear() + 1)
  const dates = []
  for (const day = new Date(first); day < end; day.setDate(day.getDate() + 1)) {
    const date = dateKey(day)
    if (appliesOn(task, date)) dates.push(date)
  }
  return [...new Set([...dates, ...(task.restoredDates || []).filter(date => date >= today && appliesOn(task, date))])].sort()
}

function applyDates(task, before, after, today) {
  const selected = new Set(after)
  const previous = new Set(before)
  const excluded = new Set(task.excludedDates)
  const restored = new Set(task.restoredDates)
  const fixed = usesFixedDates(task)
  for (const date of before) {
    if (!selected.has(date)) {
      if (!fixed) excluded.add(date)
      restored.delete(date)
    }
  }
  for (const date of after) {
    if (previous.has(date)) continue
    excluded.delete(date)
    if (!fixed && !appliesOn({ ...task, excludedDates: [...excluded] }, date)) restored.add(date)
  }
  const changes = { excludedDates: [...excluded].sort(), restoredDates: [...restored].sort() }
  if (fixed) {
    changes.dates = [...new Set([...(task.dates || []).filter(date => date < today), ...after])].sort()
  }
  return { ...task, ...changes }
}

function ControlIcon({ name }) {
  return <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" className="size-4 shrink-0">
    <path d={icons[name]} stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
}

export default function RepeatingTaskEditor({ task, lists, today, onCreateList, onOverlayChange, onSave, onClose, onDelete }) {
  const [draft, setDraft] = useState(task)
  const [panel, setPanel] = useState(null)
  const [calendarDate, setCalendarDate] = useState(null)
  const [showMonths, setShowMonths] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const calendarTrigger = useRef(null)
  const deleteTrigger = useRef(null)
  const dates = useMemo(() => previewDates(draft, today), [draft, today])
  const months = new Map()
  for (const date of dates) {
    const month = date.slice(0, 7)
    if (!months.has(month)) months.set(month, [])
    months.get(month).push(date.slice(-2).replace(/^0/, ''))
  }
  const monthRows = [...months]
  const color = Object.keys(applePalette).find(name => applePalette[name] === taskAppleColor(draft))
  const patch = (key, value) => setDraft(previous => ({ ...previous, [key]: value }))
  const togglePanel = name => setPanel(previous => previous === name ? null : name)
  function openCalendar(date, event) {
    calendarTrigger.current = event.currentTarget
    onOverlayChange(true)
    setCalendarDate(date)
  }
  function closeCalendar() {
    setCalendarDate(null)
    onOverlayChange(false)
    requestAnimationFrame(() => calendarTrigger.current?.focus({ preventScroll: true }))
  }
  function submit(event) {
    event.preventDefault()
    if (draft.title.trim()) onSave({ ...draft, title: draft.title.trim() })
  }
  return <>
      <form aria-label="Edit repeating task" onSubmit={submit} onKeyDown={event => {
        if (event.key === 'Escape') { event.stopPropagation(); onClose() }
      }} className="mx-auto grid w-full min-w-0 grid-cols-[minmax(0,1fr)] gap-1.5 py-2 text-[#2E2A25]">
        <div className="flex items-center gap-2">
          <button type="button" aria-label={`Apple color, ${color}`} aria-expanded={panel === 'color'} onClick={() => togglePanel('color')} className="grid size-9 shrink-0 place-items-center rounded-lg border border-dashed border-[#76877A] bg-white/35 focus-visible:outline-2 focus-visible:outline-[#4F7A66]">
            <TaskApple task={{ appleColor: color }} size={20} />
          </button>
          <div className="relative min-w-0 flex-1">
            <input aria-label="Title" placeholder="Title" value={draft.title} onChange={event => patch('title', event.target.value)} required maxLength={160} className="h-9 w-full rounded-lg bg-white/45! px-2 text-sm font-semibold outline-[#4F7A66]" />
            <svg aria-hidden="true" className="pointer-events-none absolute inset-0 h-full w-full" fill="none">
              <rect x=".5" y=".5" rx="7.5" className="h-[calc(100%-1px)] w-[calc(100%-1px)]" stroke="#87978A" strokeOpacity=".5" strokeDasharray="8 4" />
            </svg>
          </div>
        </div>
        {panel === 'color' && <div aria-label="Apple colors" role="group" className="flex items-center gap-1 rounded-xl bg-white/40 p-1">
          {Object.keys(applePalette).map(name => <button key={name} type="button" aria-label={name} aria-current={name === color ? 'true' : undefined} onClick={() => { patch('appleColor', name); setPanel(null) }} className="grid size-11 place-items-center rounded-xl aria-[current=true]:bg-[#DCE7DC] focus-visible:outline-2 focus-visible:outline-[#4F7A66]"><TaskApple task={{ appleColor: name }} /></button>)}
        </div>}
        <div className="grid grid-cols-[1fr_.7fr_1.45fr] items-start gap-1">
          <TimeAccordion value={draft.time} expanded={panel === 'time'} onToggle={() => togglePanel('time')} onChange={value => patch('time', value)} />
          <button type="button" aria-label="Calendar" aria-haspopup="dialog" onClick={event => openCalendar(dates[0] || today, event)} className={control}><ControlIcon name="calendar" /></button>
          <button type="button" aria-expanded={panel === 'notification'} onClick={() => togglePanel('notification')} className={control}><ControlIcon name="notification" /><span className="text-[10px]">Notification</span></button>
        </div>
        {panel === 'notification' && <NotificationPicker value={draft.notification} onChange={value => patch('notification', value)} />}
        <section aria-label="Scheduled dates by month" className="rounded-xl border border-[#6E9A82]/30 bg-white/45 px-2">
          <ul className={`task-scroll divide-y divide-[#6E9A82]/25 ${showMonths ? 'max-h-28 overflow-y-auto overscroll-contain' : ''}`}>
            {monthRows.length === 0 && <li className="py-2 text-center text-xs text-[#59554D]">No upcoming dates.</li>}
            {(showMonths ? monthRows : monthRows.slice(0, 3)).map(([month, days]) => {
              const date = new Date(`${month}-01T12:00:00`)
              const preview = days.join(', ')
              return <li key={month} className="flex min-w-0 items-center gap-1.5">
                <button type="button" aria-label={`Open ${monthYearFormat.format(date)} in calendar`} onClick={event => openCalendar(`${month}-01`, event)} className="grid min-h-8 min-w-10 shrink-0 place-items-center rounded-full text-xs font-semibold text-[#354D40] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">
                  <span className="rounded-full border border-[#6E9A82]/40 bg-[#E8EFE5] px-2 py-0.5 hover:bg-[#DCE7DC]">{monthFormat.format(date)}</span>
                </button>
                <span title={preview} className="min-w-0 flex-1 truncate text-xs text-[#45443F]">{preview}</span>
              </li>
            })}
          </ul>
          {monthRows.length > 3 && <button type="button" aria-expanded={showMonths} onClick={() => setShowMonths(value => !value)} className="flex min-h-7 w-full items-center justify-center gap-1 border-t border-[#6E9A82]/25 text-xs text-[#354D40] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">{showMonths ? 'Fewer months' : 'More months'} <span aria-hidden="true" className={showMonths ? 'rotate-180' : ''}>⌄</span></button>}
        </section>
        <TaskListField hideLabel lists={lists} value={draft.list} onChange={value => patch('list', value)} onCreateList={onCreateList} onOverlayChange={onOverlayChange} />
        <button type="submit" disabled={!draft.title.trim()} className="min-h-9 rounded-full bg-[#4F7A66] text-sm font-semibold text-white">Save changes</button>
        <button ref={deleteTrigger} type="button" onClick={() => { onOverlayChange(true); setDeleting(true) }} className="min-h-9 rounded-full border border-[#A46C65]/60 text-sm font-medium text-[#783E38]">Delete repeating task</button>
      </form>
    {calendarDate && createPortal(
      <div className="absolute inset-0 z-[70]" onClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}>
        <Calendar mode="multi" tasks={[]} selectionType="commitment" initialDate={calendarDate} initialDates={dates} allowEmpty={!usesFixedDates(draft)} multiLabel="Schedule repeating task" confirmLabel="Apply dates" onClose={closeCalendar} onPick={(selected, { recurrence, recurrencePattern }) => {
          const unchanged = dates.length === selected.length && dates.every((date, index) => date === selected[index])
          setDraft(previous => ({
            ...applyDates(previous, dates, selected, today),
            recurrencePattern: recurrencePattern || (!recurrence && unchanged ? previous.recurrencePattern : undefined),
          }))
          closeCalendar()
        }} />
      </div>, document.querySelector('.app-stage')
    )}
    {deleting && createPortal(
      <div className="absolute inset-0 z-[70]" onClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}>
        <DeleteTaskDialog task={task} allowOccurrence={false} onClose={() => {
          setDeleting(false)
          onOverlayChange(false)
          requestAnimationFrame(() => deleteTrigger.current?.focus({ preventScroll: true }))
        }} onDelete={() => { onOverlayChange(false); onDelete() }} />
      </div>, document.querySelector('.app-stage')
    )}
  </>
}
