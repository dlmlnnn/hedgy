const dayNumber = date => Date.parse(`${date}T00:00:00Z`) / 86400000
const dateFromDay = day => new Date(day * 86400000).toISOString().slice(0, 10)

export function selectRecurringMonths(selected, start, months, days) {
  const anchor = new Date(`${start}T00:00:00Z`)
  const end = new Date(anchor)
  end.setUTCFullYear(end.getUTCFullYear() + 1)
  const result = new Set([...selected].filter(date => date < start || date >= end.toISOString().slice(0, 10)))
  for (let offset = 0; offset < 12; offset++) {
    const first = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth() + offset, 1))
    if (!months.includes(first.getUTCMonth() + 1)) continue
    for (const day of days) {
      const date = new Date(first)
      date.setUTCDate(day)
      if (date.getUTCMonth() !== first.getUTCMonth() || date < anchor) continue
      result.add(date.toISOString().slice(0, 10))
    }
  }
  return result
}

export function selectWeekdaysInMonth(selected, year, month, today, weekdays, anchorDate) {
  const first = `${year}-${String(month + 1).padStart(2, '0')}-01`
  const last = `${year}-${String(month + 1).padStart(2, '0')}-${new Date(year, month + 1, 0).getDate()}`
  const start = [first, today, anchorDate || first].sort().at(-1)
  const result = new Set([...selected].filter(date => date < start || date > last))
  for (let day = dayNumber(start); day <= dayNumber(last); day++) {
    if (weekdays.includes(new Date(day * 86400000).getUTCDay() || 7)) result.add(dateFromDay(day))
  }
  return result
}

export function selectIntervalRange(selected, year, month, today, interval, anchorDate) {
  if (!Number.isInteger(interval) || interval < 2 || interval > 30) return new Set(selected)
  const first = `${year}-${String(month + 1).padStart(2, '0')}-01`
  const last = `${year}-${String(month + 1).padStart(2, '0')}-${new Date(year, month + 1, 0).getDate()}`
  const existing = [...selected].sort()
  const inMonth = existing.find(date => date >= first && date <= last)
  const previous = existing.filter(date => date < first).at(-1)
  const start = Math.max(dayNumber(first), dayNumber(today), anchorDate ? dayNumber(anchorDate) : 0)
  let anchor = anchorDate ? dayNumber(anchorDate) : inMonth ? dayNumber(inMonth) : previous ? dayNumber(previous) + interval : start
  if (anchor < start) anchor += Math.ceil((start - anchor) / interval) * interval
  const endDate = new Date(start * 86400000)
  endDate.setUTCFullYear(endDate.getUTCFullYear() + 1)
  const end = endDate.getTime() / 86400000
  const result = new Set(existing.filter(date => dayNumber(date) < start || dayNumber(date) >= end))
  for (let day = anchor; day < end; day += interval) result.add(dateFromDay(day))
  return result
}

export function selectMonthDays(selected, year, month, today, { weekdays, interval, anchorDate }) {
  const first = `${year}-${String(month + 1).padStart(2, '0')}-01`
  const last = `${year}-${String(month + 1).padStart(2, '0')}-${new Date(year, month + 1, 0).getDate()}`
  const existing = [...selected].sort()
  const result = new Set(existing.filter(date => date < first || date > last))
  const pickedStart = anchorDate && anchorDate <= last ? dayNumber(anchorDate) : dayNumber(first)
  const start = Math.max(dayNumber(first), dayNumber(today), weekdays ? pickedStart : dayNumber(first))
  const end = dayNumber(last)
  if (start > end) return result
  if (weekdays) {
    for (let day = start; day <= end; day++) if (weekdays.includes(new Date(day * 86400000).getUTCDay() || 7)) result.add(dateFromDay(day))
  } else if (Number.isInteger(interval) && interval >= 2 && interval <= 30) {
    const inMonth = existing.find(date => date >= first && date <= last)
    const previous = existing.filter(date => date < first).at(-1)
    let anchor = anchorDate && anchorDate <= last ? dayNumber(anchorDate) : inMonth ? dayNumber(inMonth) : previous ? dayNumber(previous) + interval : start
    if (anchor < start) anchor += Math.ceil((start - anchor) / interval) * interval
    for (let day = anchor; day <= end; day += interval) result.add(dateFromDay(day))
  }
  return result
}

export function migrateGoalDates(item) {
  if (item.type !== 'goal') return item
  const { stepWeekdays, ...goal } = item
  const dates = new Set(goal.stepDates || [])
  if (stepWeekdays?.length) {
    for (let day = dayNumber(goal.startDate); day <= dayNumber(goal.deadline); day++) {
      if (stepWeekdays.includes(new Date(day * 86400000).getUTCDay() || 7)) dates.add(dateFromDay(day))
    }
  }
  return { ...goal, stepDates: [...dates].filter(date => date >= goal.startDate && date <= goal.deadline).sort() }
}
