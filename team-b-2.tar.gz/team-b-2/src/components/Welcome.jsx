import { useEffect, useState } from 'react'

function RunningHedgehog() {
  return <svg aria-hidden="true" width="64" height="40" viewBox="0 0 64 40" className="welcome-hedgehog-stride overflow-visible">
    <ellipse cx="32" cy="35" rx="29" ry="3" fill="#625848" opacity=".12" />
    <path className="welcome-running-feet" d="m17 34 3-5m23 5 3-5" fill="none" stroke="#79674F" strokeWidth="3" strokeLinecap="round" />
    <path d="M15 28 13 19l5-1-1-7 6 2 2-9 6 5 5-7 4 7 7-3 1 7 7-1-2 7 6 3-4 10-20 2Z" fill="#8B7C61" stroke="#706449" strokeWidth=".7" strokeLinejoin="round" />
    <path d="M20 22Q14 16 9 22L1 28q8 8 23 2Z" fill="#D7C4A3" stroke="#A69070" strokeWidth=".6" />
    <circle cx="14" cy="24" r="1.1" fill="#2E2A25" /><circle cx="1.6" cy="28" r="1.6" fill="#62513E" />
    <path d="m24 15 2 4m5-7 2 5m6-3 1 4m6 1 2 3m-14 0 1 4m-10-2 1 3m16-2 2 3" fill="none" stroke="#B5A283" strokeWidth="1.1" strokeLinecap="round" />
  </svg>
}

export default function Welcome({ onStart, exiting }) {
  const [ready, setReady] = useState(() => window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  useEffect(() => {
    if (ready) return
    const timer = setTimeout(() => setReady(true), 1500)
    return () => clearTimeout(timer)
  }, [ready])
  return <section aria-labelledby="hedgy-welcome-title" className={`hedgy-welcome absolute inset-0 overflow-hidden bg-[#F3EEDF] ${exiting ? 'welcome-exiting' : ''}`}>
    <h1 id="hedgy-welcome-title" className="absolute left-1/2 top-1/2 w-full -translate-x-1/2 -translate-y-1/2 px-5 text-center font-serif text-[clamp(36px,11vw,44px)] font-semibold leading-tight text-[#2E2A25]">Hedgy Planner</h1>
    <div aria-hidden="true" className="absolute inset-x-6 top-[62%] h-px bg-[#6E9A82]/20" />
    <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-[calc(62%-35px)] h-10">
      {[0,1,2].map(index => <div key={index} data-welcome-runner className="welcome-hedgehog-runner absolute inset-0" style={{ animationDelay: `${index * 150}ms` }}><RunningHedgehog /></div>)}
    </div>
    {ready && <button type="button" onClick={onStart} disabled={exiting} className="welcome-get-started absolute inset-x-6 bottom-[max(24px,env(safe-area-inset-bottom))] flex h-14 items-center justify-center rounded-full bg-[#4F7A66] px-5 text-[16px] font-bold text-[#F8F4E8] shadow-[0_8px_24px_rgba(70,50,30,0.18)] transition active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#2E2A25]">Get started</button>}
  </section>
}
