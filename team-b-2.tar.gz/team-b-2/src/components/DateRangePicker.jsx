import { useState } from 'react'
import { createPortal } from 'react-dom'
import { dateKey } from './calendarDates'

export default function DateRangePicker({ start, end, blue, onClose, onSave }) {
  const [first, setFirst] = useState(start)
  const [last, setLast] = useState(end)
  const [month, setMonth] = useState(() => new Date(`${start}T12:00:00`))
  const [choosingEnd, setChoosingEnd] = useState(false)
  return createPortal(<div role="dialog" aria-modal="true" aria-label="Choose date range" onClick={event => { event.stopPropagation(); onClose() }} onKeyDown={event => { event.stopPropagation(); if (event.key === 'Escape') onClose() }} className="absolute inset-0 z-[70] flex items-center justify-center bg-[#2E2A25]/20 backdrop-blur-[3px]">
    <div onClick={event => event.stopPropagation()} className="task-scroll max-h-[90%] w-[min(300px,94%)] overflow-y-auto rounded-[28px] border-2 border-[#6E9A82] bg-[#F8F4E8] p-4 shadow-xl">
      <div className="flex items-center justify-between"><button type="button" aria-label="Previous month" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))} className="h-11 w-11">‹</button><span className="text-[14px] font-semibold">{month.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span><button type="button" aria-label="Next month" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))} className="h-11 w-11">›</button></div>
      <p className="mb-2 text-center text-[12px]">{choosingEnd ? 'Choose end date' : 'Choose start date'}</p>
      <div className="grid grid-cols-7">{Array.from({ length: new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate() }, (_, i) => {
        const date = dateKey(new Date(month.getFullYear(), month.getMonth(), i + 1))
        const edge = date === first || date === last
        return <button type="button" key={date} onClick={() => { if (!choosingEnd || date < first) { setFirst(date); setLast(date); setChoosingEnd(true) } else { setLast(date); setChoosingEnd(false) } }} className={`min-h-11 text-[13px] ${edge ? `rounded-full text-white ${blue ? 'bg-[#5B8DB8]' : 'bg-[#4F7A66]'}` : date > first && date < last ? blue ? 'bg-[#D7E5EF]' : 'bg-[#DDE8DA]' : ''}`}>{i + 1}</button>
      })}</div>
      <button type="button" onClick={() => onSave(first, last)} className="mt-3 min-h-11 w-full rounded-full bg-[#4F7A66] text-sm text-white">Save range</button>
    </div>
  </div>, document.querySelector('.app-stage'))
}
