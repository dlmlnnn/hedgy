import TaskRows from './TaskRows'

export default function GroupedTasks({ items, lists, showEmpty = false, ...rowProps }) {
  const groups = new Map([['', []], ...lists.map(name => [name, []])])
  for (const item of items) {
    const name = item.list || ''
    if (!groups.has(name)) groups.set(name, [])
    groups.get(name).push(item)
  }
  const visible = [...groups].filter(([, tasks]) => showEmpty || tasks.length)
  return <div className="task-scroll h-full overflow-y-auto overscroll-y-contain pb-[88px]">
    {!visible.length && <p className="py-8 text-center text-sm text-[#59554D]">No unfinished tasks today.</p>}
    {visible.map(([name, tasks]) => <section key={name} aria-label={name || 'Inbox'} className="mb-2 last:mb-0">
      <h3 className={!showEmpty && visible.length === 1 && !name ? 'sr-only' : 'break-words px-6 pt-2 text-sm font-semibold text-[#3D6653]'}>{name || 'Inbox'}</h3>
      <TaskRows items={tasks} {...rowProps} embedded />
    </section>)}
  </div>
}
