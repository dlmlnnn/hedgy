import { useLayoutEffect } from 'react'

export default function useTriggerExpansion(panelRef, triggerRef, enabled = true) {
  useLayoutEffect(() => {
    const panel = panelRef.current
    const trigger = triggerRef?.current
    if (!enabled || !panel || !trigger || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    const panelBounds = panel.getBoundingClientRect()
    const triggerBounds = trigger.getBoundingClientRect()
    const originX = triggerBounds.left + triggerBounds.width / 2 - panelBounds.left
    const originY = triggerBounds.top + triggerBounds.height / 2 - panelBounds.top
    const origin = `${originX}px ${originY}px`
    const animation = panel.animate([
      { transform: 'scale(.15)', transformOrigin: origin },
      { transform: 'scale(1)', transformOrigin: origin },
    ], { duration: 320, easing: 'cubic-bezier(0.22, 1, 0.36, 1)' })
    return () => animation.cancel()
  }, [panelRef, triggerRef, enabled])
}
