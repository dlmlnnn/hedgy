import { useEffect, useId, useLayoutEffect, useRef, useState } from 'react'
import TaskApple, { applePalette, taskAppleColor } from './TaskApple'
import { appliesOn } from './taskSchedule'
import FolderCard, { readFolderCover } from './FolderCard'
import FolderDetail from './FolderDetail'

const weekdayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
function repeatSummary(task) {
  if (task.cadence === 'dates' || !['schedule', 'daily', 'weekdays'].includes(task.rule)) {
    const dates = new Set([...(task.dates || []), ...(task.restoredDates || [])])
    const count = [...dates].filter(date => appliesOn(task, date)).length
    return `${count} scheduled ${count === 1 ? 'date' : 'dates'}`
  }
  const weekdays = task.weekdays || []
  let summary = 'Every day'
  if (task.cadence === 'interval') summary = `Every ${task.interval} days`
  else if (task.rule !== 'daily' && weekdays.length < 7) summary = weekdays.map(day => weekdayNames[day - 1]).join(', ') || 'Selected weekdays'
  if (task.rule === 'schedule' && task.months?.length && task.months.length < 12) {
    const months = task.months.map(month => new Date(2026, month - 1, 1).toLocaleDateString('en-US', { month: 'short' }))
    summary += ` · ${months.join(', ')}`
  }
  return task.time ? `${summary} · ${task.time}` : summary
}

const recurringPage = 'Reocurring tasks'
const taskListsPage = 'Task folders'
const taskPages = new Set(['Completed', recurringPage, taskListsPage])
const cloudModes = [
  { value: 'classic', title: 'Classic Clouds', description: 'Soft clouds drift across the sky without touch controls.' },
  { value: 'scratch', title: 'Scratch-off Clouds', description: 'Rub or drag across clouds to wipe them away.' },
  { value: 'notes', title: 'Scratch-off note Clouds', description: 'Tap a cloud to write a note, or drag to erase it.' },
]
const menuItems = [
  { label: 'Folders', page: taskListsPage, path: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z' },
  { label: recurringPage, path: 'M4 11V8a3 3 0 0 1 3-3h13m-4-4 4 4-4 4m4 4v3a3 3 0 0 1-3 3H4m4-4-4 4 4 4' },
  { label: 'Completed', path: 'm5 12 4 4L19 6' },
  { label: 'Information' },
  { label: 'Settings', path: 'M10 2.8h4l.7 2.4 2.4 1.4 2.4-.6 2 3.5-1.7 1.8v2.8l1.7 1.8-2 3.5-2.4-.6-2.4 1.4-.7 2.4h-4l-.7-2.4-2.4-1.4-2.4.6-2-3.5 1.7-1.8v-2.8L2.5 9.5l2-3.5 2.4.6 2.4-1.4.7-2.4Z M15 12.7a3 3 0 1 0-6 0 3 3 0 1 0 6 0' },
]
const settingsOptions = ['Theme', 'Cloud notes', 'Tree & birds']
const themes = ['Regular', 'Dark', 'Neutral']

export default function SettingsDialog({ onClose, completedContent, repeatingTasks, lists, folderCovers, onSaveFolders, linkedFolder, folderDescriptions, folderLists, folderTasks, onSaveFolderDetail, onOpenFolderPage, renderRepeatingEditor, suspended, closing, skyColor, groundColor, lightGroundColor, theme, onThemeChange, cloudMode, onCloudModeChange }) {
  const dialog = useRef(null)
  const currentContent = useRef(null)
  const repeatingScroll = useRef(0)
  const [page, setPage] = useState(() => linkedFolder ? { folder: linkedFolder } : null)
  const [outgoing, setOutgoing] = useState(null)
  const [contentHeight, setContentHeight] = useState(null)
  const [settingsExpanded, setSettingsExpanded] = useState(false)
  const [folderDrafts, setFolderDrafts] = useState(null)
  const [folderToDelete, setFolderToDelete] = useState(null)
  const folderDeleteTrigger = useRef(null)
  const folderEditButton = useRef(null)
  const [folderCardKeys, setFolderCardKeys] = useState(new Map())
  const [folderDropTarget, setFolderDropTarget] = useState(null)
  const [newFolderName, setNewFolderName] = useState(null)
  const [uploadingFolder, setUploadingFolder] = useState(null)
  const coverUpload = useRef(null)
  const [listError, setListError] = useState('')
  const [expandedTaskId, setExpandedTaskId] = useState(null)
  const [repeatingOverlay, setRepeatingOverlay] = useState(false)
  const settingsId = useId()
  const deleteTitleId = useId()
  useEffect(() => { if (!suspended) dialog.current?.focus({ preventScroll: true }) }, [page, expandedTaskId, suspended])
  useLayoutEffect(() => {
    const content = currentContent.current
    if (!content) return
    if (page === recurringPage && !expandedTaskId) {
      const list = content.querySelector('[data-repeating-scroll]')
      if (list) list.scrollTop = repeatingScroll.current
    }
    const measure = () => setContentHeight(content.offsetHeight)
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(content)
    return () => observer.disconnect()
  }, [page, expandedTaskId])
  useEffect(() => {
    if (!outgoing) return
    const timer = setTimeout(() => setOutgoing(null), 320)
    return () => clearTimeout(timer)
  }, [outgoing])
  function transitionTo(nextPage, nextEditor, direction, vertical = false) {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    setOutgoing(reducedMotion ? null : { page, editor: expandedTaskId, direction, vertical })
    setExpandedTaskId(nextEditor)
    setPage(nextPage)
  }
  function navigate(next) {
    if (next === page) return
    if (page === taskListsPage) coverUpload.current = null
    if (next === taskListsPage) { setFolderDrafts(null); setFolderDropTarget(null); setNewFolderName(null); setUploadingFolder(null); setListError('') }
    if (next === recurringPage) repeatingScroll.current = 0
    transitionTo(next, null, next && !page?.folder ? 1 : -1)
  }
  function openEditor(taskId, event) {
    repeatingScroll.current = event.currentTarget.closest('[data-repeating-scroll]')?.scrollTop || 0
    transitionTo(recurringPage, taskId, 1, true)
  }
  function collapseEditor() {
    if (!expandedTaskId) return
    const rowId = `${settingsId}-repeat-${expandedTaskId}`
    transitionTo(recurringPage, null, -1, true)
    requestAnimationFrame(() => document.getElementById(rowId)?.focus({ preventScroll: true }))
  }
  function dismissSurface() {
    if (folderToDelete) closeFolderDelete()
    else if (expandedTaskId) collapseEditor()
    else onClose()
  }
  function closeFolderDelete(confirmed = false) {
    if (confirmed) {
      setFolderDrafts(previous => previous.filter(folder => folder.key !== folderToDelete.key))
      setListError('')
    }
    setFolderToDelete(null)
    requestAnimationFrame(() => (confirmed ? folderEditButton.current : folderDeleteTrigger.current)?.focus())
  }
  function editLists() {
    if (!folderDrafts) {
      setFolderDrafts(lists.map(name => ({ key: folderCardKeys.get(name) ?? name, originalName: name, name, cover: folderCovers.get(name) })))
      return
    }
    const names = folderDrafts.map(draft => draft.name.trim())
    const normalized = names.map(name => name.toLowerCase())
    if (names.some(name => !name)) { setListError('Enter a name for each folder.'); return }
    if (normalized.includes('inbox') || new Set(normalized).size !== names.length) { setListError('Choose a different name for each folder.'); return }
    const error = onSaveFolders(folderDrafts.map((draft, index) => ({ ...draft, name: names[index] })))
    if (error) { setListError(error); return }
    setFolderCardKeys(new Map(names.map((name, index) => [name, folderDrafts[index].key])))
    setFolderDrafts(null)
    setListError('')
  }
  function moveFolder(index, target) {
    setFolderDrafts(previous => {
      if (!previous || index === target || target < 0 || target >= previous.length) return previous
      const next = [...previous]
      const [folder] = next.splice(index, 1)
      next.splice(target, 0, folder)
      return next
    })
  }
  function addFolder(event) {
    event.preventDefault()
    const name = newFolderName.trim()
    if (!name) { setListError('Enter a folder name.'); return }
    const normalized = name.toLowerCase()
    if (normalized === 'inbox' || folderDrafts.some(draft => draft.name.trim().toLowerCase() === normalized)) {
      setListError('Choose a different folder name.')
      return
    }
    const key = crypto.randomUUID()
    setFolderDrafts(previous => [...previous, { key, name }])
    setNewFolderName(null)
    setListError('')
  }
  function updateFolderDraft(index, changes) {
    setFolderDrafts(previous => previous.map((draft, position) => position === index ? { ...draft, ...changes } : draft))
    setListError('')
  }
  async function uploadFolderCover(index, file) {
    if (coverUpload.current) return
    const upload = {}
    coverUpload.current = upload
    setUploadingFolder(index)
    setListError('')
    try {
      const cover = await readFolderCover(file)
      if (coverUpload.current === upload) updateFolderDraft(index, { cover })
    } catch {
      if (coverUpload.current === upload) setListError('This image could not be opened. Try another photo.')
    } finally {
      if (coverUpload.current === upload) {
        coverUpload.current = null
        setUploadingFolder(null)
      }
    }
  }
  function renderPage(view, editor, leaving) {
    if (view === 'Cloud notes') return <div className="cloud-mode-panel task-scroll min-h-0 overflow-y-auto px-2 pb-2">
        <header className="flex items-center gap-1 pb-1">
          <button type="button" aria-label="Back to menu" onClick={() => navigate(null)} className="size-11 shrink-0 rounded-lg text-xl font-normal focus-visible:outline-2">←</button>
          <h2 className="planner-page-heading cloud-mode-heading text-[15px]">Cloud notes</h2>
        </header>
        <fieldset aria-label="Cloud mode" className="grid px-2">
          {cloudModes.map(({ value, title, description }) => <label key={value} className="cloud-mode-row flex min-h-16 cursor-pointer items-center gap-3 px-2 py-3">
            <input className="cloud-mode-radio size-3.5 shrink-0" type="radio" name={`${settingsId}${leaving ? '-outgoing' : ''}-cloud-mode`}
              checked={cloudMode === value} onChange={() => onCloudModeChange(value)} aria-label={title}
              aria-describedby={leaving ? undefined : `${settingsId}-cloud-${value}`} />
            <span className="min-w-0">
              <span className="block text-sm font-normal">{title}</span>
              <span id={leaving ? undefined : `${settingsId}-cloud-${value}`} className="cloud-mode-description mt-0.5 block text-xs leading-relaxed">{description}</span>
            </span>
          </label>)}
        </fieldset>
      </div>
    if (view === 'Theme') return <>
      <button type="button" aria-label="Back to menu" onClick={() => navigate(null)} className="size-11 shrink-0 self-start rounded-full text-xl text-[#454A41] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">←</button>
      <div className="task-scroll min-h-0 overflow-y-auto rounded-2xl border border-white/50 bg-white/45 px-4 py-3 shadow-sm">
        <h2 className="planner-page-heading px-1 pb-2 text-sm">Theme</h2>
        <fieldset aria-label="Theme" className="divide-y divide-neutral-500/15">
          {themes.map(label => {
            const value = label.toLowerCase()
            return <label key={value} className="flex min-h-12 cursor-pointer items-center justify-between gap-3 px-1 text-sm font-medium text-[#2E2A25]">
              {label}
              <span className="relative">
                <input type="radio" name={`${settingsId}${leaving ? '-outgoing' : ''}-theme`} value={value} checked={theme === value} onChange={() => onThemeChange(value)} className="peer sr-only" />
                <span aria-hidden="true" className="block h-6 w-11 rounded-full border border-neutral-500/30 bg-neutral-400/40 transition-colors peer-checked:bg-[#527561] peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-[#4F7A66] motion-reduce:transition-none" />
                <span aria-hidden="true" className="pointer-events-none absolute left-0.5 top-0.5 size-5 rounded-full bg-white shadow-sm transition-transform peer-checked:translate-x-5 motion-reduce:transition-none" />
              </span>
            </label>
          })}
        </fieldset>
      </div>
    </>
    if (view?.folder) {
      const name = view.folder
      return <>
        <button type="button" aria-label="Back to task folders" onClick={() => navigate(taskListsPage)} className="size-11 shrink-0 self-start rounded-full text-xl text-[#454A41] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">←</button>
        <div className="task-scroll min-h-0 overflow-y-auto overscroll-contain rounded-2xl border border-white/50 bg-white/45 p-3 text-[#2E2A25] shadow-sm">
          {lists.includes(name) ? <FolderDetail name={name} cover={folderCovers.get(name)} description={folderDescriptions.get(name)}
            lists={folderLists.filter(entry => entry.folder === name)} tasks={folderTasks.filter(task => task.list === name)}
            onOpenPage={id => onOpenFolderPage(name, id)} onSave={details => {
              const error = onSaveFolderDetail(name, details)
              if (!error && details.name !== name) setPage({ folder: details.name })
              return error
            }} /> : <p className="py-4 text-center text-sm text-neutral-600">This folder is unavailable in this browser.</p>}
        </div>
      </>
    }
    return taskPages.has(view) ? <>
        <div className="flex shrink-0 items-center justify-between text-[#2E2A25]">
          <button type="button" aria-label={editor ? "Back to Reocurring tasks" : "Back to menu"} onClick={editor ? collapseEditor : () => navigate(null)} className="size-11 rounded-full text-xl text-[#454A41] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">←</button>
          {view !== taskListsPage && <button type="button" aria-label="Close menu" onClick={onClose} className="size-11 rounded-full text-xl text-[#454A41] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">×</button>}
        </div>
        <div className="flex min-h-0 flex-col overflow-hidden rounded-2xl border border-white/50 bg-white/45 text-[#2E2A25] shadow-sm">
          {view === taskListsPage ? <div className="flex shrink-0 items-center justify-between gap-2 px-5 pt-1">
            <h2 className="planner-page-heading text-[14px] leading-[18px]">{view}</h2>
            <button ref={leaving ? undefined : folderEditButton} type="button" onClick={editLists} disabled={uploadingFolder !== null || newFolderName !== null || folderDropTarget !== null} className="min-h-10 rounded-lg px-2 text-sm font-semibold text-[#354D40] focus-visible:outline-2 focus-visible:outline-[#4F7A66] disabled:opacity-50">{folderDrafts ? 'Save' : 'Edit'}</button>
          </div> : (view !== recurringPage || !editor) && <h2 className="planner-page-heading shrink-0 px-5 pb-2 pt-3 text-[14px] leading-[18px]">{view}</h2>}
          <div data-repeating-scroll={view === recurringPage || undefined} className="task-scroll min-h-0 overflow-y-auto overscroll-contain">
          {view === taskListsPage ? <>
            {lists.length === 0 && <div data-open={!folderDrafts} aria-hidden={Boolean(folderDrafts)} className="folder-edit-reveal">
              <div><p className="px-5 pb-3 text-sm text-[#59554D]">No task folders yet.</p></div>
            </div>}
            {listError && <p role="alert" className="px-5 py-2 text-xs text-[#783E38]">{listError}</p>}
            <ul className="grid grid-cols-2 gap-x-3 px-4 pb-1 pt-1">
              {(folderDrafts || lists.map(name => ({ key: folderCardKeys.get(name) ?? name, name, cover: folderCovers.get(name) }))).map((folder, index) => {
                return <FolderCard key={folder.key} name={folder.name || folder.originalName || 'New folder'} editing={folderDrafts && folder} cover={folder.cover}
                  onOpen={() => navigate({ folder: folder.name })}
                  uploading={uploadingFolder === index} uploadPending={uploadingFolder !== null} onNameChange={value => updateFolderDraft(index, { name: value })}
                  index={index} reorderDisabled={(folderDrafts?.length ?? 0) < 2} dropTarget={folderDropTarget === index}
                  onDragTarget={setFolderDropTarget} onMove={moveFolder}
                  onDelete={event => { folderDeleteTrigger.current = event.currentTarget; setFolderToDelete(folder) }}
                  onCoverChange={file => uploadFolderCover(index, file)} onCoverRemove={() => updateFolderDraft(index, { cover: undefined })} />
              })}
              <li inert={!folderDrafts} aria-hidden={!folderDrafts} data-open={Boolean(folderDrafts)} className="folder-edit-reveal min-w-0 self-start">
                <div><div className="mb-3 rounded-2xl border border-dashed border-neutral-500/25 bg-white/20 p-3.5 sm:p-4">
                {newFolderName === null ? <button type="button" onClick={() => { setNewFolderName(''); setListError('') }}
                  className="group block w-full rounded-xl text-center text-neutral-600 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-neutral-500">
                  <span className="grid aspect-[4/3] place-items-center rounded-xl bg-neutral-500/7">
                    <span aria-hidden="true" className="grid size-9 place-items-center rounded-full border border-white/70 bg-white/25 text-2xl font-light leading-none shadow-sm backdrop-blur-sm group-hover:bg-white/45">+</span>
                  </span>
                  <span className="mt-3 block text-sm font-semibold">Create new</span>
                </button> : <form onSubmit={addFolder} className="grid gap-2">
                  <input autoFocus aria-label="New folder name" placeholder="Folder name" value={newFolderName} maxLength={40}
                    onChange={event => { setNewFolderName(event.target.value); setListError('') }}
                    className="min-h-9 min-w-0 rounded-lg border border-[#657568]/25 bg-white/50 px-2 text-sm outline-[#4F7A66]" />
                  <button type="submit" className="min-h-9 rounded-lg bg-[#4F7A66] px-1 text-xs font-semibold text-white">Create</button>
                  <button type="button" onClick={() => { setNewFolderName(null); setListError('') }} className="min-h-9 rounded-lg text-xs text-[#354D40]">Cancel</button>
                </form>}
                </div></div>
              </li>
            </ul>
          </> : view === 'Completed' ? completedContent : <ul className="w-full min-w-0 divide-y divide-[#4F7A66]/20 px-3">
            {repeatingTasks.length === 0 && <li className="py-3 text-center text-sm">No reocurring tasks yet.</li>}
            {repeatingTasks.filter(task => !editor || task.id === editor).map(task => {
              const rowId = `${settingsId}-repeat-${task.id}`
              if (editor === task.id) {
                return <li key={task.id} className="min-w-0">{renderRepeatingEditor(task, collapseEditor, setRepeatingOverlay)}</li>
              }
              const colorName = Object.keys(applePalette).find(name => applePalette[name] === taskAppleColor(task))
              const summary = `${task.list || 'Inbox'} · ${repeatSummary(task)}`
              return <li key={task.id}>
                <button id={leaving ? undefined : rowId} type="button" aria-expanded="false" onClick={event => openEditor(task.id, event)} className="flex min-h-14 w-full items-center gap-2 break-words px-2 py-2 text-left focus-visible:outline-2 focus-visible:outline-[#4F7A66]">
                  <span className="grid size-9 shrink-0 place-items-center"><TaskApple task={{ appleColor: colorName }} /><span className="sr-only">{colorName} apple</span></span>
                  <span className="min-w-0">
                    <span className="block px-2 text-sm font-semibold">{task.title}</span>
                    <span className="block px-2 text-xs leading-relaxed text-[#45443F]">{summary}</span>
                  </span>
                </button>
              </li>
            })}
          </ul>}
          </div>
        </div>
      </> : view ? <div className="pb-2">
        <h2 className="text-xl font-semibold">{view}</h2>
        <p className="my-4 text-[14px] leading-relaxed text-[#59554D]">{view === 'Information' ? 'Hedgy is a gentle space to plan your day, capture little thoughts, and take things one step at a time.' : 'No settings available yet.'}</p>
        <button type="button" onClick={() => navigate(null)} className="min-h-11 rounded-xl bg-[#4F7A66] px-4 text-sm font-medium text-[#F8F4E8] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4F7A66]">← Back to menu</button>
      </div> : <div className="task-scroll grid min-h-0 gap-4 overflow-y-auto overscroll-contain p-0.5">
        {menuItems.map(({ label, path, page: destination = label }) => {
          const isSettings = label === 'Settings'
          return <div key={label} className="rounded-2xl border border-white/50 bg-white/45 shadow-sm">
          <button type="button" aria-expanded={isSettings ? settingsExpanded : undefined} aria-controls={isSettings && !leaving ? settingsId : undefined} onClick={isSettings ? () => setSettingsExpanded(value => !value) : () => navigate(destination)} className="flex min-h-16 w-full items-center gap-2.5 rounded-2xl pl-3 pr-4 text-left text-base font-medium text-[#2E2A25] focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">
          <span aria-hidden="true" className="grid size-9 shrink-0 place-items-center rounded-full bg-[#4F7A66]/10 text-lg text-[#3D6653]">
            {path ? <svg viewBox="0 0 24 24" fill="none" className="size-[18px]"><path d={path} stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg> : 'i'}
          </span>
          <span className="flex-1">{label}</span>
          {isSettings && <svg aria-hidden="true" viewBox="0 0 16 16" fill="none" className={`size-4 shrink-0 text-[#3D6653] transition-[transform,opacity,rotate] duration-200 ease-in-out motion-reduce:transition-none ${settingsExpanded ? 'rotate-180 opacity-100' : 'opacity-0'}`}>
            <path d="m4 6 4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>}
          </button>
          {isSettings && <div id={leaving ? undefined : settingsId} inert={!settingsExpanded} className={`grid transition-[grid-template-rows,opacity] duration-200 ease-in-out motion-reduce:transition-none ${settingsExpanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
            <div className="min-h-0 overflow-hidden">
              <ul className="mx-4 mb-2 divide-y divide-[#4F7A66]/15 border-t border-[#4F7A66]/15">
                {settingsOptions.map(option => <li key={option}>
                  <button type="button" onClick={() => navigate(option)} className="min-h-11 w-full rounded-lg px-3 text-left text-sm font-medium text-[#545750] hover:bg-white/35 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[#4F7A66]">{option}</button>
                </li>)}
              </ul>
            </div>
          </div>}
          </div>
        })}
      </div>
  }
  const current = { page, editor: expandedTaskId, leaving: false }
  const layers = outgoing ? [{ ...outgoing, leaving: true }, current] : [current]
  const shift = `${(outgoing?.direction || 1) * 10}px`
  return <div role="dialog" aria-modal={!suspended && !repeatingOverlay && !closing} inert={suspended || repeatingOverlay} aria-hidden={suspended || repeatingOverlay || closing} aria-label={page?.folder || page || 'Menu'} tabIndex={-1} ref={dialog} onClick={event => { if (event.target === event.currentTarget) dismissSurface() }} onKeyDown={event => { if (event.key === 'Escape') dismissSurface() }} data-closing={closing || undefined} style={{ '--menu-sky': skyColor, '--menu-ground': groundColor, '--menu-ground-light': lightGroundColor }} className="menu-view-backdrop absolute inset-0 z-50 overflow-hidden outline-none">
    <div inert={closing || Boolean(folderToDelete)} data-task-view={Boolean(page?.folder) || page === 'Theme' || page === 'Cloud notes' || taskPages.has(page) || undefined} onClick={event => { if (expandedTaskId && event.target === event.currentTarget) collapseEditor() }} className="menu-scene-card planner-page-bounds absolute rounded-[28px] border border-white/30 px-3 py-4 shadow-xl backdrop-blur-md">
      <div className={`relative overflow-hidden ${outgoing ? 'menu-view-morph' : ''}`} style={{ height: contentHeight, '--menu-view-shift-x': outgoing?.vertical ? '0px' : shift, '--menu-view-shift-y': outgoing?.vertical ? shift : '0px' }}>
        {layers.map(({ page: view, editor, leaving }) => {
          return <div key={JSON.stringify([view, editor])} ref={leaving ? undefined : currentContent} inert={leaving} aria-hidden={leaving}
            className={`menu-view-content flex flex-col ${leaving ? 'menu-view-leaving pointer-events-none absolute inset-x-0 top-0' : outgoing ? 'menu-view-entering relative' : 'relative'}`}>
            {renderPage(view, editor, leaving)}
          </div>
        })}
      </div>
    </div>
    {folderToDelete && <div className="absolute inset-0 z-10 grid place-items-center bg-black/10 backdrop-blur-sm" onClick={event => {
      if (event.target === event.currentTarget) closeFolderDelete()
    }}>
      <section role="alertdialog" aria-modal="true" aria-labelledby={deleteTitleId} className="w-[84%] max-w-sm rounded-[28px] border border-white/70 bg-white/65 p-5 text-[#2E2A25] shadow-xl backdrop-blur-md">
        <h2 id={deleteTitleId} className="break-words text-base font-semibold">Delete “{folderToDelete.name.trim() || folderToDelete.originalName || 'New folder'}” folder?</h2>
        {folderToDelete.originalName && <p className="mt-2 text-sm text-neutral-600">When you save, these tasks will appear under No folder.</p>}
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button autoFocus type="button" onClick={() => closeFolderDelete()} className="min-h-11 rounded-xl border border-white/70 bg-white/50 text-sm focus-visible:outline-2 focus-visible:outline-neutral-500">Cancel</button>
          <button type="button" onClick={() => closeFolderDelete(true)} className="min-h-11 rounded-xl border border-[#8B5550]/25 bg-[#8B5550]/10 text-sm font-semibold text-[#783E38] focus-visible:outline-2 focus-visible:outline-[#783E38]">Yes</button>
        </div>
      </section>
    </div>}
  </div>
}
