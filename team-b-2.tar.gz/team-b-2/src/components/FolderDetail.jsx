import { useId, useState } from 'react'
import TaskApple from './TaskApple'
import { readFolderCover } from './FolderCard'

const actionStyle = 'min-h-10 w-full rounded-lg px-3 text-left text-sm text-neutral-700 hover:bg-white/70 focus-visible:outline-2 focus-visible:outline-neutral-500'

export default function FolderDetail({ name, cover, description, lists, tasks, onOpenPage, onSave }) {
  const [action, setAction] = useState(null)
  const [draft, setDraft] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [message, setMessage] = useState('')
  const actionsId = useId()
  const link = new URL(window.location.pathname, window.location.origin)
  link.searchParams.set('folder', name)
  const linkNote = 'This link opens the folder where it already exists. Folder contents stay in this browser.'

  async function copyLink() {
    setAction('link')
    setMessage('')
    try {
      await navigator.clipboard.writeText(link.href)
      setMessage('Link copied.')
    } catch {
      setMessage('Select and copy the link below.')
    }
  }

  async function uploadCover(file) {
    setUploading(true)
    setMessage('')
    try {
      const image = await readFolderCover(file)
      setDraft(previous => ({ ...previous, cover: image }))
    } catch {
      setMessage('Could not open this photo.')
    } finally {
      setUploading(false)
    }
  }

  function save(event) {
    event.preventDefault()
    const error = onSave({ ...draft, name: draft.name.trim(), description: draft.description.trim() })
    if (error) { setMessage(error); return }
    setDraft(null)
    setAction(null)
    setMessage('')
  }

  const pages = lists.length ? [{ id: 'folder-all', title: 'All' }, ...lists] : []
  return <>
    <div className="relative isolate flex min-h-32 items-end overflow-hidden rounded-2xl bg-[#6C756B] px-4 pb-4 pt-8">
      {cover && <img src={cover} alt="" className="absolute inset-0 -z-20 h-full w-full object-cover" />}
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-linear-to-t from-black/75 via-black/25 to-transparent" />
      <span className="mr-2 grid size-9 shrink-0 place-items-center rounded-full bg-black/30"><TaskApple task={{ appleColor: 'Green' }} size={21} /></span>
      <h2 className="min-w-0 self-end pb-1 text-xl font-semibold wrap-anywhere text-white">{name}</h2>
    </div>
    <div className="relative mt-2 flex items-start justify-between gap-2">
      <p className={`min-w-0 whitespace-pre-wrap wrap-anywhere px-1 py-3 text-sm ${description ? 'text-neutral-700' : 'text-neutral-500'}`}>{description || 'No description yet'}</p>
      <button type="button" aria-label="Folder options" aria-expanded={action === 'menu'} aria-controls={action === 'menu' ? actionsId : undefined}
        onClick={() => { setAction(action === 'menu' ? null : 'menu'); setDraft(null); setMessage('') }} disabled={uploading}
        className="grid size-11 shrink-0 place-items-center rounded-xl text-sm tracking-widest text-neutral-600 hover:bg-white/50 focus-visible:outline-2 focus-visible:outline-neutral-500">•••</button>
    </div>
    {action === 'menu' && <div id={actionsId} className="relative z-10 mb-2 ml-auto w-44 rounded-xl border border-white/85 bg-[#F4F4F3]/95 p-1 shadow-lg backdrop-blur-md">
        <button type="button" className={actionStyle} onClick={() => setAction('invite')}>Invite friends</button>
        <button type="button" className={actionStyle} onClick={copyLink}>Share / copy link</button>
        <button type="button" className={actionStyle} onClick={() => { setDraft({ name, description: description || '', cover }); setAction('edit') }}>Edit folder details</button>
    </div>}
    {(action === 'invite' || action === 'link') && <div className="mb-3 space-y-2 rounded-xl border border-white/70 bg-white/50 p-3 text-xs text-neutral-700">
      <p>{linkNote}</p>
      {action === 'invite' && <a href={`mailto:?subject=${encodeURIComponent(name)}&body=${encodeURIComponent(`${link.href}\n\n${linkNote}`)}`} className="inline-flex min-h-9 items-center underline underline-offset-2">Open email invitation</a>}
      {message && <p role="status">{message}</p>}
      <input aria-label="Folder link" readOnly value={link.href} onFocus={event => event.target.select()} className="w-full rounded-lg border border-neutral-400/30 px-2 py-1" />
    </div>}
    {draft && <form onSubmit={save} className="mb-3 grid gap-2 rounded-xl border border-white/70 bg-white/50 p-3 text-sm text-neutral-700">
      <label className="grid gap-1">Folder name<input maxLength={40} value={draft.name} onChange={event => setDraft({ ...draft, name: event.target.value })} className="rounded-lg border border-neutral-400/30 px-2 py-1" /></label>
      <label className="grid gap-1">Description<textarea rows={2} maxLength={500} value={draft.description} onChange={event => setDraft({ ...draft, description: event.target.value })} className="rounded-lg border border-neutral-400/30 px-2 py-1" /></label>
      <label className="relative flex min-h-10 w-fit items-center rounded-lg px-2 underline underline-offset-2 has-focus-visible:outline-2">
        {uploading ? 'Preparing cover…' : 'Choose cover photo'}
        <input type="file" accept="image/*" aria-label="Choose cover photo" disabled={uploading} className="absolute inset-0 w-full cursor-pointer opacity-0" onChange={event => {
          const file = event.target.files?.[0]
          if (file) uploadCover(file)
        }} />
      </label>
      {message && <p role="alert" className="text-xs text-[#783E38]">{message}</p>}
      <div className="grid grid-cols-2 gap-2">
        <button type="button" disabled={uploading} className="min-h-10 rounded-lg border border-white/80" onClick={() => { setDraft(null); setAction(null); setMessage('') }}>Cancel</button>
        <button type="submit" disabled={uploading} className="min-h-10 rounded-lg bg-[#4F7A66] font-semibold text-white">Save</button>
      </div>
    </form>}
    {pages.length ? <ul className="grid gap-2 py-1">
      {pages.map(({ id, title }) => {
        const count = new Set(tasks.filter(task => id === 'folder-all' || task.folderListId === id).map(task => task.id)).size
        return <li key={id}><button type="button" onClick={() => onOpenPage(id)} className="flex min-h-12 w-full items-center justify-between gap-2 rounded-xl border border-white/70 bg-white/45 px-3 py-2 text-left text-sm text-neutral-700 hover:bg-white/70 focus-visible:outline-2 focus-visible:outline-neutral-500">
          <span className="min-w-0 wrap-anywhere font-semibold">{title}</span><span className="shrink-0 text-xs text-neutral-600">{count} ongoing {count === 1 ? 'task' : 'tasks'}</span>
        </button></li>
      })}
    </ul> : <p className="px-2 py-8 text-center text-sm text-neutral-500">Your folder lists will appear here</p>}
  </>
}
