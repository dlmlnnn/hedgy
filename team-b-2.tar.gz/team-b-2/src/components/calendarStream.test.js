import test from 'node:test'
import assert from 'node:assert/strict'
import { calendarMonths, visibleCalendarMonth } from './calendarStream.js'

test('scrolling continues across month and year boundaries with no end padding', () => {
  const months = calendarMonths(2026 * 12 + 11, 3)
  assert.deepEqual(months.map(month => [month.year, month.month]), [[2026, 11], [2027, 0], [2027, 1]])
  assert.equal(months[0].days.at(-1).getDate(), 31)
  assert.equal(months[1].days[0].getDate(), 1)
  assert.equal(months[1].offset, months[0].height)
  assert.equal(visibleCalendarMonth(months, months[1].offset + 16).month, 0)
  assert.equal(visibleCalendarMonth(months, months[1].offset + 15).month, 11)
})

test('appending another year preserves every existing month offset', () => {
  const initial = calendarMonths(2026 * 12 + 9, 12)
  const extended = calendarMonths(2026 * 12 + 9, 24)
  assert.deepEqual(extended.slice(0, 12), initial)
  assert.equal(visibleCalendarMonth(extended, initial[3].offset + 150).serial, initial[3].serial)
})

test('leap-year February contains all 29 dates', () => {
  const [month] = calendarMonths(2028 * 12 + 1, 1)
  assert.equal(month.days.length, 29)
  assert.equal(month.leading, 1)
  assert.equal(month.height, 32 + 5 * 36)
  assert.equal(month.days.at(-1).getDate(), 29)
})
