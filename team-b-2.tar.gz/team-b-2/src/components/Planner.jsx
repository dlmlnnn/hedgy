import { useEffect, useRef, useState } from 'react'
import PlannerScene from './PlannerScene'
import SkyBird from './SkyBird'
import WipeableClouds from './WipeableClouds'
import TreeLeaves from './TreeLeaves'
import PlannerCalendarButton from './PlannerCalendarButton'
import PlannerFolderBadge from './PlannerFolderBadge'
import CreateFolderList from './CreateFolderList'
import FolderListTitleEditor from './FolderListTitleEditor'
import { taskAppleColor } from './TaskApple'
import UnifiedTaskForm from './UnifiedTaskForm'
import RepeatingTaskEditor from './RepeatingTaskEditor'
import Calendar from './Calendar'
import { dateKey } from './calendarDates'
import { appliesOn, completedThisMonth, deleteOccurrence, unfinishedItems, itemsForDate, plannerItemsForToday, toggleItem, toggleGoalStep } from './taskSchedule'
import PlannerTree from './PlannerTree'
import { freshTree, migrateTree, rewardCompletion } from './treeProgress'
import TaskDetail from './TaskDetail'
import PanelPager from './PanelPager'
import TaskRows from './TaskRows'
import DeleteTaskDialog from './DeleteTaskDialog'
import { normalizeTask, expandTaskDates, isRecurringTask, isOverdue } from './taskModel'
import { migrateGoalDates } from './calendarSelection'
import { estoniaDaylight } from './estoniaDaylight'
import CalendarEventCard from './CalendarEventCard'
import AppleCollection from './AppleCollection'
import SettingsDialog from './SettingsDialog'
import { anchorPosition, appleAnchorPercentages, appleAssignmentKey, appleItemKey, appleLandingLane, loadAppleAssignments, reconcileAppleAssignments, treeItemsForToday } from './treeAppleLayout'

const tasksKey = 'team-b-2:tasks'
const treeKey = 'team-b-2:treeGrowth'
const listsKey = 'team-b-2:taskLists'
const folderListsKey = 'team-b-2:folderLists'
const folderCoversKey = 'team-b-2:folderCovers'
const folderDescriptionsKey = 'team-b-2:folderDescriptions'
const cloudModeKey = 'team-b-2:cloudMode'
function loadCloudMode() {
  try {
    const mode = localStorage.getItem(cloudModeKey)
    if (mode === 'scratch' || mode === 'notes') return mode
  } catch { /* Storage is optional. */ }
  return 'classic'
}
function loadFolderMetadata(key) {
  try { return new Map(JSON.parse(localStorage.getItem(key) || '[]')) } catch { return new Map() }
}
function loadFolderLists() {
  try {
    const data = JSON.parse(localStorage.getItem(folderListsKey) || '[]')
    return Array.isArray(data) ? data.filter(item => item && typeof item.folder === 'string' && typeof item.id === 'string' && typeof item.title === 'string') : []
  } catch { return [] }
}
function loadLists() {
  try {
    const data = JSON.parse(localStorage.getItem(listsKey) || '[]')
    return Array.isArray(data) ? data.filter(name => typeof name === 'string' && name.trim()) : []
  } catch { return [] }
}
function loadTasks() {
  try {
    const data = JSON.parse(localStorage.getItem(tasksKey) || '[]')
    return Array.isArray(data) ? data.filter(item => item && typeof item.id === 'string' && typeof item.title === 'string').map(item => normalizeTask(migrateGoalDates(item))) : []
  } catch { return [] }
}
function loadTree() {
  try { return migrateTree(JSON.parse(localStorage.getItem(treeKey))) } catch { return freshTree() }
}
export default function Planner({ theme, onThemeChange }) {
  const [cloudMode, setCloudMode] = useState(loadCloudMode)
  function changeCloudMode(mode) {
    setCloudMode(mode)
    try { localStorage.setItem(cloudModeKey, mode) } catch { /* Keep the selection in this session. */ }
  }
  const [today, setToday] = useState(() => new Date())
  const [tasks, setTasks] = useState(loadTasks)
  const [savedLists, setSavedLists] = useState(loadLists)
  const [activeFolder, setActiveFolder] = useState('')
  const [folderLists, setFolderLists] = useState(loadFolderLists)
  const [requestedPage, setRequestedPage] = useState(null)
  const [editingFolderListId, setEditingFolderListId] = useState(null)
  const [addToListId, setAddToListId] = useState(undefined)
  const lists = [...new Set([...savedLists, ...tasks.map(task => task.list).filter(Boolean)])]
  const [tree, setTree] = useState(loadTree)
  const [pulse, setPulse] = useState(0)
  const [birdVisit, setBirdVisit] = useState(0)
  const [collections, setCollections] = useState([])
  const collectionsRef = useRef([])
  const [appleAssignments, setAppleAssignments] = useState(loadAppleAssignments)
  const [goalHighlights, setGoalHighlights] = useState({})
  const highlightTimers = useRef(new Map())
  useEffect(() => () => highlightTimers.current.forEach(clearTimeout), [])
  const [adding, setAdding] = useState(false)
  const [calendarOpen, setCalendarOpen] = useState(false)
  const [detail, setDetail] = useState(null)
  const [inlineDetailOverlay, setInlineDetailOverlay] = useState(false)
  const [eventTask, setEventTask] = useState(null)
  const [deleting, setDeleting] = useState(null)
  const [toast, setToast] = useState('')
  const [linkedFolder, setLinkedFolder] = useState(() => new URLSearchParams(window.location.search).get('folder'))
  const [menuPhase, setMenuPhase] = useState(() => linkedFolder ? 'open' : null)
  const [folderCovers, setFolderCovers] = useState(() => loadFolderMetadata(folderCoversKey))
  const [folderDescriptions, setFolderDescriptions] = useState(() => loadFolderMetadata(folderDescriptionsKey))
  const menuButton = useRef(null)
  const menuCloseTimer = useRef(null)
  useEffect(() => () => clearTimeout(menuCloseTimer.current), [])
  const tasksRef = useRef(tasks)
  const treeRef = useRef(tree)
  const addButton = useRef(null)
  const taskDetailTrigger = useRef(null)
  const calendarButton = useRef(null)
  const currentDay = dateKey(today)
  useEffect(() => {
    const now = new Date()
    const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1)
    const timer = setTimeout(() => setToday(new Date()), midnight - now + 10)
    return () => clearTimeout(timer)
  }, [currentDay])
  tasksRef.current = tasks
  treeRef.current = tree
  useEffect(() => { try { localStorage.setItem(tasksKey, JSON.stringify(tasks)) } catch { /* In-memory fallback. */ } }, [tasks])
  useEffect(() => { try { localStorage.setItem(listsKey, JSON.stringify(savedLists)) } catch { /* In-memory fallback. */ } }, [savedLists])
  useEffect(() => { try { localStorage.setItem(folderListsKey, JSON.stringify(folderLists)) } catch { /* In-memory fallback. */ } }, [folderLists])
  useEffect(() => { try { localStorage.setItem(folderDescriptionsKey, JSON.stringify([...folderDescriptions])) } catch { /* In-memory fallback. */ } }, [folderDescriptions])
  useEffect(() => { try { localStorage.setItem(treeKey, JSON.stringify(tree)) } catch { /* In-memory fallback. */ } }, [tree])
  useEffect(() => {
    const refresh = () => setToday(new Date())
    const interval = setInterval(refresh, 30000)
    window.addEventListener('focus', refresh)
    document.addEventListener('visibilitychange', refresh)
    return () => { clearInterval(interval); window.removeEventListener('focus', refresh); document.removeEventListener('visibilitychange', refresh) }
  }, [])
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(''), 2000); return () => clearTimeout(timer) }, [toast])
  function updateTasks(update) { const next = update(tasksRef.current); tasksRef.current = next; setTasks(next) }
  const unfinished = unfinishedItems(tasks, currentDay)
  const todaysItems = plannerItemsForToday(unfinished, currentDay)
  const completed = completedThisMonth(tasks, today)
  const repeatingTasks = tasks.filter(task => {
    if (!isRecurringTask(task)) return false
    if (task.cadence !== 'dates' && ['schedule', 'daily', 'weekdays'].includes(task.rule)) return true
    return [...(task.dates || []), ...(task.restoredDates || [])].some(date => date >= currentDay && appliesOn(task, date) && !task.completedDates?.includes(date))
  })
  const treeItems = treeItemsForToday(todaysItems, currentDay, tasks)
  const assigned = reconcileAppleAssignments(appleAssignments, treeItems, collections.filter(event => !event.landed).map(event => event.anchorIndex))
  const visibleApples = treeItems.filter(item => Object.hasOwn(assigned, appleItemKey(item)))
  const assignmentJSON = JSON.stringify(assigned)
  useEffect(() => {
    const next = JSON.parse(assignmentJSON)
    setAppleAssignments(previous => JSON.stringify(previous) === assignmentJSON ? previous : next)
    try { localStorage.setItem(appleAssignmentKey, assignmentJSON) } catch { /* Keep anchors stable in memory. */ }
  }, [assignmentJSON])
  const dailyTree = { ...tree, applesOnTree: visibleApples.length, appleColors: visibleApples.map(taskAppleColor), appleHighlights: visibleApples.map(item => goalHighlights[item.id]), appleOverdue: visibleApples.map(item => isOverdue(item, today)), appleKeys: visibleApples.map(appleItemKey), applePositions: visibleApples.map(item => anchorPosition(assigned[appleItemKey(item)])) }
  function updateCollections(update) {
    const next = update(collectionsRef.current)
    collectionsRef.current = next
    setCollections(next)
  }
  function collect(item, creditId = item.id, shouldFall = true) {
    const next = rewardCompletion(treeRef.current, { id: creditId, date: item.date, once: !isRecurringTask(item) })
    treeRef.current = next; setTree(next); setPulse(value => value + 1)
    if (!shouldFall) return
    return queueAppleFall(item, creditId)
  }
  function queueAppleFall(item, creditId = item.id, kind = 'collection') {
    const apple = visibleApples.find(apple => apple.id === creditId && (!isRecurringTask(item) || apple.date === item.date))
    if (!apple) return
    const anchorIndex = assigned[appleItemKey(apple)]
    const [px, py] = appleAnchorPercentages[anchorIndex]
    const element = document.querySelector('.planner-tree')
    const frame = element?.closest('.planner')?.getBoundingClientRect()
    const rect = element?.getBoundingClientRect()
    const header = element?.closest('.planner')?.querySelector('.planner-scene')?.getBoundingClientRect()
    if (!frame || !rect || !header?.height) return
    const startX = (rect.left - frame.left + rect.width * px / 100) * 393 / frame.width
    const startY = (rect.top - frame.top + rect.height * py / 100) * 250 / (header.height)
    const lane = appleLandingLane(startX, collectionsRef.current)
    updateCollections(queue => [...queue, { id: crypto.randomUUID(), kind, message: kind === 'goal-final' ? (Math.random() < .5 ? 'well done' : 'bravo') : undefined, anchorIndex, startX, startY, landY: 238 - lane * 12, lane, color: taskAppleColor(item) }])
    return true
  }
  function highlightGoal(id) {
    clearTimeout(highlightTimers.current.get(id))
    setGoalHighlights(previous => ({ ...previous, [id]: crypto.randomUUID() }))
    highlightTimers.current.set(id, setTimeout(() => {
      setGoalHighlights(previous => { const next = { ...previous }; delete next[id]; return next })
      highlightTimers.current.delete(id)
    }, 3000))
  }
  function visitGoal() {
    updateCollections(queue => [...queue, { id: crypto.randomUUID(), kind: 'visit', message: Math.random() < .5 ? 'well done' : 'bravo', startX: 100, startY: 200, landY: 238 }])
  }
  function completeTask(id, date) {
    const base = tasksRef.current.find(item => item.id === id)
    if (!base) return
    const item = base.type === 'goal' ? { ...base, date, completed: base.completed || base.completedDates?.includes(date) } : isRecurringTask(base) ? base.completedDates?.includes(date) ? { ...base, date, completed: true } : itemsForDate([base], date)[0] : { ...base, date }
    if (!item) return
    if (!item.completed) {
      collect(item, id, base.type !== 'goal')
      if (base.type === 'goal') highlightGoal(id)
    }
    updateTasks(items => toggleItem(items, id, date))
  }
  function toggleStep(item, step) {
    const base = tasksRef.current.find(task => task.id === item.id)
    if (!base) return
    const next = toggleGoalStep(tasksRef.current, item.id, step.id)
    const finished = next.find(task => task.id === item.id)
    if (!step.completed) {
      collect({ ...base, date: step.endDate }, step.id, false)
      if (!base.completed && finished.completed) {
        if (!queueAppleFall(base, base.id, 'goal-final')) visitGoal()
      } else visitGoal()
    }
    updateTasks(() => next)
  }
  function saveTask(fields) {
    if (tasksRef.current.some(task => task.id === fields.id)) return
    const { scheduledDates, usesRecurrence, monthPattern, ...task } = fields
    const dates = [...new Set(scheduledDates || [])].sort()
    const schedule = dates.length > 1 || (usesRecurrence && dates.length > 0)
      ? { type: 'commitment', rule: 'schedule', cadence: 'dates', dates, date: dates[0], startDate: dates[0] }
      : {}
    const list = rememberList(fields.list)
    const folderListId = folderLists.some(entry => entry.folder === list && entry.id === task.folderListId) ? task.folderListId : undefined
    const item = normalizeTask({ ...task, ...schedule, list, folderListId, done: false, completed: false, completedAt: null })
    updateTasks(items => [...items, item])
    closeAdd(); setToast('Task added')
  }
  function closeAdd() {
    setAdding(false)
    requestAnimationFrame(() => addButton.current?.focus({ preventScroll: true }))
  }
  function rememberList(value = '') {
    const name = value.trim()
    if (!name || name.toLowerCase() === 'inbox') return ''
    const existing = lists.find(list => list.toLowerCase() === name.toLowerCase()) || name
    setSavedLists(previous => previous.includes(existing) ? previous : [...previous, existing])
    return existing
  }
  function saveFolders(folders) {
    const names = folders.map(folder => folder.name)
    const entries = folders.flatMap(({ name, cover }) => cover ? [[name, cover]] : [])
    if (entries.length !== folderCovers.size || entries.some(([name, cover]) => folderCovers.get(name) !== cover)) {
      try {
        localStorage.setItem(folderCoversKey, JSON.stringify(entries))
      } catch {
        return 'Could not save these covers in this browser. Try removing a cover or choosing a smaller photo.'
      }
      setFolderCovers(new Map(entries))
    }
    setFolderDescriptions(previous => new Map(folders.flatMap(({ originalName, name, description }) => {
      const value = description ?? previous.get(originalName)
      return value ? [[name, value]] : []
    })))
    if (lists.length === names.length && lists.every((name, index) => name === names[index]) &&
      folders.every(({ originalName, name }) => originalName === name)) return
    const renamed = new Map(folders.filter(({ originalName, name }) => originalName && originalName !== name)
      .map(({ originalName, name }) => [originalName, name]))
    const retained = new Set(folders.map(folder => folder.originalName))
    const removed = new Set(lists.filter(name => !retained.has(name)))
    setSavedLists(names)
    if (!renamed.size && !removed.size) return
    setActiveFolder(folder => removed.has(folder) ? '' : renamed.get(folder) ?? folder)
    setFolderLists(previous => previous.filter(entry => !removed.has(entry.folder))
      .map(entry => ({ ...entry, folder: renamed.get(entry.folder) ?? entry.folder })))
    updateTasks(items => items.map(task => {
      if (removed.has(task.list)) return { ...task, list: '', folderListId: undefined }
      return renamed.has(task.list) ? { ...task, list: renamed.get(task.list) } : task
    }))
  }
  function saveFolderDetail(originalName, details) {
    const name = details.name.trim()
    if (!name) return 'Enter a folder name.'
    if (name.toLowerCase() === 'inbox' || lists.some(folder => folder !== originalName && folder.toLowerCase() === name.toLowerCase())) {
      return 'Choose a different folder name.'
    }
    return saveFolders(lists.map(folder => folder === originalName
      ? { ...details, name, originalName }
      : { name: folder, originalName: folder, cover: folderCovers.get(folder) }))
  }
  function listTitleError(title, exceptId) {
    if (!title) return 'Enter a list title.'
    if (title.toLowerCase() === 'all' || folderLists.some(entry => entry.id !== exceptId && entry.folder === activeFolder && entry.title.toLowerCase() === title.toLowerCase())) return 'Choose a different list title.'
    return ''
  }
  function createFolderList(title) {
    const error = listTitleError(title)
    if (error) return error
    const id = crypto.randomUUID()
    setFolderLists(previous => [...previous, { folder: activeFolder, id, title }])
    setRequestedPage(id)
    return ''
  }
  function closeFolderList() {
    setEditingFolderListId(null)
    requestAnimationFrame(() => document.querySelector('[data-stack-depth="0"] [data-folder-title]')?.focus({ preventScroll: true }))
  }
  function renameFolderList(title) {
    const error = listTitleError(title, editingFolderListId)
    if (error) return error
    setFolderLists(previous => previous.map(entry => entry.id === editingFolderListId ? { ...entry, title } : entry))
    closeFolderList()
    return ''
  }
  function deleteFolderList() {
    setFolderLists(previous => previous.filter(entry => entry.id !== editingFolderListId))
    updateTasks(items => items.map(task => task.folderListId === editingFolderListId ? { ...task, folderListId: undefined } : task))
    setRequestedPage(null)
    closeFolderList()
  }
  function edit(item, event, inline = false) {
    taskDetailTrigger.current = event?.currentTarget
    setDetail(previous => inline && previous?.inline && previous.id === item.id && previous.date === item.date ? null : { id: item.id, date: item.date, inline })
  }
  function removeItem(item, whole) {
    updateTasks(items => whole || !isRecurringTask(item) ? items.filter(task => task.id !== item.id) : deleteOccurrence(items, item.id, item.date))
    setDeleting(null); setDetail(null); setToast('Deleted')
  }
  function saveEdit(updated) {
    const list = rememberList(updated.list)
    updateTasks(items => items.flatMap(item => item.id === updated.id
      ? expandTaskDates({ ...item, ...updated, list, folderListId: list === item.list ? item.folderListId : undefined })
      : [item]))
    setDetail(null); setToast('Saved')
  }
  const detailTask = detail && tasks.find(item => item.id === detail.id)
  const separateDetail = Boolean(detailTask && !detail.inline)
  const daylight = estoniaDaylight(today, theme)
  const modalOpen = adding || Boolean(menuPhase) || calendarOpen || separateDetail || inlineDetailOverlay || Boolean(eventTask) || Boolean(deleting)
  function closeMenu() {
    if (menuPhase !== 'open') return
    function finish() {
      setMenuPhase(null)
      setLinkedFolder(null)
      requestAnimationFrame(() => menuButton.current?.focus({ preventScroll: true }))
    }
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) finish()
    else {
      setMenuPhase('closing')
      menuCloseTimer.current = setTimeout(finish, 320)
    }
  }
  const rowProps = { onEdit: edit, onComplete: item => completeTask(item.id, item.type === 'goal' && !item.completed ? currentDay : item.date), onShare: setEventTask, onStep: toggleStep, onDelete: setDeleting }
  function renderTaskDetail(inline, item) {
    const task = inline ? tasks.find(candidate => candidate.id === item.id) || item : detailTask
    const date = inline ? item.date : detail.date
    return <TaskDetail task={task} lists={lists} occurrenceDate={date} inline={inline} onOverlayChange={inline ? setInlineDetailOverlay : undefined}
      onClose={() => { setDetail(null); requestAnimationFrame(() => taskDetailTrigger.current?.focus({ preventScroll: true })) }}
      onDelete={whole => removeItem({ ...task, date }, whole)} onSave={saveEdit}
      onCalendarOptions={task.date ? () => { setEventTask({ ...task, date: date || task.date }); setDetail(null) } : undefined} />
  }
  const plannerRowProps = {
    ...rowProps,
    onEdit: (item, event) => edit(item, event, true),
    detailKey: detail?.inline && detailTask ? `${detail.id}@${detail.date}` : undefined,
    renderDetail: item => renderTaskDetail(true, item),
  }
  const dayPages = Array.from({ length: 8 }, (_, offset) => offset).flatMap(offset => {
    const day = new Date(today)
    day.setDate(day.getDate() + offset)
    const date = dateKey(day)
    const dayItems = offset === 0
      ? todaysItems.filter(item => item.date === date)
      : itemsForDate(tasks, date).filter(item => !item.completed).sort((a, b) => (a.time || '').localeCompare(b.time || ''))
    const items = dayItems.filter(item => !item.list)
    if (!items.length) return []
    return [{
      id: `day:${offset}`,
      name: offset === 0 ? 'Today' : offset === 1 ? 'Tomorrow' : `In ${offset} days`,
      content: <TaskRows items={items} {...plannerRowProps} onComplete={item => completeTask(item.id, date)} />,
    }]
  })
  const folderItems = activeFolder ? unfinished.filter(item => item.list === activeFolder) : []
  const folderRows = items => <TaskRows items={items} {...plannerRowProps} onComplete={item => completeTask(item.id, item.date)} />
  const plannerPages = activeFolder ? [
    { id: 'folder-all', name: 'All', content: folderRows(folderItems) },
    ...folderLists.filter(entry => entry.folder === activeFolder).map(entry => ({
      id: entry.id, name: entry.title, folderListId: entry.id,
      onEditTitle: () => setEditingFolderListId(entry.id),
      titleEditor: editingFolderListId === entry.id ? <FolderListTitleEditor list={entry} onClose={closeFolderList} onRename={renameFolderList} onDelete={deleteFolderList} /> : null,
      content: folderRows(folderItems.filter(item => item.folderListId === entry.id)),
    })),
    { id: 'folder-create', name: 'Create a list', placeholder: true, content: <CreateFolderList onCreate={createFolderList} /> },
  ] : dayPages
  return <section className="planner absolute inset-0" style={{ background: `linear-gradient(to bottom, ${daylight.sky} 0%, ${daylight.horizon} 17%, ${daylight.ground} var(--planner-header-height), ${daylight.lower} 100%)` }} aria-label="Daily planner">
    <div className="absolute inset-0" inert={modalOpen} aria-hidden={modalOpen}>
      <h1 className="sr-only">Your daily planner</h1>
      <PlannerScene daylight={daylight} />
      <WipeableClouds mode={cloudMode} daylight={daylight} />
      <button ref={menuButton} type="button" aria-label="Settings" onClick={() => setMenuPhase('open')} className="absolute right-2 top-2 flex h-11 w-11 items-center justify-center rounded-full text-[#2E2A25] transition active:scale-95"><svg aria-hidden="true" width="22" height="18" viewBox="0 0 22 18" fill="none"><path d="M1 2h20M1 9h20M1 16h20" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" /></svg></button>
      <PlannerTree tree={dailyTree} pulse={pulse} tapPulse={birdVisit} />
      <TreeLeaves tap={birdVisit} />
      <SkyBird perchRequest={birdVisit} />
      <button type="button" aria-label="Invite a bird to the tree" onClick={() => setBirdVisit(value => value + 1)} className="planner-tree-bounds absolute rounded-full bg-transparent focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6E9A82]" />
      {new URLSearchParams(window.location.search).get('demoGrowth') === '1' && <div className="absolute right-4 top-[195px] flex gap-2">{[1,5].map(count => <button key={count} onClick={() => updateTasks(items => [...items, ...Array.from({ length: count }, (_, index) => normalizeTask({ id: crypto.randomUUID(), type: 'quick', title: `A little task ${index + 1}`, date: currentDay, done: false }))])} className="min-h-7 rounded-full bg-[#F8F4E8]/40 px-2 text-[10px]">+{count} task{count > 1 ? 's' : ''}</button>)}</div>}
      <PanelPager key={JSON.stringify(activeFolder)} requestedPage={requestedPage} slideAway={menuPhase === 'open'} calendarButton={<PlannerCalendarButton today={today} buttonRef={calendarButton} onOpen={() => setCalendarOpen(true)} />}
        folderBadge={<PlannerFolderBadge folders={lists} value={activeFolder} onChange={folder => { setRequestedPage(null); setActiveFolder(folder) }} />} pages={plannerPages}
        addButton={folderListId => <button type="button" onClick={event => { addButton.current = event.currentTarget; setAddToListId(folderListId); setAdding(true) }} aria-label="Add a task" className="absolute bottom-4 right-4 flex h-[46.08px] w-[46.08px] items-center justify-center rounded-full bg-[#3D6653] text-[27.84px] font-normal leading-none text-white shadow-[0_4px_12px_rgba(70,50,30,0.12)] transition active:scale-95 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#4F7A66]">+</button>} />
      {collections.map(event => <AppleCollection key={event.id} event={event} onLanded={() => updateCollections(previous => previous.map(item => item.id === event.id ? { ...item, landed: true } : item))} onFinished={() => updateCollections(previous => previous.filter(item => item.id !== event.id))} />)}
    </div>
    {menuPhase && <SettingsDialog closing={menuPhase === 'closing'} skyColor={daylight.sky} groundColor={daylight.ground} lightGroundColor={daylight.lower} onClose={closeMenu} suspended={Boolean(separateDetail || deleting || eventTask)} completedContent={<TaskRows items={completed} {...rowProps} completed embedded />} repeatingTasks={repeatingTasks} lists={lists} folderCovers={folderCovers} onSaveFolders={saveFolders}
      theme={theme} onThemeChange={onThemeChange} cloudMode={cloudMode} onCloudModeChange={changeCloudMode} linkedFolder={linkedFolder} folderDescriptions={folderDescriptions} folderLists={folderLists} folderTasks={unfinished} onSaveFolderDetail={saveFolderDetail}
      onOpenFolderPage={(folder, pageId) => { setActiveFolder(folder); setRequestedPage(pageId); closeMenu() }}
      renderRepeatingEditor={(task, collapse, setOverlay) => <RepeatingTaskEditor task={task} lists={lists} today={currentDay} onCreateList={rememberList} onOverlayChange={setOverlay} onClose={collapse}
        onDelete={() => { removeItem(task, true); collapse() }} onSave={updated => { saveEdit(updated); collapse() }} />} />}
    {adding && <UnifiedTaskForm lists={lists} initialFolder={activeFolder} initialFolderListId={addToListId} onSave={saveTask} onClose={closeAdd} onCreateList={rememberList} triggerRef={addButton} />}
    {calendarOpen && <Calendar tasks={tasks} lists={lists} onToggle={completeTask} onDeleteItem={(id, date, whole) => { const item = tasksRef.current.find(task => task.id === id); if (item) removeItem({ ...item, date }, whole) }} onSaveItem={saveEdit} onStep={toggleStep} onClose={() => setCalendarOpen(false)} triggerRef={calendarButton} />}
    {separateDetail && renderTaskDetail(false)}
    {deleting && <DeleteTaskDialog task={deleting} onClose={() => setDeleting(null)} onDelete={whole => removeItem(deleting, whole)} />}
    {eventTask && <CalendarEventCard task={eventTask} onClose={() => setEventTask(null)} />}
    {toast && <div role="status" className="pointer-events-none absolute bottom-7 left-1/2 z-[80] w-max max-w-[90%] -translate-x-1/2 rounded-full bg-[#4F7A66] px-5 py-3 text-center text-[13px] font-semibold text-[#F8F4E8]">{toast}</div>}
  </section>
}
