import { useRef, useState } from 'react'
import TaskFields from './TaskFields'
import { isRecurringTask, normalizeTask, validateTask } from './taskModel'
import useVisibleViewport from './useVisibleViewport'
import TaskListField, { taskFieldClass } from './TaskListField'
import TaskApple, { applePalette, taskAppleColor } from './TaskApple'

export default function TaskEditor({ task, lists, onSave, onClose, onDelete, onShare }) {
  const [draft, setDraft] = useState(() => {
    const item = normalizeTask(task)
    if (item.type === 'habit' && item.rule !== 'schedule') {
      if (!['daily', 'weekdays'].includes(item.rule) && item.dates?.length) return { ...item, rule: 'schedule', cadence: 'dates', startDate: item.startDate || item.dates[0] }
      return { ...item, rule: 'schedule', weekdays: item.rule === 'daily' ? [1,2,3,4,5,6,7] : item.weekdays || [], months: item.months || [1,2,3,4,5,6,7,8,9,10,11,12] }
    }
    return item
  })
  const [error, setError] = useState('')
  const dialog = useRef(null)
  const viewport = useVisibleViewport(dialog)
  const recurring = isRecurringTask(draft)
  const color = Object.keys(applePalette).find(name => applePalette[name] === taskAppleColor(draft))
  function save(event) {
    event.preventDefault()
    const steps = recurring ? draft.steps.map(step => ({ ...step, title: step.title.trim() })) : draft.steps
    const message = validateTask(draft) || (recurring && steps.some(step => !step.title) ? 'Enter a name for each step.' : '')
    setError(message)
    if (message) return
    onSave({
      ...draft, title: draft.title.trim(), steps,
      ...(draft.type === 'goal' ? { stepDates: (draft.stepDates || []).filter(date => date >= draft.startDate && date <= draft.deadline) } : {}),
      rule: ['habit', 'commitment'].includes(draft.type) ? 'schedule' : draft.rule,
    })
  }
  return <div ref={dialog} role="dialog" aria-modal="true" aria-label="Edit task" onKeyDown={event => { if (event.key === 'Escape') { event.stopPropagation(); onClose() } }} className="absolute inset-0 z-50 flex items-end justify-center pb-[6%] planner-modal-backdrop">
    <form style={viewport ? { position: 'absolute', top: viewport.top + 12, maxHeight: Math.max(100, viewport.height - 24) } : undefined} onSubmit={save} className="task-scroll flex max-h-[82%] w-[86%] flex-col gap-3 overflow-y-auto rounded-[28px] bg-[#F8F4E8] p-5 shadow-xl">
      <div className="sticky top-0 z-10 flex shrink-0 items-center justify-between gap-2 bg-(--surface)">
        <h2 className="font-sans text-xl font-semibold">Edit task</h2>
        <button type="button" aria-label="Close edit form without saving" onClick={onClose} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[24px] text-[#59554D] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">×</button>
      </div>
      <TaskFields draft={draft} onChange={setDraft} />
      {recurring && <label className="block text-sm font-semibold">Apple color
        <span className="flex items-center gap-2">
          <TaskApple task={{ appleColor: color }} />
          <select aria-label="Apple color" value={color} onChange={event => setDraft(previous => ({ ...previous, appleColor: event.target.value }))} className={taskFieldClass}>
            {Object.keys(applePalette).map(name => <option key={name}>{name}</option>)}
          </select>
        </span>
      </label>}
      <TaskListField lists={lists} value={draft.list} onChange={list => setDraft(previous => ({ ...previous, list }))} />
      <div className="flex gap-2">
        {onDelete && <button type="button" onClick={onDelete} className="min-h-11 flex-1 rounded-full border border-[#87544B] text-sm text-[#713A32]">Delete</button>}
        {onShare && <button type="button" onClick={onShare} className="min-h-11 flex-1 rounded-full border border-[#4F7A66] text-sm">Calendar options</button>}
      </div>
      {error && <p role="alert" className="text-[13px] text-[#895F3D]">{error}</p>}
      <div className="grid grid-cols-2 gap-3"><button type="button" onClick={onClose} className="min-h-11 rounded-full border border-[#4F7A66] text-sm">Cancel</button><button className="min-h-11 rounded-full bg-[#4F7A66] text-sm text-white">Save changes</button></div>
    </form>
  </div>
}
