import { taskType, isRecurringTask } from './taskModel.js'
import { dateKey } from './calendarDates.js'

export function calendarTasksForDate(items, date, today) {
  return items.filter(item => {
    if (item.type !== 'goal' || !(item.completed ?? item.done)) return true
    const finished = item.completedAt ? new Date(item.completedAt) : null
    const lastDay = finished && Number.isFinite(finished.getTime()) ? dateKey(finished) : today
    return date <= lastDay
  })
}

export function itemRowTitle(item) {
  if (item.steps?.length) return item.title
  return item.type === 'goal' && item.date !== item.deadline
    ? `A step for “${item.title}”`
    : item.title
}

export function carryQuickTasks(items, today) {
  return items
}

export function isGoalStep(item, date) {
  if (item.type !== 'goal' || date < item.startDate || date > item.deadline) return false
  return (item.stepDates || []).includes(date) || (item.steps || []).some(step => date >= step.startDate && date <= step.endDate)
}

export function appliesOn(item, date) {
  if ((item.excludedDates || []).includes(date)) return false
  if (item.type === 'goal') return date >= item.startDate && date <= item.deadline && (!(item.stepDates || []).length || date === item.deadline || item.stepDates.includes(date) || isGoalStep(item, date))
  if (!isRecurringTask(item)) return item.date === date
  if (item.restoredDates?.includes(date)) return true
  if (item.rule === 'schedule' && item.cadence === 'dates') return (item.dates || []).includes(date)
  if (item.rule === 'schedule' && item.cadence === 'interval') return date >= item.startDate && Number.isInteger(item.interval) && item.interval >= 2 && (Math.round((Date.parse(`${date}T00:00:00Z`) - Date.parse(`${item.startDate}T00:00:00Z`)) / 86400000) % item.interval === 0) && (item.months || []).includes(new Date(`${date}T12:00:00`).getMonth() + 1)
  if (item.rule === 'schedule') return date >= item.startDate && (item.weekdays || []).includes(new Date(`${date}T12:00:00`).getDay() || 7) && (item.months || []).includes(new Date(`${date}T12:00:00`).getMonth() + 1)
  if (item.rule === 'weekdays') return date >= item.startDate && (item.weekdays || []).includes(new Date(`${date}T12:00:00`).getDay() || 7)
  return item.rule === 'daily' ? date >= item.startDate : (item.dates || []).includes(date)
}

export function deleteOccurrence(items, id, date) {
  return items.flatMap(item => {
    if (item.id !== id) return [item]
    if (!appliesOn(item, date) && !item.completedDates?.includes(date)) return [item]
    if (!isRecurringTask(item) && item.type !== 'goal') return []
    return [{ ...item, excludedDates: [...new Set([...(item.excludedDates || []), date])].sort() }]
  })
}

export function itemsForDate(items, date) {
  return items.filter(item => appliesOn(item, date)).map(item => isRecurringTask(item) || item.type === 'goal'
    ? { ...item, date, done: Boolean(item.type === 'goal' && item.completed) || (item.completedDates || []).includes(date), completed: Boolean(item.type === 'goal' && item.completed) || (item.completedDates || []).includes(date) }
    : { ...item, date: item.type === 'goal' ? date : item.date, done: item.completed ?? item.done, completed: item.completed ?? item.done })
}

export function toggleItem(items, id, date, completedAt = new Date().toISOString()) {
  return items.map(item => {
    if (item.id !== id) return item
    if (item.type === 'goal') {
      if (item.completed) {
        const steps = [...(item.steps || [])]
        if (steps.length && steps.every(step => step.completed)) steps[steps.length - 1] = { ...steps.at(-1), completed: false, completedAt: null }
        return { ...item, completed: false, done: false, completedAsWhole: false, completedAt: null, steps, completedDates: (item.completedDates || []).filter(day => day !== date) }
      }
      const days = new Set(item.completedDates || [])
      const times = { ...(item.completionTimes || {}) }
      if (days.has(date)) { days.delete(date); delete times[date] } else { days.add(date); times[date] = completedAt }
      return { ...item, completed: false, done: false, completedAt: null, completedDates: [...days].sort(), completionTimes: times }
    }
    if (!isRecurringTask(item)) { const completed = !(item.completed ?? item.done); return { ...item, done: completed, completed, completedAt: completed ? completedAt : null } }
    const completed = new Set(item.completedDates || [])
    if (completed.has(date)) completed.delete(date)
    else completed.add(date)
    const completionTimes = { ...(item.completionTimes || {}) }
    if (completed.has(date)) completionTimes[date] = completedAt
    else delete completionTimes[date]
    const restoredDates = new Set(item.restoredDates || [])
    if (completed.has(date)) restoredDates.delete(date)
    else restoredDates.add(date)
    return { ...item, completed: false, done: false, completedDates: [...completed].sort(), completionTimes, restoredDates: [...restoredDates] }
  })
}

export function completedThisMonth(items, today = new Date()) {
  return items.flatMap(item => {
    const recurring = isRecurringTask(item)
    const dates = recurring ? (item.completedDates || []).filter(date => !item.excludedDates?.includes(date)) : (item.completed ?? item.done) ? [item.type === 'goal' ? item.deadline : item.date] : []
    return dates.map(date => {
      const completedAt = recurring ? item.completionTimes?.[date] || `${date}T12:00:00` : item.completedAt || `${date}T12:00:00`
      const moment = new Date(completedAt)
      const localMonth = `${moment.getFullYear()}-${String(moment.getMonth() + 1).padStart(2, '0')}`
      return { ...item, date, completedAt, completed: true, localMonth }
    })
  }).sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt))
}

export function dotTypes(items, date) {
  const applicable = items.filter(item => appliesOn(item, date))
  return {
    quick: applicable.some(item => taskType(item) === 'quick'),
    commitment: applicable.some(item => taskType(item) === 'commitment'),
    habit: applicable.some(item => item.type === 'habit'),
    goalDeadline: applicable.some(item => item.type === 'goal' && item.deadline === date),
    goalStep: applicable.some(item => isGoalStep(item, date)),
  }
}

export function unfinishedItems(items, today) {
  return items.flatMap(item => {
    if (!isRecurringTask(item)) return (item.completed ?? item.done) ? [] : [{ ...item, date: item.type === 'goal' ? item.deadline : item.date, completed: false }]
    const result = []
    // Retain overdue occurrences and include the next upcoming scheduled day.
    const start = [item.startDate || item.dates?.[0] || today, ...(item.restoredDates || [])].sort()[0]
    const cursor = new Date(`${start}T12:00:00`)
    const end = new Date(`${today}T12:00:00`)
    end.setFullYear(end.getFullYear() + 4)
    for (; cursor <= end; cursor.setDate(cursor.getDate() + 1)) {
      const date = `${cursor.getFullYear()}-${String(cursor.getMonth() + 1).padStart(2, '0')}-${String(cursor.getDate()).padStart(2, '0')}`
      if (!appliesOn(item, date) || item.completedDates?.includes(date)) continue
      result.push({ ...item, date, completed: false, done: false })
      if (date >= today) break
    }
    return result
  }).sort((a, b) => Number(!a.date) - Number(!b.date) || (a.date || '').localeCompare(b.date || '') || (a.time || '00:00').localeCompare(b.time || '00:00'))
}

export function plannerItemsForToday(items, today) {
  return items.filter(item => !item.completed && (item.type === 'goal' ? item.startDate <= today && !(item.completedDates || []).includes(today) && (today > item.deadline || appliesOn(item, today)) : item.date && item.date <= today)).map(item => item.type === 'goal' ? { ...item, date: today > item.deadline ? item.deadline : today } : item)
}

export function toggleGoalStep(items, id, stepId, completedAt = new Date().toISOString()) {
  return items.map(item => {
    if (item.id !== id) return item
    const steps = (item.steps || []).map(step => step.id === stepId ? { ...step, completed: !step.completed, completedAt: step.completed ? null : completedAt } : step)
    const completed = Boolean(item.completedAsWhole) || (steps.length > 0 && steps.every(step => step.completed))
    return { ...item, steps, completed, done: completed, completedAt: completed ? completedAt : null }
  })
}

export function completeWholeGoal(items, id, completedAt = new Date().toISOString()) {
  return items.map(item => item.id === id ? { ...item, completed: true, done: true, completedAsWhole: true, completedAt } : item)
}
