import TaskApple from './TaskApple'
import { itemRowTitle } from './taskSchedule'

export default function CompletedPage({ items, onRestore }) {
  return <div className="flex h-full flex-col px-4">
    <h2 className="sr-only">Completed · {items.length}</h2>
    <ul className="task-scroll min-h-0 flex-1 overflow-y-auto overscroll-y-contain pb-5">
      {!items.length && <li className="flex h-full items-center justify-center text-center text-[14px] text-[#59554D]">Nothing completed this month yet.</li>}
      {items.map(item => <li key={`${item.id}@${item.date}`} className="flex min-h-[82px] items-center gap-3 border-b border-[#6E9A82]/40 py-3 last:border-0">
        <span className="flex w-6 shrink-0 justify-center"><TaskApple task={item} /></span>
        <div className="min-w-0 flex-1"><p title={itemRowTitle(item)} className="truncate text-[14px] font-semibold">{itemRowTitle(item)}</p><p className="mt-1 text-[11px] text-[#59554D]">{new Date(item.completedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</p></div>
        <button type="button" onClick={() => onRestore(item)} aria-label={`Restore ${item.title} for ${item.date}`} className="min-h-11 shrink-0 rounded-full border border-[#4F7A66] px-3 text-[12px] font-semibold text-[#4F7A66] focus-visible:outline-2 focus-visible:outline-[#4F7A66]">Restore</button>
      </li>)}
    </ul>
  </div>
}
