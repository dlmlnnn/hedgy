import { plannerItemsForToday } from './taskSchedule.js'

export const appleAnchorPercentages = [[30,16],[55,13],[75,22],[16,30],[40,28],[63,34],[86,38],[26,44],[50,46],[73,50],[14,56],[38,58],[62,60],[84,62]]
export const anchorOrder = [5,10,2,13,7,11,3,8,14,1,6,12,4,9].map(number => number - 1)
export const appleAssignmentKey = 'team-b-2:treeAppleAnchors'
export const appleItemKey = item => item.type === 'habit' || (item.type === 'commitment' && item.rule === 'schedule') ? `${item.id}@${item.date}` : item.id
export const anchorPosition = index => appleAnchorPercentages[index].map((value, axis) => value * (axis ? .88 : 1.4))

export function treeItemsForToday(plannerItems, today, goals = []) {
  const visible = new Map(plannerItemsForToday(plannerItems, today).map(item => [appleItemKey(item), item]))
  // Daily check-offs retain one main goal apple. Only whole-goal completion
  // or the final completed step removes it.
  for (const goal of goals) if (goal.type === 'goal' && !goal.completed && goal.startDate <= today) visible.set(goal.id, { ...goal, date: today })
  return [...visible.values()]
}

export function reconcileAppleAssignments(previous, items, reserved = []) {
  const active = new Set(items.map(appleItemKey))
  const result = {}
  const occupied = new Set(reserved)
  for (const [key, index] of Object.entries(previous || {})) {
    if (active.has(key) && Number.isInteger(index) && index >= 0 && index < 14 && !occupied.has(index)) {
      result[key] = index
      occupied.add(index)
    }
  }
  for (const item of items) {
    const key = appleItemKey(item)
    if (Object.hasOwn(result, key)) continue
    const free = anchorOrder.find(index => !occupied.has(index))
    if (free === undefined) break
    result[key] = free
    occupied.add(free)
  }
  return result
}

export function loadAppleAssignments() {
  try { return JSON.parse(localStorage.getItem(appleAssignmentKey)) || {} } catch { return {} }
}

export function appleLandingLane(x, active) {
  let lane = 0
  while (active.some(event => Math.hypot(event.startX - x, event.landY - (238 - lane * 12)) < 12)) lane++
  return lane
}
