export default function PlannerCalendarButton({ today, buttonRef, onOpen }) {
  return <button ref={buttonRef} type="button" onClick={onOpen} aria-label={`Open calendar, ${today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}`} aria-haspopup="dialog" className="absolute bottom-4 left-4 flex h-[46.08px] w-[46.08px] items-center justify-center rounded-full bg-[#ACBFE0] text-white shadow-[0_4px_12px_rgba(70,50,30,0.18)] transition hover:bg-[#9DB1D4] active:scale-95 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#4F7A66]">
    <svg aria-hidden="true" width="28" height="29" viewBox="0 0 28 29" fill="none">
      <rect x="3" y="5" width="22" height="21" rx="4" stroke="currentColor" strokeWidth="1.6" />
      <path d="M3 11h22M9 3v5m10-5v5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <text x="14" y="22" textAnchor="middle" fill="currentColor" fontFamily="Nunito, sans-serif" fontSize="11" fontWeight="700">{today.getDate()}</text>
    </svg>
  </button>
}
