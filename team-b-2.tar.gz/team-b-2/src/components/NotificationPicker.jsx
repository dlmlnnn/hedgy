export default function NotificationPicker({ value = 'none', onChange }) {
  return <label className="block text-[12px] font-semibold">
    <span className="flex items-center justify-between gap-2"><span>Set a notification</span><span className="text-[10px] font-normal text-[#8A867C]">Coming soon</span></span>
    <span className="mt-1 flex min-h-11 items-center gap-2 rounded-[15px] border border-[#6E9A82]/30 bg-(--control-surface) px-3">
      <svg aria-hidden="true" width="18" height="20" viewBox="0 0 24 24" fill="none" stroke="#70796B" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4M12 2V1" /></svg>
      <select aria-label="Set a notification" value={value} onChange={event => onChange(event.target.value)} className="min-h-11 min-w-0 flex-1 bg-transparent text-[14px] font-normal text-[#2E2A25] outline-[#4F7A66]">
        <option value="none">None</option>
        <option value="at-time">At the scheduled time</option>
        <option value="5-minutes">5 minutes before</option>
        <option value="15-minutes">15 minutes before</option>
        <option value="30-minutes">30 minutes before</option>
        <option value="1-hour">1 hour before</option>
        <option value="1-day">1 day before</option>
      </select>
    </span>
  </label>
}
