import { useEffect, useRef, useState } from 'react'
import Welcome from './components/Welcome'
import Planner from './components/Planner'

const key = 'team-b-2:hasSeenWelcome'
const themeKey = 'team-b-2:theme'
function initialTheme() {
  try {
    const theme = localStorage.getItem(themeKey)
    if (theme === 'dark' || theme === 'neutral') return theme
  } catch { /* Storage is optional. */ }
  return 'regular'
}
function initialScreen() {
  if (new URLSearchParams(window.location.search).get('welcome') === '1') return 'welcome'
  try { return localStorage.getItem(key) === 'true' ? 'planner' : 'welcome' } catch { return 'welcome' }
}
export default function App() {
  const [screen, setScreen] = useState(initialScreen)
  const [theme, setTheme] = useState(initialTheme)
  const [planting, setPlanting] = useState(false)
  const timer = useRef()
  useEffect(() => () => clearTimeout(timer.current), [])
  useEffect(() => {
    try { localStorage.setItem(themeKey, theme) } catch { /* Storage is optional. */ }
  }, [theme])
  function plant() {
    if (planting) return
    setPlanting(true)
    timer.current = setTimeout(() => {
      try { localStorage.setItem(key, 'true') } catch { /* Storage is optional. */ }
      setScreen('planner')
    }, 250)
  }
  return (
    <main className="app-shell flex min-h-dvh items-center justify-center bg-[#E6DFCE] sm:p-8">
      <div data-theme={theme} className="phone relative flex w-full flex-col overflow-hidden bg-[#F3EEDF] text-[#2E2A25] sm:max-w-[393px] sm:rounded-[48px] sm:shadow-[0_8px_24px_rgba(70,50,30,0.18)] sm:ring-[7px] sm:ring-[#F8F4E8]">
        <div aria-hidden="true" className="phone-decoration absolute left-1/2 top-3 z-20 hidden h-[25px] w-[100px] -translate-x-1/2 rounded-full bg-[#2E2A25] sm:block" />
        <div className="app-stage absolute inset-0 flex min-h-0 flex-col">
        {screen === 'welcome' ? <Welcome onStart={plant} exiting={planting} /> : <Planner theme={theme} onThemeChange={setTheme} />}
        </div>
        <div aria-hidden="true" className="phone-decoration pointer-events-none absolute bottom-2 left-1/2 hidden h-[5px] w-[120px] -translate-x-1/2 rounded-full bg-[#2E2A25]/70 sm:block" />
      </div>
    </main>
  )
}
