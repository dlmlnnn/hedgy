import { defineConfig } from '@playwright/test'

export default defineConfig({
  testDir: './tests/mobile',
  fullyParallel: true,
  workers: 2,
  timeout: 30000,
  use: { browserName: 'chromium', timezoneId: 'Europe/Tallinn', isMobile: true, hasTouch: true, screenshot: 'only-on-failure' },
  projects: [
    { name: 'iphone-small', use: { viewport: { width: 375, height: 667 } } },
    { name: 'iphone-15', use: { viewport: { width: 393, height: 852 } } },
    { name: 'iphone-large', use: { viewport: { width: 440, height: 956 } } },
    { name: 'android-small', use: { viewport: { width: 360, height: 640 } } },
    { name: 'android-pixel', use: { viewport: { width: 412, height: 915 } } },
    { name: 'phone-landscape', use: { viewport: { width: 844, height: 390 } } },
  ],
})
